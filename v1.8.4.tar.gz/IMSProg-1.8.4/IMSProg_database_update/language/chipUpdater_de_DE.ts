<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <source>IMSProg database updater</source>
        <translation>IMSProg database updater</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="32"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The &lt;span style=&quot; font-style:italic;&quot;&gt;&apos;IMSProg.Dat&apos;&lt;/span&gt; file will be replaced&lt;/p&gt;&lt;p&gt;with the new version. &lt;/p&gt;&lt;p&gt;You may lose the changes made to it.&lt;/p&gt;&lt;p&gt; Continue?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Die Datei &lt;span style=&quot; font-style:italic;&quot;&gt;&apos;IMSProg.Dat&apos;&lt;/span&gt; wird&lt;/p&gt;&lt;p&gt;durch die neue Version ersetzt. &lt;/p&gt;&lt;p&gt;Die darin vorgenommenen Änderungen gehen möglicherweise verloren.&lt;/p&gt;&lt;p&gt; Fortfahren?&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="70"/>
        <location filename="../mainwindow.cpp" line="150"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="77"/>
        <source>Exit</source>
        <translation>Beenden</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="82"/>
        <source>Downloading file IMSProg.Dat</source>
        <translation>Datei IMSProg.Dat wird heruntergeladen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="88"/>
        <source>Invalid URL</source>
        <translation>Ungültige URL</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="96"/>
        <source>Cannot create temporary file for download</source>
        <translation>Temporäre Datei für den Download kann nicht erstellt werden</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="148"/>
        <source>The database has been updated!

The old database contained %1 chips,
The new database contains %2 chips.</source>
        <translation>Die Datenbank wurde aktualisiert!

Die alte Datenbank enthält %1 Chips,
die neue Datenbank enthält %2 Chips.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="152"/>
        <source>Failed to replace the database file</source>
        <translation>Das Ersetzen der Datenbankdatei ist fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="155"/>
        <source>Downloaded file is too small (corrupted?)</source>
        <translation>Die heruntergeladene Datei ist zu klein (beschädigt?)</translation>
    </message>
    <message>
        <source>Download failed: </source>
        <translation type="vanished">Download fehlgeschlagen: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="181"/>
        <source>Error loading file: </source>
        <translation>Fehler beim Laden der Datei: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="199"/>
        <source>Error:</source>
        <translation>Fehler:</translation>
    </message>
</context>
</TS>
