<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>DialogAbout</name>
    <message>
        <location filename="../dialogabout.ui" line="14"/>
        <source>About IMSProg</source>
        <translation>Über IMSProg</translation>
    </message>
    <message>
        <source>IMSProg - free software I2C, SPI and MicroWire EEPROM/Flash chip programmer for CH341a devices. IMSProg supports 24Cxx, 25xx, 93Cxx, and M95xx series chips.</source>
        <translation type="vanished">IMSProg - freie Software I2C, SPI und MicroWire EEPROM/Flash Chip Programmierer für CH341a Geräte. IMSProg unterstützt Chips der Serien 24Cxx, 25xx, 93Cxx und M95xx.</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="26"/>
        <source>IMSProg - free software I2C, SPI and MicroWire EEPROM/Flash chip programmer for CH341A and CH347T devices. IMSProg supports 24Cxx, 25xx, 93Cxx, AT45DBxx and M95xx series chips.</source>
        <translation>IMSProg - freie Software I2C, SPI und MicroWire EEPROM/Flash Chip Programmierer für CH341A und CH347T Geräte. IMSProg unterstützt Chips der Serien 24Cxx, 25xx, 93Cxx und M95xx.</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="90"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;In this program &lt;a href=&quot;https://github.com/Simsys/qhexedit2/&quot;&gt;QhexEditor2&lt;/a&gt; widget and modified programmer &lt;a href=&quot;https://github.com/McMCCRU/SNANDer&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;SNANDer&lt;/span&gt;&lt;/a&gt; were used.&lt;/p&gt;&lt;p&gt;The page on GitHub is &lt;a href=&quot;https://github.com/bigbigmdm/IMSProg&quot;&gt;here&lt;/a&gt;, the support page is &lt;a href=&quot;https://antenna-dvb-t2.ru/IMSProg.php&quot;&gt;here&lt;/a&gt;. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;In diesem Programm wurden das &lt;a href=&quot;https://github.com/Simsys/qhexedit2/&quot;&gt;QhexEditor2&lt;/a&gt; Widget und der modifizierte Programmierer &lt;a href=&quot;https://github.com/McMCCRU/SNANDer&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;SNANDer&lt;/span&gt;&lt;/a&gt; verwendet.&lt;/p&gt;&lt;p&gt;Die Seite auf GitHub ist &lt;a href=&quot;https://github.com/bigbigmdm/IMSProg&quot;&gt;hier&lt;/a&gt;, die Support-Seite ist &lt;a href=&quot;https://antenna-dvb-t2.ru/IMSProg.php&quot;&gt;hier&lt;/a&gt;. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="119"/>
        <source>Written by 2023 - 2026 Mikhail Medvedev</source>
        <translation>Geschrieben von 2023 - 2026 Mikhail Medvedev</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="140"/>
        <source>Version: </source>
        <translation>Version: </translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="150"/>
        <source>1.1.4</source>
        <translation>1.1.4</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="48"/>
        <location filename="../dialogabout.ui" line="68"/>
        <source>OR</source>
        <translation>ODER</translation>
    </message>
    <message>
        <source>IMSProg - free software I2C, SPI and MicroWire EEPROM/Flash chip programmer for CH341a devices. IMSProg supports 24Cxx, 25xx, 93Cxx, AT45DBxx and M95xx series chips.</source>
        <translation type="vanished">IMSProg - freie Software I2C, SPI und MicroWire EEPROM/Flash Chip Programmierer für CH341a Geräte. IMSProg unterstützt Chips der Serien 24Cxx, 25xx, 93Cxx und M95xx.</translation>
    </message>
    <message>
        <source>Written by 2023 Mikhail Medvedev</source>
        <translation type="vanished">Geschrieben von 2023 Mikhail Medvedev</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="189"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
</context>
<context>
    <name>DialogBBM</name>
    <message>
        <location filename="../dialogbbm.ui" line="20"/>
        <source>Bad block management</source>
        <translation>Verwaltung fehlerhafter Blöcke</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="34"/>
        <source>Chip scan</source>
        <translation>Chip-Scan</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="69"/>
        <location filename="../dialogbbm.ui" line="285"/>
        <source>No</source>
        <translation>Anzahl</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="77"/>
        <source>Block</source>
        <translation>Block</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="85"/>
        <source>Start address</source>
        <translation>Startadresse</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="93"/>
        <source>End address</source>
        <translation>Endadresse</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="137"/>
        <source>Check</source>
        <translation>Start</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="147"/>
        <source>Settings</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="167"/>
        <source>Erasing</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="173"/>
        <source>Skip bad blocks during erase procedure  (recommended)</source>
        <translation>Fehlerhafte Blöcke überspringen (empfohlen)</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="180"/>
        <source>Don&apos;t skip bad blocks</source>
        <translation>Überspringen Sie keine fehlerhaften Blöcke.</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="190"/>
        <source>Writing</source>
        <translation>Schreiben</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="196"/>
        <source>Write all blocks one to one (ignore bad blocks)</source>
        <translation>Schreiben Sie alle Blöcke eins zu eins (ignorieren die fehlerhaften).</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="203"/>
        <source>Skip bad blocks during writing procedure</source>
        <translation>Beschädigte Blöcke während des Schreibvorgangs überspringen</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="256"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="268"/>
        <source>BBM table (Winbond)</source>
        <translation>BBM-Tabelle (Winbond)</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="274"/>
        <source>This operation is used only in some Winbond chips.</source>
        <translation>Dieser Vorgang wird nur bei einigen Winbond-Chips verwendet.</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="290"/>
        <source>Bad block</source>
        <translation>Defekter Block</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="295"/>
        <source>Changed block</source>
        <translation>Geänderter Block</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="300"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="348"/>
        <source>Read</source>
        <translation>Lesen</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="81"/>
        <location filename="../dialogbbm.cpp" line="93"/>
        <location filename="../dialogbbm.cpp" line="164"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="81"/>
        <source>Error reading chip!</source>
        <translation>Fehler beim Lesen des Chips!</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="85"/>
        <source>Corrupted blocks found:</source>
        <translation>Beschädigte Blöcke gefunden:</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="86"/>
        <source>All blocks in the chip are good!</source>
        <translation>Alle Blöcke im Chip sind in Ordnung!</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="93"/>
        <location filename="../dialogbbm.cpp" line="164"/>
        <source>Programmer </source>
        <translation>Das Programmiergerät </translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="93"/>
        <location filename="../dialogbbm.cpp" line="164"/>
        <source> is not connected!</source>
        <translation> ist nicht angeschlossen!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">Das Programmiergerät CH341a ist nicht angeschlossen!</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="154"/>
        <source>Not used</source>
        <translation>Nicht verwendet</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="155"/>
        <source>Active, valid</source>
        <translation>Aktiv, gültig</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="156"/>
        <source>Active, not valid</source>
        <translation>Aktiv, nicht gültig</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="161"/>
        <source>BBM table is not used in this chip.</source>
        <translation>Die BBM-Tabelle wird in diesem Chip nicht verwendet.</translation>
    </message>
</context>
<context>
    <name>DialogCompare</name>
    <message>
        <location filename="../dialogcompare.ui" line="14"/>
        <source>Comparing files:</source>
        <translation>Vergleich von Dateien:</translation>
    </message>
    <message>
        <location filename="../dialogcompare.ui" line="68"/>
        <source>CRC32: </source>
        <translation>CRC32: </translation>
    </message>
    <message>
        <location filename="../dialogcompare.ui" line="100"/>
        <location filename="../dialogcompare.ui" line="187"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="../dialogcompare.ui" line="155"/>
        <source>CRC32:</source>
        <translation>CRC32:</translation>
    </message>
    <message>
        <location filename="../dialogcompare.ui" line="201"/>
        <source>Visible ASCII areas</source>
        <translation>ASCII-Bereiche anzeigen</translation>
    </message>
    <message>
        <location filename="../dialogcompare.cpp" line="110"/>
        <location filename="../dialogcompare.cpp" line="111"/>
        <source>Name: </source>
        <translation>Name:</translation>
    </message>
</context>
<context>
    <name>DialogFill</name>
    <message>
        <location filename="../dialogfill.ui" line="14"/>
        <source>Fill the buffer with code</source>
        <translation>Puffer mit Code füllen</translation>
    </message>
    <message>
        <location filename="../dialogfill.ui" line="27"/>
        <source>All values in HEX format!</source>
        <translation>Alle Werte im HEX-Format!</translation>
    </message>
    <message>
        <location filename="../dialogfill.ui" line="42"/>
        <source>Start address:</source>
        <translation>Startadresse:</translation>
    </message>
    <message>
        <location filename="../dialogfill.ui" line="91"/>
        <source>Filling code:</source>
        <translation>Code wird eingefügt:</translation>
    </message>
    <message>
        <location filename="../dialogfill.ui" line="130"/>
        <source>Fill</source>
        <translation>Füllen</translation>
    </message>
    <message>
        <location filename="../dialogfill.cpp" line="36"/>
        <source>End address</source>
        <translation>Endadresse</translation>
    </message>
    <message>
        <location filename="../dialogfill.cpp" line="37"/>
        <source>Length</source>
        <translation>Länge</translation>
    </message>
</context>
<context>
    <name>DialogInfo</name>
    <message>
        <location filename="../dialoginfo.ui" line="14"/>
        <source>Connection info:</source>
        <translation>Verbindungsinformationen:</translation>
    </message>
    <message>
        <location filename="../dialoginfo.ui" line="36"/>
        <source>Slot:</source>
        <translation>Steckplatz:</translation>
    </message>
    <message>
        <location filename="../dialoginfo.ui" line="43"/>
        <location filename="../dialoginfo.ui" line="61"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../dialoginfo.ui" line="54"/>
        <source>Adapter:</source>
        <translation>Adapter:</translation>
    </message>
    <message>
        <location filename="../dialoginfo.ui" line="106"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
</context>
<context>
    <name>DialogNANDSr</name>
    <message>
        <location filename="../dialognandsr.ui" line="20"/>
        <source>Status registers</source>
        <translation>Statusregister</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="37"/>
        <source>Status register 1</source>
        <translation>Statusregister 1</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="318"/>
        <source>SRP0</source>
        <translation>SRP0</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="349"/>
        <source>BP3</source>
        <translation>BP3</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="380"/>
        <source>BP2</source>
        <translation>BP2</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="411"/>
        <source>BP1</source>
        <translation>BP1</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="442"/>
        <source>BP0</source>
        <translation>BP0</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="473"/>
        <source>TB</source>
        <translation>TB</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="504"/>
        <source>WP-E</source>
        <translation>WP-E</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="535"/>
        <source>SRP1</source>
        <translation>SRP1</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="552"/>
        <source>Status register 2</source>
        <translation>Statusregister 2</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="824"/>
        <source>OTP-L</source>
        <translation>OTP-L</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="852"/>
        <source>OTP-E</source>
        <translation>OTP-E</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="880"/>
        <source>SR1-L</source>
        <translation>SR1-L</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="908"/>
        <source>ECC-E</source>
        <translation>ECC-E</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="936"/>
        <source>BUF</source>
        <translation>BUF</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="964"/>
        <location filename="../dialognandsr.ui" line="992"/>
        <location filename="../dialognandsr.ui" line="1020"/>
        <location filename="../dialognandsr.ui" line="1309"/>
        <source>(R)</source>
        <translation>(R)</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1040"/>
        <source>Status register 3</source>
        <translation>Statusregister 3</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1337"/>
        <source>LUT-F</source>
        <translation>LUT-F</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1365"/>
        <source>ECC-1</source>
        <translation>ECC-1</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1393"/>
        <source>ECC-0</source>
        <translation>ECC-0</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1421"/>
        <source>P-FAIL</source>
        <translation>P-FAIL</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1449"/>
        <source>WELL</source>
        <translation>WELL</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1477"/>
        <source>BUSY</source>
        <translation>BUSY</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1505"/>
        <source>E_FAIL</source>
        <translation>E_FAIL</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1522"/>
        <source>Status register 4</source>
        <translation>Statusregister 4</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1785"/>
        <location filename="../dialognandsr.ui" line="1813"/>
        <location filename="../dialognandsr.ui" line="1841"/>
        <location filename="../dialognandsr.ui" line="1869"/>
        <location filename="../dialognandsr.ui" line="1897"/>
        <location filename="../dialognandsr.ui" line="1925"/>
        <location filename="../dialognandsr.ui" line="1953"/>
        <location filename="../dialognandsr.ui" line="1981"/>
        <location filename="../dialognandsr.ui" line="2261"/>
        <location filename="../dialognandsr.ui" line="2289"/>
        <location filename="../dialognandsr.ui" line="2317"/>
        <location filename="../dialognandsr.ui" line="2345"/>
        <location filename="../dialognandsr.ui" line="2373"/>
        <location filename="../dialognandsr.ui" line="2401"/>
        <location filename="../dialognandsr.ui" line="2429"/>
        <location filename="../dialognandsr.ui" line="2457"/>
        <source>---</source>
        <translation>---</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1998"/>
        <source>Status register 5</source>
        <translation>Statusregister 5</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2482"/>
        <source>Unique ID:</source>
        <translation>Eindeutige ID:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2538"/>
        <source>Read</source>
        <translation>Lesen</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2564"/>
        <source>Write</source>
        <translation>Schreiben</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2580"/>
        <source>Parameter page:</source>
        <translation>Parameter-Seite:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2608"/>
        <source>Manufacturer:</source>
        <translation>Herstellung:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2618"/>
        <source>Model:</source>
        <translation>Modell:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2628"/>
        <source>Page size:</source>
        <translation>Page Größe:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2635"/>
        <source>ECC size:</source>
        <translation>ECC Größe:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2648"/>
        <source>Pages per block:</source>
        <translation>Seiten pro Block:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2655"/>
        <source>Block per unit:</source>
        <translation>Block pro Einheit:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2662"/>
        <source>Block size:</source>
        <translation>Block Größe:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2678"/>
        <source>Chip size:</source>
        <translation>Chip Größe:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="102"/>
        <location filename="../dialognandsr.cpp" line="166"/>
        <location filename="../dialognandsr.cpp" line="266"/>
        <location filename="../dialognandsr.cpp" line="309"/>
        <location filename="../dialognandsr.cpp" line="365"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="102"/>
        <source>Error reading register!</source>
        <translation>Fehler beim Lesen des Registers!</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="166"/>
        <source>Error reading Parameter Page!</source>
        <translation>Fehler beim Lesen der Parameterseite!</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="248"/>
        <source>The Parameter Page is not supported.</source>
        <translation>Die Parameterseite wird nicht unterstützt.</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="266"/>
        <source>Error reading ID!</source>
        <translation>Fehler beim Lesen der ID!</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="309"/>
        <location filename="../dialognandsr.cpp" line="365"/>
        <source>Programmer </source>
        <translation>Das Programmiergerät </translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="309"/>
        <location filename="../dialognandsr.cpp" line="365"/>
        <source> is not connected!</source>
        <translation> ist nicht angeschlossen!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">Das Programmiergerät CH341a ist nicht angeschlossen!</translation>
    </message>
</context>
<context>
    <name>DialogNandSecurity</name>
    <message>
        <location filename="../dialognandsecurity.ui" line="14"/>
        <source>Security registers</source>
        <translation>Sicherheitsregister</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="24"/>
        <source>Hex Editor</source>
        <translation>Hexadezimal-Editor</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="64"/>
        <source>Operations:</source>
        <translation>Operationen:</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="93"/>
        <source>Reading security register data from the chip</source>
        <translation>Lesen von Sicherheitsregisterdaten aus dem Chip</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="96"/>
        <location filename="../dialognandsecurity.ui" line="128"/>
        <location filename="../dialognandsecurity.ui" line="167"/>
        <location filename="../dialognandsecurity.ui" line="199"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="125"/>
        <source>Writing data to the security register</source>
        <translation>Schreiben von Daten in das Sicherheitsregister</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="164"/>
        <source>Open a binary file from a computer</source>
        <translation>Öffnen einer Binärdatei auf einem Computer</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="196"/>
        <source>Save the binary file on the computer</source>
        <translation>Speichern Sie die Binärdatei auf dem Computer</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="225"/>
        <source>Security register number:</source>
        <translation>Nummer des Sicherheitsregisters:</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="79"/>
        <location filename="../dialognandsecurity.cpp" line="119"/>
        <location filename="../dialognandsecurity.cpp" line="214"/>
        <location filename="../dialognandsecurity.cpp" line="232"/>
        <location filename="../dialognandsecurity.cpp" line="265"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="79"/>
        <source>Error reading Parameter Page!</source>
        <translation>Fehler beim Lesen der Parameterseite!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">Das Programmiergerät CH341a ist nicht angeschlossen!</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="119"/>
        <location filename="../dialognandsecurity.cpp" line="214"/>
        <source>Programmer </source>
        <translation>Das Programmiergerät </translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="119"/>
        <location filename="../dialognandsecurity.cpp" line="214"/>
        <source> is not connected!</source>
        <translation> ist nicht angeschlossen!</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="223"/>
        <source>Open file</source>
        <translation>Datei öffnen</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="232"/>
        <source>The file size exceeds the security register size.</source>
        <translation>Die Dateigröße übersteigt die Größe des Sicherheitsregisters.</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="254"/>
        <source>Save file</source>
        <translation>Datei speichern</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="265"/>
        <source>Error saving file!</source>
        <translation>Fehler beim Speichern der Datei!</translation>
    </message>
</context>
<context>
    <name>DialogRP</name>
    <message>
        <location filename="../dialogrp.ui" line="20"/>
        <source>Load block from file</source>
        <translation>Block aus Datei laden</translation>
    </message>
    <message>
        <location filename="../dialogrp.ui" line="33"/>
        <source>All values in HEX format!</source>
        <translation>Alle Werte im HEX-Format!</translation>
    </message>
    <message>
        <location filename="../dialogrp.ui" line="48"/>
        <source>Start address:</source>
        <translation>Startadresse:</translation>
    </message>
    <message>
        <location filename="../dialogrp.ui" line="112"/>
        <source>Load</source>
        <translation>Laden</translation>
    </message>
</context>
<context>
    <name>DialogSFDP</name>
    <message>
        <location filename="../dialogsfdp.ui" line="14"/>
        <source>Information about SFDP and status registers</source>
        <translation>Informationen zu SFDP und Statusregistern</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="47"/>
        <source>SFDP support:</source>
        <translation>SFDP Unterstützung:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="67"/>
        <source>Minimum VCC:</source>
        <translation>Minimum VCC:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="87"/>
        <source>Maximum VCC:</source>
        <translation>Maximale VCC:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="107"/>
        <source>Chip size:</source>
        <translation>Chip Größe:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="127"/>
        <source>Block size:</source>
        <translation>Block Größe:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="150"/>
        <source>Speeds:</source>
        <translation>Geschwindigkeiten:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="170"/>
        <source>OTP support:</source>
        <translation>OTP Unterstützung:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="196"/>
        <source>Status Register 0</source>
        <translation>Statusregister 0</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="424"/>
        <source>SPR0</source>
        <translation>SPR0</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="449"/>
        <source>BP4</source>
        <translation>BP4</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="474"/>
        <source>BP3</source>
        <translation>BP3</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="499"/>
        <source>BP2</source>
        <translation>BP2</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="524"/>
        <source>BP1</source>
        <translation>BP1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="549"/>
        <source>BP0</source>
        <translation>BP0</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="574"/>
        <source>WEL</source>
        <translation>WEL</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="599"/>
        <source>WIP</source>
        <translation>WIP</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="830"/>
        <source>SUS1</source>
        <translation>SUS1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="855"/>
        <source>CMP</source>
        <translation>CMP</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="880"/>
        <source>LB3</source>
        <translation>LB3</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="905"/>
        <source>LB2</source>
        <translation>LB2</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="930"/>
        <source>LB1</source>
        <translation>LB1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="955"/>
        <source>SUS2</source>
        <translation>SUS2</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="980"/>
        <source>QE</source>
        <translation>QE</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1005"/>
        <source>SPR1</source>
        <translation>SPR1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="611"/>
        <source>Status Register 1</source>
        <translation>Statusregister 1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1017"/>
        <source>Status register 2</source>
        <translation>Statusregister 2</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1195"/>
        <source>JEDEC info:</source>
        <translation>JEDEC-Info:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1301"/>
        <source>Man. ID</source>
        <translatorcomment>Herst. ID</translatorcomment>
        <translation>Hersteller ID</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1323"/>
        <source>Man. type</source>
        <translation>Herst. typ</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1345"/>
        <source>Capacity</source>
        <translation>Größe</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1357"/>
        <source>Unique ID:</source>
        <translation>Eindeutige ID:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1398"/>
        <source>Read</source>
        <translation>Lesen</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1426"/>
        <source>Write registers</source>
        <translation>Register schreiben</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1453"/>
        <location filename="../dialogsfdp.ui" line="1519"/>
        <location filename="../dialogsfdp.ui" line="1541"/>
        <source>(R)</source>
        <translation>(R)</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1475"/>
        <source>DRV1</source>
        <translation>DRV1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1497"/>
        <source>DRV0</source>
        <translation>DRV0</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1563"/>
        <source>WPS</source>
        <translation>WPS</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1585"/>
        <source>ADP</source>
        <translation>ADP</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1607"/>
        <source>ADS</source>
        <translation>ADS</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1693"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p/&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p/&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1731"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Legend:&lt;/p&gt;&lt;p&gt;** - Basic area&lt;br&gt;** - Extended area&lt;br&gt;** - Manufacture area &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Legende:&lt;/p&gt;&lt;p&gt;** - Basisbereich&lt;br&gt;** - Erweiterter Bereich&lt;br&gt;** - Herstellerbereich &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1776"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="84"/>
        <location filename="../dialogsfdp.cpp" line="104"/>
        <location filename="../dialogsfdp.cpp" line="213"/>
        <location filename="../dialogsfdp.cpp" line="226"/>
        <location filename="../dialogsfdp.cpp" line="245"/>
        <location filename="../dialogsfdp.cpp" line="267"/>
        <location filename="../dialogsfdp.cpp" line="282"/>
        <location filename="../dialogsfdp.cpp" line="435"/>
        <location filename="../dialogsfdp.cpp" line="439"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="104"/>
        <location filename="../dialogsfdp.cpp" line="213"/>
        <location filename="../dialogsfdp.cpp" line="226"/>
        <location filename="../dialogsfdp.cpp" line="245"/>
        <source>Error reading register!</source>
        <translation>Fehler beim Lesen des Registers!</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="176"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt; Hex SFDP register data:
</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt; Hex SFDP-Registerdaten:
</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="177"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Addr:&lt;br&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Adr.:&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="282"/>
        <location filename="../dialogsfdp.cpp" line="435"/>
        <source>Programmer </source>
        <translation>Das Programmiergerät </translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="282"/>
        <location filename="../dialogsfdp.cpp" line="435"/>
        <source> is not connected!</source>
        <translation> ist nicht angeschlossen!</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="439"/>
        <source>Before writing the registers, please press the `Read` button!</source>
        <translation>Vor dem Register schreiben bitte die Taste `Lesen` drücken!</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="84"/>
        <source>Error reading JEDEC ID!</source>
        <translation>Fehler beim Lesen der JEDEC-ID!</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="44"/>
        <source>Legend:</source>
        <translation>Legende:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="45"/>
        <source> - Basic area</source>
        <translation> - Basisbereich</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="46"/>
        <source> - Extended area</source>
        <translation> - Erweiterter Bereich</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="47"/>
        <source> - Manufacture area</source>
        <translation> - Herstellerbereich</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="267"/>
        <source>Error reading unique ID!</source>
        <translation>Fehler beim Lesen der eindeutigen ID!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">Das Programmiergerät CH341a ist nicht angeschlossen!</translation>
    </message>
</context>
<context>
    <name>DialogSP</name>
    <message>
        <location filename="../dialogsp.ui" line="14"/>
        <source>Save part of image</source>
        <translation>Teil des Abbildes speichern</translation>
    </message>
    <message>
        <location filename="../dialogsp.ui" line="27"/>
        <source>All values in HEX format!</source>
        <translation>Alle Werte im HEX-Format!</translation>
    </message>
    <message>
        <location filename="../dialogsp.ui" line="42"/>
        <source>Start address:</source>
        <translation>Startadresse:</translation>
    </message>
    <message>
        <location filename="../dialogsp.ui" line="120"/>
        <source>Save</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <location filename="../dialogsp.cpp" line="28"/>
        <source>End address</source>
        <translation>Endadresse</translation>
    </message>
    <message>
        <location filename="../dialogsp.cpp" line="29"/>
        <source>Length</source>
        <translation>Länge</translation>
    </message>
</context>
<context>
    <name>DialogSR</name>
    <message>
        <location filename="../dialogsr.ui" line="14"/>
        <source>Status register</source>
        <translation>Statusregister</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="296"/>
        <source>WPEN</source>
        <translation>WPEN</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="327"/>
        <location filename="../dialogsr.ui" line="358"/>
        <location filename="../dialogsr.ui" line="389"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="420"/>
        <source>BP1</source>
        <translation>BP1</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="451"/>
        <source>BP0</source>
        <translation>BP0</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="482"/>
        <source>WEN</source>
        <translation>WEN</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="513"/>
        <source>/RDY</source>
        <translation>/RDY</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="545"/>
        <source>Read</source>
        <translation>Lesen</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="571"/>
        <source>Write</source>
        <translation>Schreiben</translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="57"/>
        <location filename="../dialogsr.cpp" line="71"/>
        <location filename="../dialogsr.cpp" line="110"/>
        <location filename="../dialogsr.cpp" line="113"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="57"/>
        <source>Error reading register!</source>
        <translation>Fehler beim Lesen des Registers!</translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="71"/>
        <location filename="../dialogsr.cpp" line="113"/>
        <source>Programmer </source>
        <translation>Das Programmiergerät </translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="71"/>
        <location filename="../dialogsr.cpp" line="113"/>
        <source> is not connected!</source>
        <translation> ist nicht angeschlossen!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">Das Programmiergerät CH341a ist nicht angeschlossen!</translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="110"/>
        <source>Before writing the register, please press the `Read` button!</source>
        <translation>Vor dem Register schreiben bitte die Taste `Lesen` drücken!</translation>
    </message>
</context>
<context>
    <name>DialogSecurity</name>
    <message>
        <location filename="../dialogsecurity.ui" line="14"/>
        <source>Security registers</source>
        <translation>Sicherheitsregister</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="24"/>
        <source>Hex Editor</source>
        <translation>Hexadezimal-Editor</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="64"/>
        <source>Operations:</source>
        <translation>Operationen:</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="93"/>
        <source>Reading security register data from the chip</source>
        <translation>Lesen von Sicherheitsregisterdaten aus dem Chip</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="96"/>
        <location filename="../dialogsecurity.ui" line="128"/>
        <location filename="../dialogsecurity.ui" line="160"/>
        <location filename="../dialogsecurity.ui" line="199"/>
        <location filename="../dialogsecurity.ui" line="231"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="125"/>
        <source>Erasing security register data</source>
        <translation>Löschen von Sicherheitsregisterdaten</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="157"/>
        <source>Writing data to the security register</source>
        <translation>Schreiben von Daten in das Sicherheitsregister</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="196"/>
        <source>Open a binary file from a computer</source>
        <translation>Öffnen einer Binärdatei auf einem Computer</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="228"/>
        <source>Save the binary file on the computer</source>
        <translation>Speichern Sie die Binärdatei auf dem Computer</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="257"/>
        <source>Security register number:</source>
        <translation>Nummer des Sicherheitsregisters:</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="173"/>
        <location filename="../dialogsecurity.cpp" line="183"/>
        <location filename="../dialogsecurity.cpp" line="257"/>
        <location filename="../dialogsecurity.cpp" line="294"/>
        <location filename="../dialogsecurity.cpp" line="365"/>
        <location filename="../dialogsecurity.cpp" line="390"/>
        <location filename="../dialogsecurity.cpp" line="423"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="173"/>
        <source>Error reading register!</source>
        <translation>Fehler beim Lesen des Registers!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">Das Programmiergerät CH341a ist nicht angeschlossen!</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="183"/>
        <location filename="../dialogsecurity.cpp" line="294"/>
        <location filename="../dialogsecurity.cpp" line="365"/>
        <source>Programmer </source>
        <translation>Das Programmiergerät </translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="183"/>
        <location filename="../dialogsecurity.cpp" line="294"/>
        <location filename="../dialogsecurity.cpp" line="365"/>
        <source> is not connected!</source>
        <translation> ist nicht angeschlossen!</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="257"/>
        <source>Error writing register!</source>
        <translation>Fehler beim Schreiben des Registers!</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="381"/>
        <source>Open file</source>
        <translation>Datei öffnen</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="390"/>
        <source>The file size exceeds the security register size.</source>
        <translation>Die Dateigröße übersteigt die Größe des Sicherheitsregisters.</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="412"/>
        <source>Save file</source>
        <translation>Datei speichern</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="423"/>
        <source>Error saving file!</source>
        <translation>Fehler beim Speichern der Datei!</translation>
    </message>
</context>
<context>
    <name>DialogSetAddr</name>
    <message>
        <location filename="../dialogsetaddr.ui" line="14"/>
        <source>Goto address</source>
        <translation>Gehe zu Adresse</translation>
    </message>
    <message>
        <location filename="../dialogsetaddr.ui" line="24"/>
        <source>All values in HEX format!</source>
        <translation>Alle Werte im HEX-Format!</translation>
    </message>
    <message>
        <location filename="../dialogsetaddr.ui" line="39"/>
        <source>Address:</source>
        <translation>Adresse:</translation>
    </message>
    <message>
        <location filename="../dialogsetaddr.ui" line="90"/>
        <source>Go to</source>
        <translation>Gehe zu</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="1042"/>
        <source>File</source>
        <translation>Datei</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1155"/>
        <source>Open</source>
        <translation>Öffnen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1158"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1179"/>
        <source>Exit</source>
        <translation>Beenden</translation>
    </message>
    <message>
        <source>Ctrl+X</source>
        <translation type="vanished">Ctrl+X</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1167"/>
        <source>Save</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="29"/>
        <source>IMSProg - I2C/MicroWire/SPI CH341a Programmer</source>
        <translation>IMSProg - I2C/MicroWire/SPI CH341a Programmiergerät</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="77"/>
        <location filename="../mainwindow.ui" line="1060"/>
        <source>Chip</source>
        <translation>Chip</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="171"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="247"/>
        <source>Page size</source>
        <translation>Page Größe</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="285"/>
        <source>Block size</source>
        <translation>Blockgröße</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="323"/>
        <source>VCC, Volt</source>
        <translation>VCC, Volt</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="423"/>
        <source>4byte Addr.</source>
        <translation>4 Byte Adresse</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="572"/>
        <location filename="../mainwindow.ui" line="1191"/>
        <source>Detect</source>
        <translation>Erkennen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="609"/>
        <location filename="../mainwindow.ui" line="1203"/>
        <source>Read</source>
        <translation>Lesen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="411"/>
        <source>i</source>
        <translation>i</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="461"/>
        <source>I2C bus speed</source>
        <translation>I2C-Bus-Geschw.</translation>
    </message>
    <message>
        <source>Erase size</source>
        <translation type="vanished">Löschengröße</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="496"/>
        <source>ECC size</source>
        <translation>ECC Größe:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="682"/>
        <source>Auto Options</source>
        <translation>Auto-Optionen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="699"/>
        <location filename="../mainwindow.ui" line="1215"/>
        <source>Erase</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="719"/>
        <source>Program</source>
        <translation>Schreiben</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="729"/>
        <location filename="../mainwindow.ui" line="1239"/>
        <source>Verify</source>
        <translation>Überprüfen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="784"/>
        <source>Go!</source>
        <translation>Start!</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="823"/>
        <location filename="../mainwindow.ui" line="1075"/>
        <source>Hex Editor</source>
        <translation>Hexadezimal-Editor</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="891"/>
        <source>  JEDEC ID:</source>
        <translation>JEDEC ID:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="907"/>
        <source>CH341a:</source>
        <translation>CH341a:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="938"/>
        <source>border: 2px solid gray;border-radius: 5px;font-weight:600;border-style:inset;</source>
        <translation>border: 2px solid gray;border-radius: 5px;font-weight:600;border-style:inset;</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="951"/>
        <source>CRC32:</source>
        <translation>CRC32:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1010"/>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1097"/>
        <source>Programmer</source>
        <translation>Programmierer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1091"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="618"/>
        <source>Operations</source>
        <translation>Operationen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="709"/>
        <location filename="../mainwindow.ui" line="1495"/>
        <source>Check erase</source>
        <translation>Löschvorgang prüfen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1170"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1194"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1206"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1218"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1227"/>
        <source>Write</source>
        <translation>Schreiben</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1230"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1242"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1251"/>
        <source>Undo</source>
        <translation>Rückgängig machen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1254"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1263"/>
        <source>Redo</source>
        <translation>Wiederholen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1266"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1337"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1376"/>
        <source>Import from Intel HEX</source>
        <translation>Importieren von Intel HEX</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1385"/>
        <source>Export to Intel HEX</source>
        <translation>Exportieren nach Intel HEX</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1394"/>
        <source>Extract from ASUS CAP</source>
        <translation>Auszug aus ASUS CAP</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1403"/>
        <source>Goto address</source>
        <translation>Gehe zu Adresse</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1406"/>
        <source>Move the cursor to the entered address</source>
        <translation>Verschiebe Cursor zu eingegebener Adresse</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1409"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1418"/>
        <source>Security registers</source>
        <translation>Sicherheitsregister</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1421"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1430"/>
        <source>Fill test image</source>
        <translation>Testbild ausfüllen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1433"/>
        <source>Filling the hex editor with a test array</source>
        <translation>Füllen des Hex-Editors mit einem Testbild</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1436"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1445"/>
        <source>Compare files</source>
        <translation>Dateien vergleichen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1448"/>
        <source>Compares the results of the last and penultimate chip read or file open operation</source>
        <translation>Vergleicht die Ergebnisse der letzten und vorletzten Chip-Lese- oder Dateiöffnungsoperation</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1451"/>
        <source>Ctrl+M</source>
        <translation>Ctrl+M</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1460"/>
        <source>Copy</source>
        <translation>Kopieren</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1469"/>
        <source>Paste</source>
        <translation>Einfügen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1478"/>
        <source>Bad block management</source>
        <translation>Verwaltung fehlerhafter Blöcke</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1481"/>
        <source>Ctrl+B</source>
        <translation>Ctrl+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1486"/>
        <source>Show programmer version</source>
        <translation>Programmiererversion anzeigen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1498"/>
        <source>Check erase chip</source>
        <translation>Chip löschen prüfen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1501"/>
        <source>Ctrl+J</source>
        <translation>Ctrl+J</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1510"/>
        <source>Filling with code</source>
        <translation>Mit Code füllen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1513"/>
        <source>Ctrl+K</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1525"/>
        <source>CH341A/B v1.2</source>
        <translation>CH341A/B v1.2</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1533"/>
        <source>CH341A v1.7</source>
        <translation>CH341A v1.7</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1541"/>
        <source>CH347T v1.0</source>
        <translation>CH347T v1.0</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1549"/>
        <source>CH347T v1.1</source>
        <translation>CH347T v1.1</translation>
    </message>
    <message>
        <source>CH347T</source>
        <translation type="vanished">CH347T</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1275"/>
        <source>Save Part</source>
        <translation>Teil speichern</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1287"/>
        <source>Load Part</source>
        <translation>Teil laden</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1299"/>
        <source>Find / Replace</source>
        <translation>Suchen / Ersetzen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1302"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1307"/>
        <source>About</source>
        <translation>Über</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1310"/>
        <source>About IMSProgrammer</source>
        <translation>Über IMSProgrammer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1313"/>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1322"/>
        <source>Checksum calculate</source>
        <translation>Prüfsumme berechnen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1325"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1334"/>
        <source>Edit chips Database</source>
        <translation>Chip-Datenbank bearbeiten</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1182"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1346"/>
        <location filename="../mainwindow.cpp" line="1996"/>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1349"/>
        <source>Forced stop of read, write, erase and verification operations</source>
        <translation>Erzwungener Stopp von Lese-, Schreib-, Lösch- und Prüfvorgängen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1352"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1361"/>
        <source>Chip info</source>
        <translation>Chip-Infos</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1364"/>
        <source>Information about SFDP and status registers</source>
        <translation>Informationen zu SFDP und Statusregistern</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1367"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="937"/>
        <location filename="../mainwindow.cpp" line="980"/>
        <location filename="../mainwindow.cpp" line="1543"/>
        <location filename="../mainwindow.cpp" line="2293"/>
        <location filename="../mainwindow.cpp" line="2369"/>
        <source>Current file: </source>
        <translation>Aktuelle Datei: </translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="83"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="127"/>
        <source>Manufacture</source>
        <translation>Herstellung</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="209"/>
        <source>Size</source>
        <translation>Größe</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2063"/>
        <source>Opening DAT file</source>
        <translation>DAT-Datei öffnen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <location filename="../mainwindow.cpp" line="312"/>
        <location filename="../mainwindow.cpp" line="320"/>
        <location filename="../mainwindow.cpp" line="326"/>
        <location filename="../mainwindow.cpp" line="358"/>
        <location filename="../mainwindow.cpp" line="359"/>
        <location filename="../mainwindow.cpp" line="372"/>
        <location filename="../mainwindow.cpp" line="389"/>
        <location filename="../mainwindow.cpp" line="410"/>
        <location filename="../mainwindow.cpp" line="682"/>
        <location filename="../mainwindow.cpp" line="699"/>
        <location filename="../mainwindow.cpp" line="719"/>
        <location filename="../mainwindow.cpp" line="764"/>
        <location filename="../mainwindow.cpp" line="815"/>
        <location filename="../mainwindow.cpp" line="862"/>
        <location filename="../mainwindow.cpp" line="930"/>
        <location filename="../mainwindow.cpp" line="970"/>
        <location filename="../mainwindow.cpp" line="1051"/>
        <location filename="../mainwindow.cpp" line="1115"/>
        <location filename="../mainwindow.cpp" line="1124"/>
        <location filename="../mainwindow.cpp" line="1131"/>
        <location filename="../mainwindow.cpp" line="1157"/>
        <location filename="../mainwindow.cpp" line="1167"/>
        <location filename="../mainwindow.cpp" line="1340"/>
        <location filename="../mainwindow.cpp" line="1394"/>
        <location filename="../mainwindow.cpp" line="1403"/>
        <location filename="../mainwindow.cpp" line="1409"/>
        <location filename="../mainwindow.cpp" line="1420"/>
        <location filename="../mainwindow.cpp" line="1449"/>
        <location filename="../mainwindow.cpp" line="1450"/>
        <location filename="../mainwindow.cpp" line="1464"/>
        <location filename="../mainwindow.cpp" line="1494"/>
        <location filename="../mainwindow.cpp" line="1499"/>
        <location filename="../mainwindow.cpp" line="1523"/>
        <location filename="../mainwindow.cpp" line="1557"/>
        <location filename="../mainwindow.cpp" line="1865"/>
        <location filename="../mainwindow.cpp" line="2071"/>
        <location filename="../mainwindow.cpp" line="2083"/>
        <location filename="../mainwindow.cpp" line="2243"/>
        <location filename="../mainwindow.cpp" line="2259"/>
        <location filename="../mainwindow.cpp" line="2383"/>
        <location filename="../mainwindow.cpp" line="2415"/>
        <location filename="../mainwindow.cpp" line="2433"/>
        <location filename="../mainwindow.cpp" line="2453"/>
        <location filename="../mainwindow.cpp" line="2585"/>
        <location filename="../mainwindow.cpp" line="2699"/>
        <location filename="../mainwindow.cpp" line="2745"/>
        <location filename="../mainwindow.cpp" line="2797"/>
        <location filename="../mainwindow.cpp" line="2806"/>
        <location filename="../mainwindow.cpp" line="2812"/>
        <location filename="../mainwindow.cpp" line="2823"/>
        <location filename="../mainwindow.cpp" line="2852"/>
        <location filename="../mainwindow.cpp" line="2853"/>
        <location filename="../mainwindow.cpp" line="2866"/>
        <location filename="../mainwindow.cpp" line="2892"/>
        <location filename="../mainwindow.cpp" line="2897"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1494"/>
        <location filename="../mainwindow.cpp" line="2892"/>
        <source>The end address must be greater than the starting address.</source>
        <translation>Die Endadresse muss größer als die Anfangsadresse sein.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1865"/>
        <source>File &apos;IMSProg_editor&apos; not found!</source>
        <translation>Datei `IMSProg_editor` nicht gefunden!</translation>
    </message>
    <message>
        <source>Error loading chip database file!</source>
        <translation type="vanished">Fehler beim Laden der Chipdatenbankdatei!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2089"/>
        <source>Parsing DAT file</source>
        <translation>Parsen einer DAT-Datei</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="277"/>
        <source>Reading data from </source>
        <translation>Lesen von Daten aus </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <location filename="../mainwindow.cpp" line="312"/>
        <location filename="../mainwindow.cpp" line="1051"/>
        <location filename="../mainwindow.cpp" line="1115"/>
        <location filename="../mainwindow.cpp" line="1340"/>
        <location filename="../mainwindow.cpp" line="1394"/>
        <location filename="../mainwindow.cpp" line="2745"/>
        <location filename="../mainwindow.cpp" line="2797"/>
        <source>Unsupported chip type!</source>
        <translation>Nicht unterstützter Chiptyp!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">Das Programmiergerät CH341a ist nicht angeschlossen!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="326"/>
        <location filename="../mainwindow.cpp" line="1409"/>
        <location filename="../mainwindow.cpp" line="2812"/>
        <source>Error reading block </source>
        <translation>Fehler beim Lesen des Blocks </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="358"/>
        <location filename="../mainwindow.cpp" line="1157"/>
        <location filename="../mainwindow.cpp" line="1449"/>
        <location filename="../mainwindow.cpp" line="2852"/>
        <source>Before reading from chip please press &apos;Detect&apos; button.</source>
        <translation>Vor dem Auslesen des Chips bitte die Taste &apos;Erkennen&apos; drücken.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="359"/>
        <source>Please select the chip parameters - manufacture and chip name</source>
        <translation>Bitte Chip-Parameter - Hersteller und Chip-Name auswählen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="410"/>
        <source>The chip is not connect or missing!</source>
        <translation>Der Chip ist nicht angeschlossen oder fehlt!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="669"/>
        <location filename="../mainwindow.cpp" line="2284"/>
        <source>Saving file</source>
        <translation>Speichern der Datei</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="671"/>
        <location filename="../mainwindow.cpp" line="2286"/>
        <source>Save file</source>
        <translation>Datei speichern</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="673"/>
        <location filename="../mainwindow.cpp" line="911"/>
        <source>Data Images</source>
        <translation>Datendateien</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="673"/>
        <location filename="../mainwindow.cpp" line="911"/>
        <location filename="../mainwindow.cpp" line="2288"/>
        <location filename="../mainwindow.cpp" line="2361"/>
        <source>All files</source>
        <translation>Alle Dateien</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="682"/>
        <location filename="../mainwindow.cpp" line="1523"/>
        <source>Error saving file!</source>
        <translation>Fehler beim Speichern der Datei!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="702"/>
        <source>Erasing the </source>
        <translation>Löschen der </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="719"/>
        <location filename="../mainwindow.cpp" line="764"/>
        <location filename="../mainwindow.cpp" line="815"/>
        <location filename="../mainwindow.cpp" line="862"/>
        <source>Error erasing sector </source>
        <translation>Fehler beim Löschen eines Sektors </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="903"/>
        <location filename="../mainwindow.cpp" line="958"/>
        <location filename="../mainwindow.cpp" line="2355"/>
        <source>Opening file</source>
        <translation>Datei öffnen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="909"/>
        <location filename="../mainwindow.cpp" line="962"/>
        <location filename="../mainwindow.cpp" line="2359"/>
        <source>Open file</source>
        <translation>Datei öffnen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="930"/>
        <location filename="../mainwindow.cpp" line="970"/>
        <source>The file size exceeds the chip size. Please select another chip or file or use `Save part` to split the file.</source>
        <translation>Die Dateigröße übersteigt die Chipgröße. Bitte einen anderen Chip oder eine andere Datei wählen, oder &quot;Teil speichern&quot; verwenden, um die Datei zu teilen.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1499"/>
        <location filename="../mainwindow.cpp" line="2897"/>
        <source>The ending address must not exceed the buffer size.</source>
        <translation>Die Endadresse darf die Puffergröße nicht überschreiten.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2070"/>
        <source>Cannot find a chip database file.
You may want to run IMSProg_database_update</source>
        <translation>Die Chip-Datenbankdatei wurde nicht gefunden.
Führen Sie gegebenenfalls IMSProg_database_update aus.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2243"/>
        <source>Before working with the security registers, click the &apos;Detect&apos; button</source>
        <translation>Bevor Sie mit den Sicherheitsregistern arbeiten, klicken Sie auf die Schaltfläche &apos;Detect&apos;.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2259"/>
        <source>There are no security registers in this chip or the current version of IMSProg does not support this algorithm.</source>
        <translation>Es gibt keine Sicherheitsregister in diesem Chip oder die aktuelle Version von IMSProg unterstützt diesen Algorithmus nicht.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2288"/>
        <location filename="../mainwindow.cpp" line="2361"/>
        <source>Intel HEX Images</source>
        <translation>Intel-HEX-Dateien</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2383"/>
        <source>Not valid HEX format!</source>
        <translation>Ungültiges HEX-Format!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2415"/>
        <source>The address is larger than the size of the chip!</source>
        <translation>Die Adresse ist größer als die Größe des Chips!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2433"/>
        <location filename="../mainwindow.cpp" line="2453"/>
        <source>Checksum error!</source>
        <translation>Prüfsummenfehler!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1061"/>
        <source>Writing data to </source>
        <translation>Schreiben von Daten in </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="320"/>
        <location filename="../mainwindow.cpp" line="372"/>
        <location filename="../mainwindow.cpp" line="389"/>
        <location filename="../mainwindow.cpp" line="699"/>
        <location filename="../mainwindow.cpp" line="1124"/>
        <location filename="../mainwindow.cpp" line="1167"/>
        <location filename="../mainwindow.cpp" line="1403"/>
        <location filename="../mainwindow.cpp" line="1464"/>
        <location filename="../mainwindow.cpp" line="2699"/>
        <location filename="../mainwindow.cpp" line="2806"/>
        <location filename="../mainwindow.cpp" line="2866"/>
        <source>Programmer </source>
        <translation>Das Programmiergerät </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="320"/>
        <location filename="../mainwindow.cpp" line="372"/>
        <location filename="../mainwindow.cpp" line="389"/>
        <location filename="../mainwindow.cpp" line="699"/>
        <location filename="../mainwindow.cpp" line="1124"/>
        <location filename="../mainwindow.cpp" line="1167"/>
        <location filename="../mainwindow.cpp" line="1403"/>
        <location filename="../mainwindow.cpp" line="1464"/>
        <location filename="../mainwindow.cpp" line="2699"/>
        <location filename="../mainwindow.cpp" line="2806"/>
        <location filename="../mainwindow.cpp" line="2866"/>
        <source> is not connected!</source>
        <translation> ist nicht angeschlossen!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1131"/>
        <source>Error writing sector </source>
        <translation>Fehler beim Schreiben eines Sektors </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1358"/>
        <source>Veryfing data from </source>
        <translation>Überprüfe Daten aus </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1420"/>
        <source>Error comparing data!
Address:   </source>
        <translation>Fehler beim Vergleichen von Daten!
Adresse:   </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1420"/>
        <source>
Buffer: </source>
        <translation>
Puffer: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1420"/>
        <location filename="../mainwindow.cpp" line="2823"/>
        <source>    Chip: </source>
        <translation>    Chip: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1450"/>
        <location filename="../mainwindow.cpp" line="2585"/>
        <location filename="../mainwindow.cpp" line="2853"/>
        <source>Please select the chip parameters - manufacture and chip name.</source>
        <translation>Bitte Chip-Parameter - Hersteller und Chip-Name auswählen.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1459"/>
        <source>Ok!</source>
        <translation>Ok!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1459"/>
        <source>The operation was successful!</source>
        <translation>Die Operation war Erfolgreich!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1511"/>
        <source>Saving block</source>
        <translation>Speichere Block</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1513"/>
        <source>Save block</source>
        <translation>Block speichern</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1538"/>
        <source>Opening block</source>
        <translation>Eröffnungsblock</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1540"/>
        <source>Open block</source>
        <translation>Offener Block</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1557"/>
        <source>The end address out of image size!</source>
        <translation>Die Endadresse aus der Abbildgröße!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1595"/>
        <source>Connected</source>
        <translation>Verbunden</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1600"/>
        <source>Not connected</source>
        <translation>Nicht verbunden</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1996"/>
        <source>Operation aborted!</source>
        <translation>Operation abgebrochen!</translation>
    </message>
    <message>
        <source>The chip database file was not found!</source>
        <translation type="vanished">Die Chip-Datenbankdatei wurde nicht gefunden!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2079"/>
        <source>Error loading chip database file!
File: %1
Error Code: %2
Reason: %3</source>
        <translation>Fehler beim Laden der Chip-Datenbankdatei!
Datei: %1
Fehlercode: %2
Grund: %3</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2697"/>
        <source>Info:</source>
        <translation>Info:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2697"/>
        <source>Device revision: </source>
        <translation>Geräteversion: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2762"/>
        <source>Erase checking in </source>
        <translation>Löschvorgang in </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2823"/>
        <source>Error erasing chip!
Address:   </source>
        <translation>Fehler beim Löschen des Chips!
Adresse:   </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2823"/>
        <source>
Need: FF</source>
        <translation>
Erforderlich: FF</translation>
    </message>
</context>
<context>
    <name>SearchDialog</name>
    <message>
        <location filename="../searchdialog.ui" line="14"/>
        <source>QHexEdit - Find/Replace</source>
        <translation>QHexEdit - Suchen/Ersetzen</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="26"/>
        <source>Find</source>
        <translation>Finden</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="33"/>
        <location filename="../searchdialog.ui" line="78"/>
        <source>Hex</source>
        <translation>Hex</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="38"/>
        <location filename="../searchdialog.ui" line="83"/>
        <source>UTF-8</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="71"/>
        <source>Replace</source>
        <translation>Ersetze</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="116"/>
        <source>Options</source>
        <translation>Optionen</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="122"/>
        <source>&amp;Backwards</source>
        <translation>Rückwärts</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="129"/>
        <source>&amp;Prompt on replace</source>
        <translation>Aufforderung zum Ersetzen</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="150"/>
        <source>Standard headers:</source>
        <translation>Standard-Header:</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="191"/>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="213"/>
        <source>PNG</source>
        <translation>PNG</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="235"/>
        <source>JPG</source>
        <translation>JPG</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="257"/>
        <source>GIF</source>
        <translation>GIF</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="286"/>
        <source>TAR</source>
        <translation>TAR</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="308"/>
        <source>UEFI</source>
        <translation>UEFI</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="330"/>
        <source>BIOS</source>
        <translation>BIOS</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="352"/>
        <source>GPT</source>
        <translation>GPT</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="385"/>
        <source>&amp;Find</source>
        <translation>Finden</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="388"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="413"/>
        <source>&amp;Replace</source>
        <translation>Ersetzen</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="435"/>
        <source>Replace &amp;All</source>
        <translation>Alle ersetzen</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="457"/>
        <source>&amp;Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../searchdialog.cpp" line="91"/>
        <location filename="../searchdialog.cpp" line="117"/>
        <source>QHexEdit</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../searchdialog.cpp" line="91"/>
        <source>%1 occurrences replaced.</source>
        <translation>%1 Vorkommen ersetzt.</translation>
    </message>
    <message>
        <location filename="../searchdialog.cpp" line="118"/>
        <source>Replace occurrence?</source>
        <translation>Vorkommen ersetzen?</translation>
    </message>
</context>
<context>
    <name>UndoStack</name>
    <message>
        <location filename="../commands.cpp" line="133"/>
        <source>Inserting %1 bytes</source>
        <translation>Einfügen von %1 Bytes</translation>
    </message>
    <message>
        <location filename="../commands.cpp" line="155"/>
        <source>Delete %1 chars</source>
        <translation>Zeichen %1 löschen</translation>
    </message>
    <message>
        <location filename="../commands.cpp" line="180"/>
        <source>Overwrite %1 chars</source>
        <translation>Überschreibe %1 Zeichen</translation>
    </message>
</context>
</TS>
