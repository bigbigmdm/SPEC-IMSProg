<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hu_HU">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../ezp_chip_editor.ui" line="14"/>
        <source>IMSProg chip database editor</source>
        <translation>IMSProg chip-adatbázis szerkesztő</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="53"/>
        <source>File</source>
        <translation>fájl</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="64"/>
        <source>Edit</source>
        <translation>Módosítás</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="108"/>
        <source>Open</source>
        <translation>Megnyitás</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="111"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+M</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="120"/>
        <source>Exit</source>
        <translation>Kilépés</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="123"/>
        <location filename="../ezp_chip_editor.ui" line="216"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="132"/>
        <source>Save</source>
        <translation>Mentés</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="135"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="144"/>
        <source>Delete lines</source>
        <translation>Sorok törlése</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="147"/>
        <source>Delete selected lines</source>
        <translation>Kijelölt sorok törlése</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="150"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="159"/>
        <source>Add line</source>
        <translation>Vonal hozzáadása</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="162"/>
        <source>Add selected lines and duplicate data</source>
        <translation>Kiválasztott sorok hozzáadása és az adat megkettőzése</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="165"/>
        <source>Ins</source>
        <translation>Ins</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="174"/>
        <source>Move up</source>
        <translation>Felfelé mozgat</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="177"/>
        <source>Move lines up</source>
        <translation>Sorok mozgatása felfelé</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="180"/>
        <source>Ctrl+Up</source>
        <translation>Ctrl+Up</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="189"/>
        <source>Move down</source>
        <translation>Lefelé mozgat</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="192"/>
        <source>Move lines down</source>
        <translation>Sorok mozgatása lefelé</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="195"/>
        <source>Ctrl+Down</source>
        <translation>Ctrl+Down</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="204"/>
        <source>Export selected lines to CSV file</source>
        <translation>Kiválasztott sorok exportálása CSV fájlba</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="213"/>
        <source>Export to CSV</source>
        <translation>Exportáls CSV-be</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="225"/>
        <source>Import from CSV</source>
        <translation>Importálás CSV-ből</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="228"/>
        <source>, Ctrl+Shift+X</source>
        <translation>, Ctrl+Shift+X</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="53"/>
        <location filename="../ezp_chip_editor.cpp" line="55"/>
        <location filename="../ezp_chip_editor.cpp" line="746"/>
        <location filename="../ezp_chip_editor.cpp" line="767"/>
        <source>Open the file</source>
        <translation>Fájl megnyitása</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="58"/>
        <location filename="../ezp_chip_editor.cpp" line="711"/>
        <location filename="../ezp_chip_editor.cpp" line="749"/>
        <location filename="../ezp_chip_editor.cpp" line="770"/>
        <source>Current file: </source>
        <translation>Jelenlegi fájl: </translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="82"/>
        <source>Type</source>
        <translation>Típus</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="83"/>
        <source>Manufacturer</source>
        <translation>Manufaktúra</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="84"/>
        <source>IC Name</source>
        <translation>IC Neve</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="85"/>
        <source>JEDEC ID</source>
        <translation>JEDEC ID</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="86"/>
        <source>Size</source>
        <translation>Méret</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="87"/>
        <source>Sector
size</source>
        <translation>Szektor
mérete</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="88"/>
        <source>Type
HEX</source>
        <translation>HEX típusa</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="89"/>
        <source>Algo-
rithm</source>
        <translation>Algo-
rithm</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="90"/>
        <source>Delay</source>
        <translation>Késleltetés</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="91"/>
        <source>4 bit
address</source>
        <translation>4 bites
cím</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="92"/>
        <source>Block
size K</source>
        <translation>Blokkméret K</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="93"/>
        <source>EEPROM
pages</source>
        <translation>EEPROM
lapok</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="94"/>
        <source>VCC</source>
        <translation>VCC</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="542"/>
        <location filename="../ezp_chip_editor.cpp" line="579"/>
        <location filename="../ezp_chip_editor.cpp" line="607"/>
        <location filename="../ezp_chip_editor.cpp" line="646"/>
        <location filename="../ezp_chip_editor.cpp" line="686"/>
        <location filename="../ezp_chip_editor.cpp" line="806"/>
        <location filename="../ezp_chip_editor.cpp" line="840"/>
        <source>Warning</source>
        <translation>Figyelmeztetés</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="542"/>
        <location filename="../ezp_chip_editor.cpp" line="579"/>
        <location filename="../ezp_chip_editor.cpp" line="607"/>
        <location filename="../ezp_chip_editor.cpp" line="646"/>
        <location filename="../ezp_chip_editor.cpp" line="686"/>
        <source>No string selected.</source>
        <translation>Nincs karakterlánc( string) kiválasztva.</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="706"/>
        <source>Saving file</source>
        <translation>Fájl mentése</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="708"/>
        <source>Save file</source>
        <translation>Fájl mentése</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="765"/>
        <source>Opening file</source>
        <translation>Fájl megnyitása</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="806"/>
        <source>Invalid CSV data file format.</source>
        <translation>Érvénytelen CSV adatfájlformátum.</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="840"/>
        <source>Invalid CSV header file format.</source>
        <translation>Érvénytelen CSV fejlécfájlformátum.</translation>
    </message>
</context>
</TS>
