<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../ezp_chip_editor.ui" line="14"/>
        <source>IMSProg chip database editor</source>
        <translation>Editor de banco de dados de chips IMSProg</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="53"/>
        <source>File</source>
        <translation>Arquivo</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="64"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="108"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="111"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="120"/>
        <source>Exit</source>
        <translation>Sair</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="123"/>
        <location filename="../ezp_chip_editor.ui" line="216"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="132"/>
        <source>Save</source>
        <translation>Salvar</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="135"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="144"/>
        <source>Delete lines</source>
        <translation>Deletar linhas</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="147"/>
        <source>Delete selected lines</source>
        <translation>Deletar linhas selecionadas</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="150"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="159"/>
        <source>Add line</source>
        <translation>Adicionar linha</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="162"/>
        <source>Add selected lines and duplicate data</source>
        <translation>Adicionar linhas selecionadas e duplicar dados</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="165"/>
        <source>Ins</source>
        <translation>Ins</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="174"/>
        <source>Move up</source>
        <translation>Mover acima</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="177"/>
        <source>Move lines up</source>
        <translation>Mover linhas acima</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="180"/>
        <source>Ctrl+Up</source>
        <translation>Ctrl+Up</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="189"/>
        <source>Move down</source>
        <translation>Mover abaixo</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="192"/>
        <source>Move lines down</source>
        <translation>Mover linhas abaixo</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="195"/>
        <source>Ctrl+Down</source>
        <translation>Ctrl+Down</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="204"/>
        <source>Export selected lines to CSV file</source>
        <translation>Exportar linhas selecionadas para arquivo CSV</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="213"/>
        <source>Export to CSV</source>
        <translation>Exportar para CSV</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="225"/>
        <source>Import from CSV</source>
        <translation>Importar de CSV</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="228"/>
        <source>, Ctrl+Shift+X</source>
        <translation>, Ctrl+Shift+X</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="53"/>
        <location filename="../ezp_chip_editor.cpp" line="55"/>
        <location filename="../ezp_chip_editor.cpp" line="746"/>
        <location filename="../ezp_chip_editor.cpp" line="767"/>
        <source>Open the file</source>
        <translation>Abrir o arquivo</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="58"/>
        <location filename="../ezp_chip_editor.cpp" line="711"/>
        <location filename="../ezp_chip_editor.cpp" line="749"/>
        <location filename="../ezp_chip_editor.cpp" line="770"/>
        <source>Current file: </source>
        <translation>Arquivo atual: </translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="82"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="83"/>
        <source>Manufacturer</source>
        <translation>Fabricação</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="84"/>
        <source>IC Name</source>
        <translation>Nome IC</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="85"/>
        <source>JEDEC ID</source>
        <translation>JEDEC ID</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="86"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="87"/>
        <source>Sector
size</source>
        <translation>Tamanho
setor</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="88"/>
        <source>Type
HEX</source>
        <translation>Tipo
HEX</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="89"/>
        <source>Algo-
rithm</source>
        <translation>Algo-
ritmo</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="90"/>
        <source>Delay</source>
        <translation>Atraso</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="91"/>
        <source>4 bit
address</source>
        <translation>Endereço
4 bits</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="92"/>
        <source>Block
size K</source>
        <translation>Tamanho
de bloco K</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="93"/>
        <source>EEPROM
pages</source>
        <translation>EEPROM
páginas</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="94"/>
        <source>VCC</source>
        <translation>VCC</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="542"/>
        <location filename="../ezp_chip_editor.cpp" line="579"/>
        <location filename="../ezp_chip_editor.cpp" line="607"/>
        <location filename="../ezp_chip_editor.cpp" line="646"/>
        <location filename="../ezp_chip_editor.cpp" line="686"/>
        <location filename="../ezp_chip_editor.cpp" line="806"/>
        <location filename="../ezp_chip_editor.cpp" line="840"/>
        <source>Warning</source>
        <translation>Advertência</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="542"/>
        <location filename="../ezp_chip_editor.cpp" line="579"/>
        <location filename="../ezp_chip_editor.cpp" line="607"/>
        <location filename="../ezp_chip_editor.cpp" line="646"/>
        <location filename="../ezp_chip_editor.cpp" line="686"/>
        <source>No string selected.</source>
        <translation>Nenhuma sequência selecionada.</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="706"/>
        <source>Saving file</source>
        <translation>Salvando arquivo</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="708"/>
        <source>Save file</source>
        <translation>Salvar arquivo</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="765"/>
        <source>Opening file</source>
        <translation>Abrindo arquivo</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="806"/>
        <source>Invalid CSV data file format.</source>
        <translation>Formato de arquivo de dados CSV inválido.</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="840"/>
        <source>Invalid CSV header file format.</source>
        <translation>Formato de arquivo de cabeçalho CSV inválido.</translation>
    </message>
</context>
</TS>
