<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../ezp_chip_editor.ui" line="14"/>
        <source>IMSProg chip database editor</source>
        <translation>Editor del database dei chip di IMSProg</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="53"/>
        <source>File</source>
        <translation>File</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="64"/>
        <source>Edit</source>
        <translation>Modifica</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="108"/>
        <source>Open</source>
        <translation>Apri</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="111"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="120"/>
        <source>Exit</source>
        <translation>Esci</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="123"/>
        <location filename="../ezp_chip_editor.ui" line="216"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="132"/>
        <source>Save</source>
        <translation>Salva</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="135"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="144"/>
        <source>Delete lines</source>
        <translation>Elimina righe</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="147"/>
        <source>Delete selected lines</source>
        <translation>Elimina righe selezionate</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="150"/>
        <source>Del</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="159"/>
        <source>Add line</source>
        <translation>Aggiungi riga</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="162"/>
        <source>Add selected lines and duplicate data</source>
        <translation>Aggiungi le righe selezionate e duplica i dati</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="165"/>
        <source>Ins</source>
        <translation>Inserisci</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="174"/>
        <source>Move up</source>
        <translation>Sposta su</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="177"/>
        <source>Move lines up</source>
        <translation>Sposta su le righe</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="180"/>
        <source>Ctrl+Up</source>
        <translation>Ctrl+Up</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="189"/>
        <source>Move down</source>
        <translation>Sposta giù</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="192"/>
        <source>Move lines down</source>
        <translation>Sposta giù le righe</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="195"/>
        <source>Ctrl+Down</source>
        <translation>Ctrl+Down</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="204"/>
        <source>Export selected lines to CSV file</source>
        <translation>Esporta le righe selezionate in un file CSV</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="213"/>
        <source>Export to CSV</source>
        <translation>Esporta in CSV</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="225"/>
        <source>Import from CSV</source>
        <translation>Importa da CSV</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.ui" line="228"/>
        <source>, Ctrl+Shift+X</source>
        <translation>, Ctrl+Shift+X</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="53"/>
        <location filename="../ezp_chip_editor.cpp" line="55"/>
        <location filename="../ezp_chip_editor.cpp" line="746"/>
        <location filename="../ezp_chip_editor.cpp" line="767"/>
        <source>Open the file</source>
        <translation>Apri il file</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="58"/>
        <location filename="../ezp_chip_editor.cpp" line="711"/>
        <location filename="../ezp_chip_editor.cpp" line="749"/>
        <location filename="../ezp_chip_editor.cpp" line="770"/>
        <source>Current file: </source>
        <translation>File attuale: </translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="82"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="83"/>
        <source>Manufacturer</source>
        <translation>Produttore</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="84"/>
        <source>IC Name</source>
        <translation>Nome IC</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="85"/>
        <source>JEDEC ID</source>
        <translation>ID JEDEC</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="86"/>
        <source>Size</source>
        <translation>Dimensione</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="89"/>
        <source>Algo-
rithm</source>
        <translation>Algo-
ritmo</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="90"/>
        <source>Delay</source>
        <translation>Ritardo</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="87"/>
        <source>Sector
size</source>
        <translation>Dimensione
settore</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="88"/>
        <source>Type
HEX</source>
        <translation>Tipo
HEX</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="91"/>
        <source>4 bit
address</source>
        <translation>Indirizzo
4 bit</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="92"/>
        <source>Block
size K</source>
        <translation>Dimensione
blocco K</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="93"/>
        <source>EEPROM
pages</source>
        <translation>Pagine
EEPROM</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="94"/>
        <source>VCC</source>
        <translation>VCC</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="542"/>
        <location filename="../ezp_chip_editor.cpp" line="579"/>
        <location filename="../ezp_chip_editor.cpp" line="607"/>
        <location filename="../ezp_chip_editor.cpp" line="646"/>
        <location filename="../ezp_chip_editor.cpp" line="686"/>
        <location filename="../ezp_chip_editor.cpp" line="806"/>
        <location filename="../ezp_chip_editor.cpp" line="840"/>
        <source>Warning</source>
        <translation>Avviso</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="542"/>
        <location filename="../ezp_chip_editor.cpp" line="579"/>
        <location filename="../ezp_chip_editor.cpp" line="607"/>
        <location filename="../ezp_chip_editor.cpp" line="646"/>
        <location filename="../ezp_chip_editor.cpp" line="686"/>
        <source>No string selected.</source>
        <translation>Nessuna stringa selezionata.</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="706"/>
        <source>Saving file</source>
        <translation>Salvataggio del file in corso</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="708"/>
        <source>Save file</source>
        <translation>Salva file</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="765"/>
        <source>Opening file</source>
        <translation>Apertura del file in corso</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="806"/>
        <source>Invalid CSV data file format.</source>
        <translation>Formato del file di dati CSV non valido.</translation>
    </message>
    <message>
        <location filename="../ezp_chip_editor.cpp" line="840"/>
        <source>Invalid CSV header file format.</source>
        <translation>Formato dell’intestazione CSV non valido.</translation>
    </message>
</context>
</TS>
