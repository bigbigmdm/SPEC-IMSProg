<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
<context>
    <name>DialogAbout</name>
    <message>
        <location filename="../dialogabout.ui" line="14"/>
        <source>About IMSProg</source>
        <translation>Informazioni su IMSProg</translation>
    </message>
    <message>
        <source>IMSProg - free software I2C, SPI and MicroWire EEPROM/Flash chip programmer for CH341a devices. IMSProg supports 24Cxx, 25xx, 93Cxx, and M95xx series chips.</source>
        <translation type="vanished">IMSProg è un software libero per EEPROM/Flash chip I2C, SPI e MicroWire per il programmatore CH341a. IMSProg supporta i chip della serie 24Cxx, 25xx, 93Cxx e M95xx.</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="26"/>
        <source>IMSProg - free software I2C, SPI and MicroWire EEPROM/Flash chip programmer for CH341A and CH347T devices. IMSProg supports 24Cxx, 25xx, 93Cxx, AT45DBxx and M95xx series chips.</source>
        <translation>IMSProg - è un software gratuito per la programmazione di chip I2C, SPI e MicroWire EEPROM/Flash da utilizzare con i dispositivi CH341A e CH347T. IMSProg supporta i chip delle serie 24Cxx, 25xx, 93Cxx e M95xx.</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="90"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;In this program &lt;a href=&quot;https://github.com/Simsys/qhexedit2/&quot;&gt;QhexEditor2&lt;/a&gt; widget and modified programmer &lt;a href=&quot;https://github.com/McMCCRU/SNANDer&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;SNANDer&lt;/span&gt;&lt;/a&gt; were used.&lt;/p&gt;&lt;p&gt;The page on GitHub is &lt;a href=&quot;https://github.com/bigbigmdm/IMSProg&quot;&gt;here&lt;/a&gt;, the support page is &lt;a href=&quot;https://antenna-dvb-t2.ru/IMSProg.php&quot;&gt;here&lt;/a&gt;. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;In questo programma si usa il widget &lt;a href=&quot;https://github.com/Simsys/qhexedit2/&quot;&gt;QhexEditor2&lt;/a&gt; ed il software &lt;a href=&quot;https://github.com/McMCCRU/SNANDer&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;SNANDer&lt;/span&gt;&lt;/a&gt; modificato.&lt;/p&gt;&lt;p&gt;La pagina GitHub è &lt;a href=&quot;https://github.com/bigbigmdm/IMSProg&quot;&gt;qui&lt;/a&gt;, la pagina di supporto è &lt;a href=&quot;https://antenna-dvb-t2.ru/IMSProg.php&quot;&gt;qui&lt;/a&gt;. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="119"/>
        <source>Written by 2023 - 2026 Mikhail Medvedev</source>
        <translation>Scritto da Mikhail Medvedev nel 2023 -2026</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="140"/>
        <source>Version: </source>
        <translation>Versione: </translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="150"/>
        <source>1.1.4</source>
        <translation>1.1.4</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="48"/>
        <location filename="../dialogabout.ui" line="68"/>
        <source>OR</source>
        <translation>OPPURE</translation>
    </message>
    <message>
        <source>IMSProg - free software I2C, SPI and MicroWire EEPROM/Flash chip programmer for CH341a devices. IMSProg supports 24Cxx, 25xx, 93Cxx, AT45DBxx and M95xx series chips.</source>
        <translation type="vanished">IMSProg - è un software gratuito per la programmazione di chip I2C, SPI e MicroWire EEPROM/Flash da utilizzare con i dispositivi CH341a. IMSProg supporta i chip delle serie 24Cxx, 25xx, 93Cxx e M95xx.</translation>
    </message>
    <message>
        <source>Written by 2023 Mikhail Medvedev</source>
        <translation type="vanished">Scritto da Mikhail Medvedev nel 2023</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="189"/>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
</context>
<context>
    <name>DialogBBM</name>
    <message>
        <location filename="../dialogbbm.ui" line="20"/>
        <source>Bad block management</source>
        <translation>Gestione dei blocchi danneggiati</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="34"/>
        <source>Chip scan</source>
        <translation>Scansione del chip</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="69"/>
        <location filename="../dialogbbm.ui" line="285"/>
        <source>No</source>
        <translation>Numero</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="77"/>
        <source>Block</source>
        <translation>Blocco</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="85"/>
        <source>Start address</source>
        <translation>Indirizzo iniziale</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="93"/>
        <source>End address</source>
        <translation>Indirizzo finale</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="137"/>
        <source>Check</source>
        <translation>Controlla</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="147"/>
        <source>Settings</source>
        <translation>Impostazioni</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="167"/>
        <source>Erasing</source>
        <translation>Cancella</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="173"/>
        <source>Skip bad blocks during erase procedure  (recommended)</source>
        <translation>Ignora i blocchi danneggiati (consigliato)</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="180"/>
        <source>Don&apos;t skip bad blocks</source>
        <translation>Non ignorare i blocchi danneggiati</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="190"/>
        <source>Writing</source>
        <translation>Scrittura</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="196"/>
        <source>Write all blocks one to one (ignore bad blocks)</source>
        <translation>Scrivi tutti i blocchi uno a uno (ignora danneggiati)</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="203"/>
        <source>Skip bad blocks during writing procedure</source>
        <translation>Ignora i blocchi danneggiati durante la procedura di scrittura</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="256"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="268"/>
        <source>BBM table (Winbond)</source>
        <translation>Tabella BBM (Winbond)</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="274"/>
        <source>This operation is used only in some Winbond chips.</source>
        <translation>Questa operazione viene utilizzata solo in alcuni chip Winbond.</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="290"/>
        <source>Bad block</source>
        <translation>Blocco danneggiato</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="295"/>
        <source>Changed block</source>
        <translation>Blocco modificato</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="300"/>
        <source>Status</source>
        <translation>Stato</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="348"/>
        <source>Read</source>
        <translation>Leggi</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="81"/>
        <location filename="../dialogbbm.cpp" line="93"/>
        <location filename="../dialogbbm.cpp" line="164"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="81"/>
        <source>Error reading chip!</source>
        <translation>Si è verificato un errore durante la lettura del chip!</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="85"/>
        <source>Corrupted blocks found:</source>
        <translation>Blocchi danneggiati trovati:</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="86"/>
        <source>All blocks in the chip are good!</source>
        <translation>Tutti i blocchi nel chip sono integri!</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="93"/>
        <location filename="../dialogbbm.cpp" line="164"/>
        <source>Programmer </source>
        <translation>Il programmatore </translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="93"/>
        <location filename="../dialogbbm.cpp" line="164"/>
        <source> is not connected!</source>
        <translation> non è connesso!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">Il programmatore CH341a non è collegato!</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="154"/>
        <source>Not used</source>
        <translation>Non utilizzato</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="155"/>
        <source>Active, valid</source>
        <translation>Attivo, valido</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="156"/>
        <source>Active, not valid</source>
        <translation>Attivo, non valido</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="161"/>
        <source>BBM table is not used in this chip.</source>
        <translation>La tabella BBM non è utilizzata in questo chip.</translation>
    </message>
</context>
<context>
    <name>DialogCompare</name>
    <message>
        <location filename="../dialogcompare.ui" line="14"/>
        <source>Comparing files:</source>
        <translation>Confronto dei file:</translation>
    </message>
    <message>
        <location filename="../dialogcompare.ui" line="68"/>
        <source>CRC32: </source>
        <translation>CRC32: </translation>
    </message>
    <message>
        <location filename="../dialogcompare.ui" line="100"/>
        <location filename="../dialogcompare.ui" line="187"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../dialogcompare.ui" line="155"/>
        <source>CRC32:</source>
        <translation>CRC32:</translation>
    </message>
    <message>
        <location filename="../dialogcompare.ui" line="201"/>
        <source>Visible ASCII areas</source>
        <translation>Aree ASCII visibili</translation>
    </message>
    <message>
        <location filename="../dialogcompare.cpp" line="110"/>
        <location filename="../dialogcompare.cpp" line="111"/>
        <source>Name: </source>
        <translation>Nome: </translation>
    </message>
</context>
<context>
    <name>DialogFill</name>
    <message>
        <location filename="../dialogfill.ui" line="14"/>
        <source>Fill the buffer with code</source>
        <translation>Riempi il buffer con il codice</translation>
    </message>
    <message>
        <location filename="../dialogfill.ui" line="27"/>
        <source>All values in HEX format!</source>
        <translation>Tutti i valori devono essere in formato HEX!</translation>
    </message>
    <message>
        <location filename="../dialogfill.ui" line="42"/>
        <source>Start address:</source>
        <translation>Indirizzo di partenza:</translation>
    </message>
    <message>
        <location filename="../dialogfill.ui" line="91"/>
        <source>Filling code:</source>
        <translation>Codice di riempimento:</translation>
    </message>
    <message>
        <location filename="../dialogfill.ui" line="130"/>
        <source>Fill</source>
        <translation>Riempi</translation>
    </message>
    <message>
        <location filename="../dialogfill.cpp" line="36"/>
        <source>End address</source>
        <translation>Indirizzo finale</translation>
    </message>
    <message>
        <location filename="../dialogfill.cpp" line="37"/>
        <source>Length</source>
        <translation>Lunghezza</translation>
    </message>
</context>
<context>
    <name>DialogInfo</name>
    <message>
        <location filename="../dialoginfo.ui" line="14"/>
        <source>Connection info:</source>
        <translation>Informazioni connessione:</translation>
    </message>
    <message>
        <location filename="../dialoginfo.ui" line="36"/>
        <source>Slot:</source>
        <translation>Slot:</translation>
    </message>
    <message>
        <location filename="../dialoginfo.ui" line="43"/>
        <location filename="../dialoginfo.ui" line="61"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../dialoginfo.ui" line="54"/>
        <source>Adapter:</source>
        <translation>Adattatore:</translation>
    </message>
    <message>
        <location filename="../dialoginfo.ui" line="106"/>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
</context>
<context>
    <name>DialogNANDSr</name>
    <message>
        <location filename="../dialognandsr.ui" line="20"/>
        <source>Status registers</source>
        <translation>Registri di stato</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="37"/>
        <source>Status register 1</source>
        <translation>Registro di stato 1</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="318"/>
        <source>SRP0</source>
        <translation>SRP0</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="349"/>
        <source>BP3</source>
        <translation>BP3</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="380"/>
        <source>BP2</source>
        <translation>BP2</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="411"/>
        <source>BP1</source>
        <translation>BP1</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="442"/>
        <source>BP0</source>
        <translation>BP0</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="473"/>
        <source>TB</source>
        <translation>TB</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="504"/>
        <source>WP-E</source>
        <translation>WP-E</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="535"/>
        <source>SRP1</source>
        <translation>SRP1</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="552"/>
        <source>Status register 2</source>
        <translation>Registro di stato 2</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="824"/>
        <source>OTP-L</source>
        <translation>OTP-L</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="852"/>
        <source>OTP-E</source>
        <translation>OTP-E</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="880"/>
        <source>SR1-L</source>
        <translation>SR1-L</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="908"/>
        <source>ECC-E</source>
        <translation>ECC-E</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="936"/>
        <source>BUF</source>
        <translation>BUF</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="964"/>
        <location filename="../dialognandsr.ui" line="992"/>
        <location filename="../dialognandsr.ui" line="1020"/>
        <location filename="../dialognandsr.ui" line="1309"/>
        <source>(R)</source>
        <translation>(R)</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1040"/>
        <source>Status register 3</source>
        <translation>Registro di stato 3</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1337"/>
        <source>LUT-F</source>
        <translation>LUT-F</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1365"/>
        <source>ECC-1</source>
        <translation>ECC-1</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1393"/>
        <source>ECC-0</source>
        <translation>ECC-0</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1421"/>
        <source>P-FAIL</source>
        <translation>P-FAIL</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1449"/>
        <source>WELL</source>
        <translation>WELL</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1477"/>
        <source>BUSY</source>
        <translation>BUSY</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1505"/>
        <source>E_FAIL</source>
        <translation>E_FAIL</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1522"/>
        <source>Status register 4</source>
        <translation>Registro di stato 4</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1785"/>
        <location filename="../dialognandsr.ui" line="1813"/>
        <location filename="../dialognandsr.ui" line="1841"/>
        <location filename="../dialognandsr.ui" line="1869"/>
        <location filename="../dialognandsr.ui" line="1897"/>
        <location filename="../dialognandsr.ui" line="1925"/>
        <location filename="../dialognandsr.ui" line="1953"/>
        <location filename="../dialognandsr.ui" line="1981"/>
        <location filename="../dialognandsr.ui" line="2261"/>
        <location filename="../dialognandsr.ui" line="2289"/>
        <location filename="../dialognandsr.ui" line="2317"/>
        <location filename="../dialognandsr.ui" line="2345"/>
        <location filename="../dialognandsr.ui" line="2373"/>
        <location filename="../dialognandsr.ui" line="2401"/>
        <location filename="../dialognandsr.ui" line="2429"/>
        <location filename="../dialognandsr.ui" line="2457"/>
        <source>---</source>
        <translation>---</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1998"/>
        <source>Status register 5</source>
        <translation>Registro di stato 5</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2482"/>
        <source>Unique ID:</source>
        <translation>ID univoco:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2538"/>
        <source>Read</source>
        <translation>Leggi</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2564"/>
        <source>Write</source>
        <translation>Scrivi</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2580"/>
        <source>Parameter page:</source>
        <translation>Pagina dei parametri:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2608"/>
        <source>Manufacturer:</source>
        <translation>Produttore:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2618"/>
        <source>Model:</source>
        <translation>Modello:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2628"/>
        <source>Page size:</source>
        <translation>Dimensione pagina:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2635"/>
        <source>ECC size:</source>
        <translation>Dimensione ECC:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2648"/>
        <source>Pages per block:</source>
        <translation>Pagine per blocco:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2655"/>
        <source>Block per unit:</source>
        <translation>Blocchi per unità:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2662"/>
        <source>Block size:</source>
        <translation>Dimensione blocco:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2678"/>
        <source>Chip size:</source>
        <translation>Dimensione chip:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="102"/>
        <location filename="../dialognandsr.cpp" line="166"/>
        <location filename="../dialognandsr.cpp" line="266"/>
        <location filename="../dialognandsr.cpp" line="309"/>
        <location filename="../dialognandsr.cpp" line="365"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="102"/>
        <source>Error reading register!</source>
        <translation>Si è verificato un errore durante la lettura del registro!</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="166"/>
        <source>Error reading Parameter Page!</source>
        <translation>Si è verificato un errore durante la lettura della pagina dei parametri!</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="248"/>
        <source>The Parameter Page is not supported.</source>
        <translation>La pagina dei parametri non è supportata.</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="266"/>
        <source>Error reading ID!</source>
        <translation>Si è verificato un errore durante la lettura dell&apos;ID!</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="309"/>
        <location filename="../dialognandsr.cpp" line="365"/>
        <source>Programmer </source>
        <translation>Il programmatore </translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="309"/>
        <location filename="../dialognandsr.cpp" line="365"/>
        <source> is not connected!</source>
        <translation> non è connesso!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">Il programmatore CH341a non è collegato!</translation>
    </message>
</context>
<context>
    <name>DialogNandSecurity</name>
    <message>
        <location filename="../dialognandsecurity.ui" line="14"/>
        <source>Security registers</source>
        <translation>Registri di sicurezza</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="24"/>
        <source>Hex Editor</source>
        <translation>Editor esadecimale</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="64"/>
        <source>Operations:</source>
        <translation>Operazioni:</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="93"/>
        <source>Reading security register data from the chip</source>
        <translation>Lettura dal chip dei dati del registro di sicurezza</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="96"/>
        <location filename="../dialognandsecurity.ui" line="128"/>
        <location filename="../dialognandsecurity.ui" line="167"/>
        <location filename="../dialognandsecurity.ui" line="199"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="125"/>
        <source>Writing data to the security register</source>
        <translation>Scrittura di dati nel registro di sicurezza</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="164"/>
        <source>Open a binary file from a computer</source>
        <translation>Apri un file binario da un computer</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="196"/>
        <source>Save the binary file on the computer</source>
        <translation>Salva un file binario su un computer</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="225"/>
        <source>Security register number:</source>
        <translation>Numero del registro di sicurezza:</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="79"/>
        <location filename="../dialognandsecurity.cpp" line="119"/>
        <location filename="../dialognandsecurity.cpp" line="214"/>
        <location filename="../dialognandsecurity.cpp" line="232"/>
        <location filename="../dialognandsecurity.cpp" line="265"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="79"/>
        <source>Error reading Parameter Page!</source>
        <translation>Si è verificato un errore durante la lettura della pagina dei parametri!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">Il programmatore CH341a non è collegato!</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="119"/>
        <location filename="../dialognandsecurity.cpp" line="214"/>
        <source>Programmer </source>
        <translation>Il programmatore </translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="119"/>
        <location filename="../dialognandsecurity.cpp" line="214"/>
        <source> is not connected!</source>
        <translation> non è connesso!</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="223"/>
        <source>Open file</source>
        <translation>Apri file</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="232"/>
        <source>The file size exceeds the security register size.</source>
        <translation>La dimensione del file supera la dimensione del registro di sicurezza.</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="254"/>
        <source>Save file</source>
        <translation>Salva file</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="265"/>
        <source>Error saving file!</source>
        <translation>Si è verificato un errore durante il salvataggio del file!</translation>
    </message>
</context>
<context>
    <name>DialogRP</name>
    <message>
        <location filename="../dialogrp.ui" line="20"/>
        <source>Load block from file</source>
        <translation>Carica blocco da file</translation>
    </message>
    <message>
        <location filename="../dialogrp.ui" line="33"/>
        <source>All values in HEX format!</source>
        <translation>Tutti i valori devono essere in formato HEX!</translation>
    </message>
    <message>
        <location filename="../dialogrp.ui" line="48"/>
        <source>Start address:</source>
        <translation>Indirizzo di partenza:</translation>
    </message>
    <message>
        <location filename="../dialogrp.ui" line="112"/>
        <source>Load</source>
        <translation>Carica</translation>
    </message>
</context>
<context>
    <name>DialogSFDP</name>
    <message>
        <location filename="../dialogsfdp.ui" line="14"/>
        <source>Information about SFDP and status registers</source>
        <translation>Informazioni sul SFDP e sui registri di stato</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="47"/>
        <source>SFDP support:</source>
        <translation>Supporto SFDP:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="67"/>
        <source>Minimum VCC:</source>
        <translation>VCC minima:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="87"/>
        <source>Maximum VCC:</source>
        <translation>VCC massima:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="107"/>
        <source>Chip size:</source>
        <translation>Dimensione chip:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="127"/>
        <source>Block size:</source>
        <translation>Dimensione blocco:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="150"/>
        <source>Speeds:</source>
        <translation>Velocità:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="170"/>
        <source>OTP support:</source>
        <translation>Supporto OTP:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="196"/>
        <source>Status Register 0</source>
        <translation>Registro di stato 0</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="424"/>
        <source>SPR0</source>
        <translation>SPR0</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="449"/>
        <source>BP4</source>
        <translation>BP4</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="474"/>
        <source>BP3</source>
        <translation>BP3</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="499"/>
        <source>BP2</source>
        <translation>BP2</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="524"/>
        <source>BP1</source>
        <translation>BP1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="549"/>
        <source>BP0</source>
        <translation>BP0</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="574"/>
        <source>WEL</source>
        <translation>WEL</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="599"/>
        <source>WIP</source>
        <translation>WIP</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="830"/>
        <source>SUS1</source>
        <translation>SUS1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="855"/>
        <source>CMP</source>
        <translation>CMP</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="880"/>
        <source>LB3</source>
        <translation>LB3</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="905"/>
        <source>LB2</source>
        <translation>LB2</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="930"/>
        <source>LB1</source>
        <translation>LB1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="955"/>
        <source>SUS2</source>
        <translation>SUS2</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="980"/>
        <source>QE</source>
        <translation>QE</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1005"/>
        <source>SPR1</source>
        <translation>SPR1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="611"/>
        <source>Status Register 1</source>
        <translation>Registro di stato 1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1017"/>
        <source>Status register 2</source>
        <translation>Registro di stato 2</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1195"/>
        <source>JEDEC info:</source>
        <translation>Info JEDEC:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1301"/>
        <source>Man. ID</source>
        <translation>ID Prod</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1323"/>
        <source>Man. type</source>
        <translation>Tipo prod</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1345"/>
        <source>Capacity</source>
        <translation>Dimensione</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1357"/>
        <source>Unique ID:</source>
        <translation>ID univoco:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1398"/>
        <source>Read</source>
        <translation>Leggi</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1426"/>
        <source>Write registers</source>
        <translation>Scrivi registri</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1453"/>
        <location filename="../dialogsfdp.ui" line="1519"/>
        <location filename="../dialogsfdp.ui" line="1541"/>
        <source>(R)</source>
        <translation>(R)</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1475"/>
        <source>DRV1</source>
        <translation>DRV1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1497"/>
        <source>DRV0</source>
        <translation>DRV0</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1563"/>
        <source>WPS</source>
        <translation>WPS</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1585"/>
        <source>ADP</source>
        <translation>ADP</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1607"/>
        <source>ADS</source>
        <translation>ADS</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1693"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p/&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p/&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1731"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Legend:&lt;/p&gt;&lt;p&gt;** - Basic area&lt;br&gt;** - Extended area&lt;br&gt;** - Manufacture area &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;body&gt;&lt;p&gt;Legenda:&lt;/p&gt;&lt;p&gt;** - Area base&lt;br&gt;** - Area estesa&lt;br&gt;** - Area produttore&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1776"/>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="84"/>
        <location filename="../dialogsfdp.cpp" line="104"/>
        <location filename="../dialogsfdp.cpp" line="213"/>
        <location filename="../dialogsfdp.cpp" line="226"/>
        <location filename="../dialogsfdp.cpp" line="245"/>
        <location filename="../dialogsfdp.cpp" line="267"/>
        <location filename="../dialogsfdp.cpp" line="282"/>
        <location filename="../dialogsfdp.cpp" line="435"/>
        <location filename="../dialogsfdp.cpp" line="439"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="104"/>
        <location filename="../dialogsfdp.cpp" line="213"/>
        <location filename="../dialogsfdp.cpp" line="226"/>
        <location filename="../dialogsfdp.cpp" line="245"/>
        <source>Error reading register!</source>
        <translation>Si è verificato un errore durante la lettura del registro!</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="176"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt; Hex SFDP register data:
</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt; Dati HEX del registro SFDP:
</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="177"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Addr:&lt;br&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Indirizzo:&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="282"/>
        <location filename="../dialogsfdp.cpp" line="435"/>
        <source>Programmer </source>
        <translation>Il programmatore </translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="282"/>
        <location filename="../dialogsfdp.cpp" line="435"/>
        <source> is not connected!</source>
        <translation> non è connesso!</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="439"/>
        <source>Before writing the registers, please press the `Read` button!</source>
        <translation>Prima di scrivere i registri, premi il pulsante `Leggi`!</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="84"/>
        <source>Error reading JEDEC ID!</source>
        <translation>Si è verificato un errore durante la lettura dell&apos;ID JEDEC!</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="44"/>
        <source>Legend:</source>
        <translation>Legenda:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="45"/>
        <source> - Basic area</source>
        <translation> - Area base</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="46"/>
        <source> - Extended area</source>
        <translation> - Area estesa</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="47"/>
        <source> - Manufacture area</source>
        <translation> - Area produttore</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="267"/>
        <source>Error reading unique ID!</source>
        <translation>Si è verificato un errore durante la lettura dell&apos;ID unico!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">Il programmatore CH341a non è connesso!</translation>
    </message>
</context>
<context>
    <name>DialogSP</name>
    <message>
        <location filename="../dialogsp.ui" line="14"/>
        <source>Save part of image</source>
        <translation>Salva parte dell&apos;immagine</translation>
    </message>
    <message>
        <location filename="../dialogsp.ui" line="27"/>
        <source>All values in HEX format!</source>
        <translation>Tutti i valori devono essere in formato HEX!</translation>
    </message>
    <message>
        <location filename="../dialogsp.ui" line="42"/>
        <source>Start address:</source>
        <translation>Indirizzo di partenza:</translation>
    </message>
    <message>
        <location filename="../dialogsp.ui" line="120"/>
        <source>Save</source>
        <translation>Salva</translation>
    </message>
    <message>
        <location filename="../dialogsp.cpp" line="28"/>
        <source>End address</source>
        <translation>Indirizzo finale</translation>
    </message>
    <message>
        <location filename="../dialogsp.cpp" line="29"/>
        <source>Length</source>
        <translation>Lunghezza</translation>
    </message>
</context>
<context>
    <name>DialogSR</name>
    <message>
        <location filename="../dialogsr.ui" line="14"/>
        <source>Status register</source>
        <translatorcomment>Il programmatore CH341a non e&apos; connesso</translatorcomment>
        <translation>Registro di stato</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="296"/>
        <source>WPEN</source>
        <translation>WPEN</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="327"/>
        <location filename="../dialogsr.ui" line="358"/>
        <location filename="../dialogsr.ui" line="389"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="420"/>
        <source>BP1</source>
        <translation>BP1</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="451"/>
        <source>BP0</source>
        <translation>BP0</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="482"/>
        <source>WEN</source>
        <translation>WEN</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="513"/>
        <source>/RDY</source>
        <translation>/RDY</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="545"/>
        <source>Read</source>
        <translation>Leggi</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="571"/>
        <source>Write</source>
        <translation>Scrivi</translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="57"/>
        <location filename="../dialogsr.cpp" line="71"/>
        <location filename="../dialogsr.cpp" line="110"/>
        <location filename="../dialogsr.cpp" line="113"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="57"/>
        <source>Error reading register!</source>
        <translation>Si è verificato un errore durante la lettura del registro!</translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="71"/>
        <location filename="../dialogsr.cpp" line="113"/>
        <source>Programmer </source>
        <translation>Il programmatore </translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="71"/>
        <location filename="../dialogsr.cpp" line="113"/>
        <source> is not connected!</source>
        <translation> non è connesso!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">Il programmatore CH341a non è connesso!</translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="110"/>
        <source>Before writing the register, please press the `Read` button!</source>
        <translation>Prima di scrivere il registro, premi il pulsante `Leggi`!</translation>
    </message>
</context>
<context>
    <name>DialogSecurity</name>
    <message>
        <location filename="../dialogsecurity.ui" line="14"/>
        <source>Security registers</source>
        <translation>Registri di sicurezza</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="24"/>
        <source>Hex Editor</source>
        <translation>Editor esadecimale</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="64"/>
        <source>Operations:</source>
        <translation>Operazioni:</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="93"/>
        <source>Reading security register data from the chip</source>
        <translation>Lettura dei dati dei registri di sicurezza dal chip</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="96"/>
        <location filename="../dialogsecurity.ui" line="128"/>
        <location filename="../dialogsecurity.ui" line="160"/>
        <location filename="../dialogsecurity.ui" line="199"/>
        <location filename="../dialogsecurity.ui" line="231"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="125"/>
        <source>Erasing security register data</source>
        <translation>Cancellazione dei dati dei registri di sicurezza</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="157"/>
        <source>Writing data to the security register</source>
        <translation>Scrittura dei dati nel registro di sicurezza</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="196"/>
        <source>Open a binary file from a computer</source>
        <translation>Apri un file binario da un computer</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="228"/>
        <source>Save the binary file on the computer</source>
        <translation>Salva un file binario su un computer</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="257"/>
        <source>Security register number:</source>
        <translation>Numero del registro di sicurezza:</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="173"/>
        <location filename="../dialogsecurity.cpp" line="183"/>
        <location filename="../dialogsecurity.cpp" line="257"/>
        <location filename="../dialogsecurity.cpp" line="294"/>
        <location filename="../dialogsecurity.cpp" line="365"/>
        <location filename="../dialogsecurity.cpp" line="390"/>
        <location filename="../dialogsecurity.cpp" line="423"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="173"/>
        <source>Error reading register!</source>
        <translation>Si è verificato un errore durante la lettura del registro!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">Il programmatore CH341a non è connesso!</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="183"/>
        <location filename="../dialogsecurity.cpp" line="294"/>
        <location filename="../dialogsecurity.cpp" line="365"/>
        <source>Programmer </source>
        <translation>Il programmatore </translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="183"/>
        <location filename="../dialogsecurity.cpp" line="294"/>
        <location filename="../dialogsecurity.cpp" line="365"/>
        <source> is not connected!</source>
        <translation> non è connesso!</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="257"/>
        <source>Error writing register!</source>
        <translation>Si è verificato un errore durante la scrittura del registro!</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="381"/>
        <source>Open file</source>
        <translation>Apri file</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="390"/>
        <source>The file size exceeds the security register size.</source>
        <translation>La dimensione del file supera la dimensione del registro di sicurezza.</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="412"/>
        <source>Save file</source>
        <translation>Salva file</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="423"/>
        <source>Error saving file!</source>
        <translation>Si è verificato un errore durante il salvataggio del file!</translation>
    </message>
</context>
<context>
    <name>DialogSetAddr</name>
    <message>
        <location filename="../dialogsetaddr.ui" line="14"/>
        <source>Goto address</source>
        <translation>Vai all&apos;indirizzo</translation>
    </message>
    <message>
        <location filename="../dialogsetaddr.ui" line="24"/>
        <source>All values in HEX format!</source>
        <translation>Tutti i valori devono essere in formato HEX!</translation>
    </message>
    <message>
        <location filename="../dialogsetaddr.ui" line="39"/>
        <source>Address:</source>
        <translation>Indirizzo:</translation>
    </message>
    <message>
        <location filename="../dialogsetaddr.ui" line="90"/>
        <source>Go to</source>
        <translation>Vai</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="1042"/>
        <source>File</source>
        <translation>File</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1155"/>
        <source>Open</source>
        <translation>Apri</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1158"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1179"/>
        <source>Exit</source>
        <translation>Esci</translation>
    </message>
    <message>
        <source>Ctrl+X</source>
        <translation type="vanished">Ctrl+X</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1167"/>
        <source>Save</source>
        <translation>Salva</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="29"/>
        <source>IMSProg - I2C/MicroWire/SPI CH341a Programmer</source>
        <translation>IMSProg - programatore I2C/MicroWire/SPI CH341a</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="77"/>
        <location filename="../mainwindow.ui" line="1060"/>
        <source>Chip</source>
        <translation>Chip</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="171"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="247"/>
        <source>Page size</source>
        <translation>Dim. pagina</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="285"/>
        <source>Block size</source>
        <translation>Dim. blocco</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="323"/>
        <source>VCC, Volt</source>
        <translation>VCC, volt</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="423"/>
        <source>4byte Addr.</source>
        <translation>4byte Indir.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="572"/>
        <location filename="../mainwindow.ui" line="1191"/>
        <source>Detect</source>
        <translation>Rileva</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="609"/>
        <location filename="../mainwindow.ui" line="1203"/>
        <source>Read</source>
        <translation>Leggi</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="411"/>
        <source>i</source>
        <translation>i</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="461"/>
        <source>I2C bus speed</source>
        <translation>Velocità bus I2C</translation>
    </message>
    <message>
        <source>Erase size</source>
        <translation type="vanished">Dimensione cancel.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="496"/>
        <source>ECC size</source>
        <translation>Dimensione ECC</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="682"/>
        <source>Auto Options</source>
        <translation>Opzioni automatiche</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="699"/>
        <location filename="../mainwindow.ui" line="1215"/>
        <source>Erase</source>
        <translation>Cancella</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="719"/>
        <source>Program</source>
        <translation>Programma</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="729"/>
        <location filename="../mainwindow.ui" line="1239"/>
        <source>Verify</source>
        <translation>Verifica</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="784"/>
        <source>Go!</source>
        <translation>Vai!</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="823"/>
        <location filename="../mainwindow.ui" line="1075"/>
        <source>Hex Editor</source>
        <translation>Editor esadecimale</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="891"/>
        <source>  JEDEC ID:</source>
        <translation>  JEDEC ID:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="907"/>
        <source>CH341a:</source>
        <translation>CH341a:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="938"/>
        <source>border: 2px solid gray;border-radius: 5px;font-weight:600;border-style:inset;</source>
        <translation>border: 2px solid gray;border-radius: 5px;font-weight:600;border-style:inset;</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="951"/>
        <source>CRC32:</source>
        <translation>CRC32:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1010"/>
        <source>Message</source>
        <translation>Messaggio</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1097"/>
        <source>Programmer</source>
        <translation>Programmatore</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1091"/>
        <source>Help</source>
        <translation>Aiuto</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="618"/>
        <source>Operations</source>
        <translation>Operazioni</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="709"/>
        <location filename="../mainwindow.ui" line="1495"/>
        <source>Check erase</source>
        <translation>Verifica cancellazione</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1170"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1194"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1206"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1218"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1227"/>
        <source>Write</source>
        <translation>Scrivi</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1230"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1242"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1251"/>
        <source>Undo</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1254"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1263"/>
        <source>Redo</source>
        <translation>Ripristina</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1266"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1337"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1376"/>
        <source>Import from Intel HEX</source>
        <translation>Importa da Intel HEX</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1385"/>
        <source>Export to Intel HEX</source>
        <translation>Esporta in Intel HEX</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1394"/>
        <source>Extract from ASUS CAP</source>
        <translation>Estrai dal CAP di ASUS</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1403"/>
        <source>Goto address</source>
        <translation>Vai all&apos;indirizzo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1406"/>
        <source>Move the cursor to the entered address</source>
        <translation>Sposta il cursore all&apos;indirizzo inserito</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1409"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1418"/>
        <source>Security registers</source>
        <translation>Registri di sicurezza</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1421"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1430"/>
        <source>Fill test image</source>
        <translation>Riempi l&apos;immagine di prova</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1433"/>
        <source>Filling the hex editor with a test array</source>
        <translation>Riempi l&apos;editor esadecimale con una matrice di prova</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1436"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1445"/>
        <source>Compare files</source>
        <translation>Confronta i file</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1448"/>
        <source>Compares the results of the last and penultimate chip read or file open operation</source>
        <translation>Confronta i risultati dell’ultima e della penultima operazione di lettura del chip o di apertura del file</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1451"/>
        <source>Ctrl+M</source>
        <translation>Ctrl+M</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1460"/>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1469"/>
        <source>Paste</source>
        <translation>Incolla</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1478"/>
        <source>Bad block management</source>
        <translation>Gestione dei blocchi danneggiati</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1481"/>
        <source>Ctrl+B</source>
        <translation>Ctrl+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1486"/>
        <source>Show programmer version</source>
        <translation>Mostra versione del programma</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1498"/>
        <source>Check erase chip</source>
        <translation>Verifica la cancellazione del chip</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1501"/>
        <source>Ctrl+J</source>
        <translation>Ctrl+J</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1510"/>
        <source>Filling with code</source>
        <translation>Riempimento con codice</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1513"/>
        <source>Ctrl+K</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1525"/>
        <source>CH341A/B v1.2</source>
        <translation>CH341A/B v1.2</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1533"/>
        <source>CH341A v1.7</source>
        <translation>CH341A v1.7</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1541"/>
        <source>CH347T v1.0</source>
        <translation>CH347T v1.0</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1549"/>
        <source>CH347T v1.1</source>
        <translation>CH347T v1.1</translation>
    </message>
    <message>
        <source>CH347T</source>
        <translation type="vanished">CH347T</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1275"/>
        <source>Save Part</source>
        <translation>Salva parte</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1287"/>
        <source>Load Part</source>
        <translation>Carica parte</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1299"/>
        <source>Find / Replace</source>
        <translation>Trova / Sostituisci</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1302"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1307"/>
        <source>About</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1310"/>
        <source>About IMSProgrammer</source>
        <translation>Informazioni su IMSProgrammer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1313"/>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1322"/>
        <source>Checksum calculate</source>
        <translation>Calcola checksum</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1325"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1334"/>
        <source>Edit chips Database</source>
        <translation>Modifica il database dei chip</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1182"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1346"/>
        <location filename="../mainwindow.cpp" line="1997"/>
        <source>Stop</source>
        <translation>Ferma</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1349"/>
        <source>Forced stop of read, write, erase and verification operations</source>
        <translation>Arresto forzato delle operazioni di lettura, scrittura, cancellazione e verifica</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1352"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1361"/>
        <source>Chip info</source>
        <translation>Informazioni sul chip</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1364"/>
        <source>Information about SFDP and status registers</source>
        <translation>Informazioni su SFDP e registri di stato</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1367"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="937"/>
        <location filename="../mainwindow.cpp" line="980"/>
        <location filename="../mainwindow.cpp" line="1541"/>
        <location filename="../mainwindow.cpp" line="2296"/>
        <location filename="../mainwindow.cpp" line="2372"/>
        <source>Current file: </source>
        <translation>File attuale: </translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="83"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="127"/>
        <source>Manufacture</source>
        <translation>Produttore</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="209"/>
        <source>Size</source>
        <translation>Dimensione</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2066"/>
        <source>Opening DAT file</source>
        <translation>Apertura in corso del file DAT</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <location filename="../mainwindow.cpp" line="312"/>
        <location filename="../mainwindow.cpp" line="320"/>
        <location filename="../mainwindow.cpp" line="326"/>
        <location filename="../mainwindow.cpp" line="358"/>
        <location filename="../mainwindow.cpp" line="359"/>
        <location filename="../mainwindow.cpp" line="372"/>
        <location filename="../mainwindow.cpp" line="389"/>
        <location filename="../mainwindow.cpp" line="410"/>
        <location filename="../mainwindow.cpp" line="682"/>
        <location filename="../mainwindow.cpp" line="699"/>
        <location filename="../mainwindow.cpp" line="719"/>
        <location filename="../mainwindow.cpp" line="764"/>
        <location filename="../mainwindow.cpp" line="815"/>
        <location filename="../mainwindow.cpp" line="862"/>
        <location filename="../mainwindow.cpp" line="930"/>
        <location filename="../mainwindow.cpp" line="970"/>
        <location filename="../mainwindow.cpp" line="1051"/>
        <location filename="../mainwindow.cpp" line="1115"/>
        <location filename="../mainwindow.cpp" line="1124"/>
        <location filename="../mainwindow.cpp" line="1131"/>
        <location filename="../mainwindow.cpp" line="1157"/>
        <location filename="../mainwindow.cpp" line="1167"/>
        <location filename="../mainwindow.cpp" line="1338"/>
        <location filename="../mainwindow.cpp" line="1392"/>
        <location filename="../mainwindow.cpp" line="1401"/>
        <location filename="../mainwindow.cpp" line="1407"/>
        <location filename="../mainwindow.cpp" line="1418"/>
        <location filename="../mainwindow.cpp" line="1447"/>
        <location filename="../mainwindow.cpp" line="1448"/>
        <location filename="../mainwindow.cpp" line="1462"/>
        <location filename="../mainwindow.cpp" line="1492"/>
        <location filename="../mainwindow.cpp" line="1497"/>
        <location filename="../mainwindow.cpp" line="1521"/>
        <location filename="../mainwindow.cpp" line="1555"/>
        <location filename="../mainwindow.cpp" line="1866"/>
        <location filename="../mainwindow.cpp" line="2074"/>
        <location filename="../mainwindow.cpp" line="2086"/>
        <location filename="../mainwindow.cpp" line="2246"/>
        <location filename="../mainwindow.cpp" line="2262"/>
        <location filename="../mainwindow.cpp" line="2386"/>
        <location filename="../mainwindow.cpp" line="2418"/>
        <location filename="../mainwindow.cpp" line="2436"/>
        <location filename="../mainwindow.cpp" line="2456"/>
        <location filename="../mainwindow.cpp" line="2588"/>
        <location filename="../mainwindow.cpp" line="2702"/>
        <location filename="../mainwindow.cpp" line="2748"/>
        <location filename="../mainwindow.cpp" line="2800"/>
        <location filename="../mainwindow.cpp" line="2809"/>
        <location filename="../mainwindow.cpp" line="2815"/>
        <location filename="../mainwindow.cpp" line="2826"/>
        <location filename="../mainwindow.cpp" line="2855"/>
        <location filename="../mainwindow.cpp" line="2856"/>
        <location filename="../mainwindow.cpp" line="2869"/>
        <location filename="../mainwindow.cpp" line="2895"/>
        <location filename="../mainwindow.cpp" line="2900"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1492"/>
        <location filename="../mainwindow.cpp" line="2895"/>
        <source>The end address must be greater than the starting address.</source>
        <translation>L&apos;indirizzo finale deve essere maggiore dell&apos;indirizzo iniziale.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1866"/>
        <source>File &apos;IMSProg_editor&apos; not found!</source>
        <translation>&apos;IMSProg_editor&apos; non è stato trovato!</translation>
    </message>
    <message>
        <source>Error loading chip database file!</source>
        <translation type="vanished">Si è verificato un errore durante l&apos;apertura del database dei chip!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2092"/>
        <source>Parsing DAT file</source>
        <translation>Analisi archivio DAT in corso</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="277"/>
        <source>Reading data from </source>
        <translation>Lettura dati in corso da </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <location filename="../mainwindow.cpp" line="312"/>
        <location filename="../mainwindow.cpp" line="1051"/>
        <location filename="../mainwindow.cpp" line="1115"/>
        <location filename="../mainwindow.cpp" line="1338"/>
        <location filename="../mainwindow.cpp" line="1392"/>
        <location filename="../mainwindow.cpp" line="2748"/>
        <location filename="../mainwindow.cpp" line="2800"/>
        <source>Unsupported chip type!</source>
        <translation>Chip non supportato!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">Il programatore CH341a non è connesso!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="326"/>
        <location filename="../mainwindow.cpp" line="1407"/>
        <location filename="../mainwindow.cpp" line="2815"/>
        <source>Error reading block </source>
        <translation>Si è verificato un errore durante la lettura del blocco </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="358"/>
        <location filename="../mainwindow.cpp" line="1157"/>
        <location filename="../mainwindow.cpp" line="1447"/>
        <location filename="../mainwindow.cpp" line="2855"/>
        <source>Before reading from chip please press &apos;Detect&apos; button.</source>
        <translation>Prima di leggere il chip, premere il pulsante &apos;Rileva&apos;.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="359"/>
        <source>Please select the chip parameters - manufacture and chip name</source>
        <translation>Seleziona i parametri del chip: produttore e nome del chip</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="410"/>
        <source>The chip is not connect or missing!</source>
        <translation>Il chip non è collegato oppure è mancante!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="669"/>
        <location filename="../mainwindow.cpp" line="2287"/>
        <source>Saving file</source>
        <translation>Salvataggio file in corso</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="671"/>
        <location filename="../mainwindow.cpp" line="2289"/>
        <source>Save file</source>
        <translation>Salva file</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="673"/>
        <location filename="../mainwindow.cpp" line="911"/>
        <source>Data Images</source>
        <translation>File di dati</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="673"/>
        <location filename="../mainwindow.cpp" line="911"/>
        <location filename="../mainwindow.cpp" line="2291"/>
        <location filename="../mainwindow.cpp" line="2364"/>
        <source>All files</source>
        <translation>Tutti i file</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="682"/>
        <location filename="../mainwindow.cpp" line="1521"/>
        <source>Error saving file!</source>
        <translation>Si è verificato un errore durante il salvataggio del file!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="702"/>
        <source>Erasing the </source>
        <translation>Cancellazione in corso di </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="719"/>
        <location filename="../mainwindow.cpp" line="764"/>
        <location filename="../mainwindow.cpp" line="815"/>
        <location filename="../mainwindow.cpp" line="862"/>
        <source>Error erasing sector </source>
        <translation>Si è verificato un errore durante la cancellazione del settore </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="903"/>
        <location filename="../mainwindow.cpp" line="958"/>
        <location filename="../mainwindow.cpp" line="2358"/>
        <source>Opening file</source>
        <translation>Apertura del file in corso</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="909"/>
        <location filename="../mainwindow.cpp" line="962"/>
        <location filename="../mainwindow.cpp" line="2362"/>
        <source>Open file</source>
        <translation>Apri file</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="930"/>
        <location filename="../mainwindow.cpp" line="970"/>
        <source>The file size exceeds the chip size. Please select another chip or file or use `Save part` to split the file.</source>
        <translation>La dimensione del file supera quella del chip. Selezionare un altro chip o un altro file oppure utilizzare `Salva parte` per dividere il file.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1497"/>
        <location filename="../mainwindow.cpp" line="2900"/>
        <source>The ending address must not exceed the buffer size.</source>
        <translation>L&apos;indirizzo finale non deve superare la dimensione del buffer.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2073"/>
        <source>Cannot find a chip database file.
You may want to run IMSProg_database_update</source>
        <translation>Impossibile trovare un file del database dei chip.
Si consiglia di eseguire IMSProg_database_update</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2246"/>
        <source>Before working with the security registers, click the &apos;Detect&apos; button</source>
        <translation>Prima di lavorare con i registri di sicurezza, fai clic sul pulsante &apos;Rileva&apos;</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2262"/>
        <source>There are no security registers in this chip or the current version of IMSProg does not support this algorithm.</source>
        <translation>Non ci sono registri di sicurezza in questo chip o la versione attuale di IMSProg non supporta questo algoritmo.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2291"/>
        <location filename="../mainwindow.cpp" line="2364"/>
        <source>Intel HEX Images</source>
        <translation>File Intel HEX</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2386"/>
        <source>Not valid HEX format!</source>
        <translation>Formato HEX non valido!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2418"/>
        <source>The address is larger than the size of the chip!</source>
        <translation>L&apos;indirizzo è più grande della dimensione del chip!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2436"/>
        <location filename="../mainwindow.cpp" line="2456"/>
        <source>Checksum error!</source>
        <translation>Si è verificato un errore di checksum!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1061"/>
        <source>Writing data to </source>
        <translation>Scrittura dati in corso su </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="320"/>
        <location filename="../mainwindow.cpp" line="372"/>
        <location filename="../mainwindow.cpp" line="389"/>
        <location filename="../mainwindow.cpp" line="699"/>
        <location filename="../mainwindow.cpp" line="1124"/>
        <location filename="../mainwindow.cpp" line="1167"/>
        <location filename="../mainwindow.cpp" line="1401"/>
        <location filename="../mainwindow.cpp" line="1462"/>
        <location filename="../mainwindow.cpp" line="2702"/>
        <location filename="../mainwindow.cpp" line="2809"/>
        <location filename="../mainwindow.cpp" line="2869"/>
        <source>Programmer </source>
        <translation>Il programmatore </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="320"/>
        <location filename="../mainwindow.cpp" line="372"/>
        <location filename="../mainwindow.cpp" line="389"/>
        <location filename="../mainwindow.cpp" line="699"/>
        <location filename="../mainwindow.cpp" line="1124"/>
        <location filename="../mainwindow.cpp" line="1167"/>
        <location filename="../mainwindow.cpp" line="1401"/>
        <location filename="../mainwindow.cpp" line="1462"/>
        <location filename="../mainwindow.cpp" line="2702"/>
        <location filename="../mainwindow.cpp" line="2809"/>
        <location filename="../mainwindow.cpp" line="2869"/>
        <source> is not connected!</source>
        <translation> non è connesso!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1131"/>
        <source>Error writing sector </source>
        <translation>Si è verificato un errore durante la scrittura del settore </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1356"/>
        <source>Veryfing data from </source>
        <translation>Verifica dati in corso da </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1418"/>
        <source>Error comparing data!
Address:   </source>
        <translation>Si è verificato un errore durante il confronto dei dati!
Indirizzo:   </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1418"/>
        <source>
Buffer: </source>
        <translation>
Buffer: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1418"/>
        <location filename="../mainwindow.cpp" line="2826"/>
        <source>    Chip: </source>
        <translation>    Chip: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1448"/>
        <location filename="../mainwindow.cpp" line="2588"/>
        <location filename="../mainwindow.cpp" line="2856"/>
        <source>Please select the chip parameters - manufacture and chip name.</source>
        <translation>Seleziona i parametri del chip: produttore e nome del chip.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1457"/>
        <source>Ok!</source>
        <translation>Ok!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1457"/>
        <source>The operation was successful!</source>
        <translation>Operazione completata!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1509"/>
        <source>Saving block</source>
        <translation>Salvataggio del blocco in corso</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1511"/>
        <source>Save block</source>
        <translation>Salva blocco</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1536"/>
        <source>Opening block</source>
        <translation>Apertura del blocco in corso</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1538"/>
        <source>Open block</source>
        <translation>Apri blocco</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1555"/>
        <source>The end address out of image size!</source>
        <translation>L’indirizzo finale supera la dimensione dell’immagine!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1593"/>
        <source>Connected</source>
        <translation>Connesso</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1598"/>
        <source>Not connected</source>
        <translation>Non connesso</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1997"/>
        <source>Operation aborted!</source>
        <translation>L&apos;operazione è stata annullata!</translation>
    </message>
    <message>
        <source>The chip database file was not found!</source>
        <translation type="vanished">Il file del database dei chip non è stato trovato!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2082"/>
        <source>Error loading chip database file!
File: %1
Error Code: %2
Reason: %3</source>
        <translation>Errore durante il caricamento del file del database dei chip!
File: %1
Codice errore: %2
Motivo: %3</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2700"/>
        <source>Info:</source>
        <translation>Informazioni:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2700"/>
        <source>Device revision: </source>
        <translation>Revisione del dispositivo: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2765"/>
        <source>Erase checking in </source>
        <translation>Verifica cancellazione in </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2826"/>
        <source>Error erasing chip!
Address:   </source>
        <translation>Errore durante la cancellazione del chip!
Indirizzo:   </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2826"/>
        <source>
Need: FF</source>
        <translation>
Richiesto: FF</translation>
    </message>
</context>
<context>
    <name>SearchDialog</name>
    <message>
        <location filename="../searchdialog.ui" line="14"/>
        <source>QHexEdit - Find/Replace</source>
        <translation>QHexEdit - Trova/Sostituisci</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="26"/>
        <source>Find</source>
        <translation>Trova</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="33"/>
        <location filename="../searchdialog.ui" line="78"/>
        <source>Hex</source>
        <translation>Hex</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="38"/>
        <location filename="../searchdialog.ui" line="83"/>
        <source>UTF-8</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="71"/>
        <source>Replace</source>
        <translation>Sostituisci</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="116"/>
        <source>Options</source>
        <translation>Opzioni</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="122"/>
        <source>&amp;Backwards</source>
        <translation>&amp;Indietro</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="129"/>
        <source>&amp;Prompt on replace</source>
        <translation>&amp;Chiedi conferma prima di sostituire</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="150"/>
        <source>Standard headers:</source>
        <translation>Header standard:</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="191"/>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="213"/>
        <source>PNG</source>
        <translation>PNG</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="235"/>
        <source>JPG</source>
        <translation>JPG</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="257"/>
        <source>GIF</source>
        <translation>GIF</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="286"/>
        <source>TAR</source>
        <translation>TAR</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="308"/>
        <source>UEFI</source>
        <translation>UEFI</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="330"/>
        <source>BIOS</source>
        <translation>BIOS</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="352"/>
        <source>GPT</source>
        <translation>GPT</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="385"/>
        <source>&amp;Find</source>
        <translation>&amp;Trova</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="388"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="413"/>
        <source>&amp;Replace</source>
        <translation>&amp;Sostituisci</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="435"/>
        <source>Replace &amp;All</source>
        <translation>S&amp;ostituisci tutto</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="457"/>
        <source>&amp;Close</source>
        <translation>&amp;Chiudi</translation>
    </message>
    <message>
        <location filename="../searchdialog.cpp" line="91"/>
        <location filename="../searchdialog.cpp" line="117"/>
        <source>QHexEdit</source>
        <translation>QHexEdit</translation>
    </message>
    <message>
        <location filename="../searchdialog.cpp" line="91"/>
        <source>%1 occurrences replaced.</source>
        <translation>%1 occorrenze sostituite.</translation>
    </message>
    <message>
        <location filename="../searchdialog.cpp" line="118"/>
        <source>Replace occurrence?</source>
        <translation>Sostituire occorrenza?</translation>
    </message>
</context>
<context>
    <name>UndoStack</name>
    <message>
        <location filename="../commands.cpp" line="133"/>
        <source>Inserting %1 bytes</source>
        <translation>Inserimento in corso di %1 byte</translation>
    </message>
    <message>
        <location filename="../commands.cpp" line="155"/>
        <source>Delete %1 chars</source>
        <translation>Eliminati %1 caratteri</translation>
    </message>
    <message>
        <location filename="../commands.cpp" line="180"/>
        <source>Overwrite %1 chars</source>
        <translation>Sovrascritti %1 caratteri</translation>
    </message>
</context>
</TS>
