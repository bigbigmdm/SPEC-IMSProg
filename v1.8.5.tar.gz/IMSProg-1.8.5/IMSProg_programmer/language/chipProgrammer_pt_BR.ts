<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_BR">
<context>
    <name>DialogAbout</name>
    <message>
        <location filename="../dialogabout.ui" line="14"/>
        <source>About IMSProg</source>
        <translation>Sobre IMSProg</translation>
    </message>
    <message>
        <source>IMSProg - free software I2C, SPI and MicroWire EEPROM/Flash chip programmer for CH341a devices. IMSProg supports 24Cxx, 25xx, 93Cxx, and M95xx series chips.</source>
        <translation type="vanished">IMSProg - software livre I2C, SPI e MicroWire EEPROM/Flash chip programador para dispositivos CH341a. IMSProg admite chips das séries 24Cxx, 25xx, 93Cxx e M95xx.</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="26"/>
        <source>IMSProg - free software I2C, SPI and MicroWire EEPROM/Flash chip programmer for CH341A and CH347T devices. IMSProg supports 24Cxx, 25xx, 93Cxx, AT45DBxx and M95xx series chips.</source>
        <translation>IMSProg - software livre I2C, SPI e MicroWire EEPROM/Flash chip programador para dispositivos CH341A e CH347T. IMSProg suporta chips das séries 24Cxx, 25xx, 93Cxx, AT45DBxx e M95xx.</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="90"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;In this program &lt;a href=&quot;https://github.com/Simsys/qhexedit2/&quot;&gt;QhexEditor2&lt;/a&gt; widget and modified programmer &lt;a href=&quot;https://github.com/McMCCRU/SNANDer&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;SNANDer&lt;/span&gt;&lt;/a&gt; were used.&lt;/p&gt;&lt;p&gt;The page on GitHub is &lt;a href=&quot;https://github.com/bigbigmdm/IMSProg&quot;&gt;here&lt;/a&gt;, the support page is &lt;a href=&quot;https://antenna-dvb-t2.ru/IMSProg.php&quot;&gt;here&lt;/a&gt;. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Neste programa utilizou-se o widget &lt;a href=&quot;https://github.com/Simsys/qhexedit2/&quot;&gt;QhexEditor2&lt;/a&gt; e o programador &lt;a href=&quot;https://github.com/McMCCRU/SNANDer&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;SNANDer&lt;/span&gt;&lt;/a&gt; modificado.&lt;/p&gt;&lt;p&gt;A página do GitHub está &lt;a href=&quot;https://github.com/bigbigmdm/IMSProg&quot;&gt;aqui&lt;/a&gt;, e a página de suporte está &lt;a href=&quot;https://antenna-dvb-t2.ru/IMSProg.php&quot;&gt;aqui&lt;/a&gt;. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="119"/>
        <source>Written by 2023 - 2026 Mikhail Medvedev</source>
        <translation>Escrito por Mikhail Medvedev 2023 - 2026</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="140"/>
        <source>Version: </source>
        <translation>Versão: </translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="150"/>
        <source>1.1.4</source>
        <translation>1.1.4</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="48"/>
        <location filename="../dialogabout.ui" line="68"/>
        <source>OR</source>
        <translation>OU</translation>
    </message>
    <message>
        <source>IMSProg - free software I2C, SPI and MicroWire EEPROM/Flash chip programmer for CH341a devices. IMSProg supports 24Cxx, 25xx, 93Cxx, AT45DBxx and M95xx series chips.</source>
        <translation type="vanished">IMSProg - software livre I2C, SPI e MicroWire EEPROM/Flash chip programador para dispositivos CH341a. IMSProg suporta chips das séries 24Cxx, 25xx, 93Cxx, AT45DBxx e M95xx.</translation>
    </message>
    <message>
        <source>Written by 2023 Mikhail Medvedev</source>
        <translation type="vanished">Escrito por Mikhail Medvedev 2023</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="189"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
</context>
<context>
    <name>DialogBBM</name>
    <message>
        <location filename="../dialogbbm.ui" line="20"/>
        <source>Bad block management</source>
        <translation>Gerenciamento de blocos defeituosos</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="34"/>
        <source>Chip scan</source>
        <translation>Leitura do chip</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="69"/>
        <location filename="../dialogbbm.ui" line="285"/>
        <source>No</source>
        <translation>Número</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="77"/>
        <source>Block</source>
        <translation>Bloco</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="85"/>
        <source>Start address</source>
        <translation>Endereço inicial</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="93"/>
        <source>End address</source>
        <translation>Endereço final</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="137"/>
        <source>Check</source>
        <translation>Verificar</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="147"/>
        <source>Settings</source>
        <translation>Configurações</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="167"/>
        <source>Erasing</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="173"/>
        <source>Skip bad blocks during erase procedure  (recommended)</source>
        <translation>Ignorar blocos defeituosos (recomendado)</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="180"/>
        <source>Don&apos;t skip bad blocks</source>
        <translation>Não ignore blocos defeituosos</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="190"/>
        <source>Writing</source>
        <translation>Programar</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="196"/>
        <source>Write all blocks one to one (ignore bad blocks)</source>
        <translation>Grave todos os blocos um a um (ignore os blocos defeituosos)</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="203"/>
        <source>Skip bad blocks during writing procedure</source>
        <translation>Ignorar blocos danificados durante a gravação</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="256"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="268"/>
        <source>BBM table (Winbond)</source>
        <translation>Tabela BBM (Winbond)</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="274"/>
        <source>This operation is used only in some Winbond chips.</source>
        <translation>Esta operação é utilizada apenas em alguns chips Winbond.</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="290"/>
        <source>Bad block</source>
        <translation>Bloco defeituoso</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="295"/>
        <source>Changed block</source>
        <translation>Bloco alterado</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="300"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="348"/>
        <source>Read</source>
        <translation>Ler</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="81"/>
        <location filename="../dialogbbm.cpp" line="93"/>
        <location filename="../dialogbbm.cpp" line="164"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="81"/>
        <source>Error reading chip!</source>
        <translation>Erro ao ler o chip!</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="85"/>
        <source>Corrupted blocks found:</source>
        <translation>Blocos corrompidos encontrados:</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="86"/>
        <source>All blocks in the chip are good!</source>
        <translation>Todos os blocos do chip estão em bom estado!</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="93"/>
        <location filename="../dialogbbm.cpp" line="164"/>
        <source>Programmer </source>
        <translation>Programador </translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="93"/>
        <location filename="../dialogbbm.cpp" line="164"/>
        <source> is not connected!</source>
        <translation> não está conectado!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">O programador CH341a não está conectado!</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="154"/>
        <source>Not used</source>
        <translation>Não utilizado</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="155"/>
        <source>Active, valid</source>
        <translation>Ativo, válido</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="156"/>
        <source>Active, not valid</source>
        <translation>Ativo, não válido</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="161"/>
        <source>BBM table is not used in this chip.</source>
        <translation>A tabela BBM não é utilizada neste chip.</translation>
    </message>
</context>
<context>
    <name>DialogCompare</name>
    <message>
        <location filename="../dialogcompare.ui" line="14"/>
        <source>Comparing files:</source>
        <translation>Comparação de arquivos:</translation>
    </message>
    <message>
        <location filename="../dialogcompare.ui" line="68"/>
        <source>CRC32: </source>
        <translation>CRC32: </translation>
    </message>
    <message>
        <location filename="../dialogcompare.ui" line="100"/>
        <location filename="../dialogcompare.ui" line="187"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../dialogcompare.ui" line="155"/>
        <source>CRC32:</source>
        <translation>CRC32:</translation>
    </message>
    <message>
        <location filename="../dialogcompare.ui" line="201"/>
        <source>Visible ASCII areas</source>
        <translation>Mostrar áreas ASCII</translation>
    </message>
    <message>
        <location filename="../dialogcompare.cpp" line="110"/>
        <location filename="../dialogcompare.cpp" line="111"/>
        <source>Name: </source>
        <translation>Nome:</translation>
    </message>
</context>
<context>
    <name>DialogFill</name>
    <message>
        <location filename="../dialogfill.ui" line="14"/>
        <source>Fill the buffer with code</source>
        <translation> Preencha o buffer com código</translation>
    </message>
    <message>
        <location filename="../dialogfill.ui" line="27"/>
        <source>All values in HEX format!</source>
        <translation>Todos os valores em formato HEX!</translation>
    </message>
    <message>
        <location filename="../dialogfill.ui" line="42"/>
        <source>Start address:</source>
        <translation>Endereço de início:</translation>
    </message>
    <message>
        <location filename="../dialogfill.ui" line="91"/>
        <source>Filling code:</source>
        <translation>Preenchimento código:</translation>
    </message>
    <message>
        <location filename="../dialogfill.ui" line="130"/>
        <source>Fill</source>
        <translation>Preencher</translation>
    </message>
    <message>
        <location filename="../dialogfill.cpp" line="36"/>
        <source>End address</source>
        <translation>Endereço final</translation>
    </message>
    <message>
        <location filename="../dialogfill.cpp" line="37"/>
        <source>Length</source>
        <translation>Comprimento</translation>
    </message>
</context>
<context>
    <name>DialogInfo</name>
    <message>
        <location filename="../dialoginfo.ui" line="14"/>
        <source>Connection info:</source>
        <translation>Informação de conexão:</translation>
    </message>
    <message>
        <location filename="../dialoginfo.ui" line="36"/>
        <source>Slot:</source>
        <translation>Slot:</translation>
    </message>
    <message>
        <location filename="../dialoginfo.ui" line="43"/>
        <location filename="../dialoginfo.ui" line="61"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../dialoginfo.ui" line="54"/>
        <source>Adapter:</source>
        <translation>Adaptador:</translation>
    </message>
    <message>
        <location filename="../dialoginfo.ui" line="106"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
</context>
<context>
    <name>DialogNANDSr</name>
    <message>
        <location filename="../dialognandsr.ui" line="20"/>
        <source>Status registers</source>
        <translation>Registros de status</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="37"/>
        <source>Status register 1</source>
        <translation>Registro de status 1</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="318"/>
        <source>SRP0</source>
        <translation>SRP0</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="349"/>
        <source>BP3</source>
        <translation>BP3</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="380"/>
        <source>BP2</source>
        <translation>BP2</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="411"/>
        <source>BP1</source>
        <translation>BP1</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="442"/>
        <source>BP0</source>
        <translation>BP0</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="473"/>
        <source>TB</source>
        <translation>TB</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="504"/>
        <source>WP-E</source>
        <translation>WP-E</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="535"/>
        <source>SRP1</source>
        <translation>SRP1</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="552"/>
        <source>Status register 2</source>
        <translation>Registro de status 2</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="824"/>
        <source>OTP-L</source>
        <translation>OTP-L</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="852"/>
        <source>OTP-E</source>
        <translation>OTP-E</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="880"/>
        <source>SR1-L</source>
        <translation>SR1-L</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="908"/>
        <source>ECC-E</source>
        <translation>ECC-E</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="936"/>
        <source>BUF</source>
        <translation>BUF</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="964"/>
        <location filename="../dialognandsr.ui" line="992"/>
        <location filename="../dialognandsr.ui" line="1020"/>
        <location filename="../dialognandsr.ui" line="1309"/>
        <source>(R)</source>
        <translation>(R)</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1040"/>
        <source>Status register 3</source>
        <translation>Registro de status 3</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1337"/>
        <source>LUT-F</source>
        <translation>LUT-F</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1365"/>
        <source>ECC-1</source>
        <translation>ECC-1</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1393"/>
        <source>ECC-0</source>
        <translation>ECC-0</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1421"/>
        <source>P-FAIL</source>
        <translation>P-FAIL</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1449"/>
        <source>WELL</source>
        <translation>WELL</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1477"/>
        <source>BUSY</source>
        <translation>BUSY</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1505"/>
        <source>E_FAIL</source>
        <translation>E_FAIL</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1522"/>
        <source>Status register 4</source>
        <translation>Registro de status 4</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1785"/>
        <location filename="../dialognandsr.ui" line="1813"/>
        <location filename="../dialognandsr.ui" line="1841"/>
        <location filename="../dialognandsr.ui" line="1869"/>
        <location filename="../dialognandsr.ui" line="1897"/>
        <location filename="../dialognandsr.ui" line="1925"/>
        <location filename="../dialognandsr.ui" line="1953"/>
        <location filename="../dialognandsr.ui" line="1981"/>
        <location filename="../dialognandsr.ui" line="2261"/>
        <location filename="../dialognandsr.ui" line="2289"/>
        <location filename="../dialognandsr.ui" line="2317"/>
        <location filename="../dialognandsr.ui" line="2345"/>
        <location filename="../dialognandsr.ui" line="2373"/>
        <location filename="../dialognandsr.ui" line="2401"/>
        <location filename="../dialognandsr.ui" line="2429"/>
        <location filename="../dialognandsr.ui" line="2457"/>
        <source>---</source>
        <translation>---</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1998"/>
        <source>Status register 5</source>
        <translation>Registro de status 5</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2482"/>
        <source>Unique ID:</source>
        <translation>ID único:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2538"/>
        <source>Read</source>
        <translation>Ler</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2564"/>
        <source>Write</source>
        <translation>Programar</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2580"/>
        <source>Parameter page:</source>
        <translation>Página de parâmetros:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2608"/>
        <source>Manufacturer:</source>
        <translation>Fabricante:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2618"/>
        <source>Model:</source>
        <translation>Modelo:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2628"/>
        <source>Page size:</source>
        <translation>Tamanho de página:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2635"/>
        <source>ECC size:</source>
        <translation>Tamanho ECC:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2648"/>
        <source>Pages per block:</source>
        <translation>Páginas por bloco:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2655"/>
        <source>Block per unit:</source>
        <translation>Bloco por unidade:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2662"/>
        <source>Block size:</source>
        <translation>Tamanho do bloco:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2678"/>
        <source>Chip size:</source>
        <translation>Tamanho do chip:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="102"/>
        <location filename="../dialognandsr.cpp" line="166"/>
        <location filename="../dialognandsr.cpp" line="266"/>
        <location filename="../dialognandsr.cpp" line="309"/>
        <location filename="../dialognandsr.cpp" line="365"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="102"/>
        <source>Error reading register!</source>
        <translation>Erro ao ler o registro!</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="166"/>
        <source>Error reading Parameter Page!</source>
        <translation>Erro ao ler a página de parâmetros!</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="248"/>
        <source>The Parameter Page is not supported.</source>
        <translation>A página Parâmetros não é compatível.</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="266"/>
        <source>Error reading ID!</source>
        <translation>Erro ao ler o ID!</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="309"/>
        <location filename="../dialognandsr.cpp" line="365"/>
        <source>Programmer </source>
        <translation>Programador </translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="309"/>
        <location filename="../dialognandsr.cpp" line="365"/>
        <source> is not connected!</source>
        <translation> não está conectado!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">O programador CH341a não está conectado!</translation>
    </message>
</context>
<context>
    <name>DialogNandSecurity</name>
    <message>
        <location filename="../dialognandsecurity.ui" line="14"/>
        <source>Security registers</source>
        <translation>Registros de segurança</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="24"/>
        <source>Hex Editor</source>
        <translation>Editor hexadecimal</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="64"/>
        <source>Operations:</source>
        <translation>Operações</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="93"/>
        <source>Reading security register data from the chip</source>
        <translation>Lendo dados do registro de segurança do chip</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="96"/>
        <location filename="../dialognandsecurity.ui" line="128"/>
        <location filename="../dialognandsecurity.ui" line="167"/>
        <location filename="../dialognandsecurity.ui" line="199"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="125"/>
        <source>Writing data to the security register</source>
        <translation>Gravando dados no registro de segurança</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="164"/>
        <source>Open a binary file from a computer</source>
        <translation>Abra um arquivo binário do computador</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="196"/>
        <source>Save the binary file on the computer</source>
        <translation>Salvar arquivo binário no computador</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="225"/>
        <source>Security register number:</source>
        <translation>Número do registro de segurança:</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="79"/>
        <location filename="../dialognandsecurity.cpp" line="119"/>
        <location filename="../dialognandsecurity.cpp" line="214"/>
        <location filename="../dialognandsecurity.cpp" line="232"/>
        <location filename="../dialognandsecurity.cpp" line="265"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="79"/>
        <source>Error reading Parameter Page!</source>
        <translation>Erro ao ler a página de parâmetros!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">O programador CH341a não está conectado!</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="119"/>
        <location filename="../dialognandsecurity.cpp" line="214"/>
        <source>Programmer </source>
        <translation>Programador </translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="119"/>
        <location filename="../dialognandsecurity.cpp" line="214"/>
        <source> is not connected!</source>
        <translation> não está conectado!</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="223"/>
        <source>Open file</source>
        <translation>Abrir arquivo</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="232"/>
        <source>The file size exceeds the security register size.</source>
        <translation>O tamanho do arquivo excede o tamanho do registro de segurança.</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="254"/>
        <source>Save file</source>
        <translation>Salvar arquivo</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="265"/>
        <source>Error saving file!</source>
        <translation>Erro salvando arquivo!</translation>
    </message>
</context>
<context>
    <name>DialogRP</name>
    <message>
        <location filename="../dialogrp.ui" line="20"/>
        <source>Load block from file</source>
        <translation>Carregar bloco de arquivo</translation>
    </message>
    <message>
        <location filename="../dialogrp.ui" line="33"/>
        <source>All values in HEX format!</source>
        <translation>Todos os valores em formato HEX!</translation>
    </message>
    <message>
        <location filename="../dialogrp.ui" line="48"/>
        <source>Start address:</source>
        <translation>Endereço de início:</translation>
    </message>
    <message>
        <location filename="../dialogrp.ui" line="112"/>
        <source>Load</source>
        <translation>Carregar</translation>
    </message>
</context>
<context>
    <name>DialogSFDP</name>
    <message>
        <location filename="../dialogsfdp.ui" line="14"/>
        <source>Information about SFDP and status registers</source>
        <translation>Informações sobre SFDP e registros de status</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="47"/>
        <source>SFDP support:</source>
        <translation>Suporte SFDP:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="67"/>
        <source>Minimum VCC:</source>
        <translation>VCC mínimo:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="87"/>
        <source>Maximum VCC:</source>
        <translation>VCC máximo:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="107"/>
        <source>Chip size:</source>
        <translation>Tamanho do chip:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="127"/>
        <source>Block size:</source>
        <translation>Tamanho do bloco:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="150"/>
        <source>Speeds:</source>
        <translation>Velocidades:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="170"/>
        <source>OTP support:</source>
        <translation>Suporte OTP:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="196"/>
        <source>Status Register 0</source>
        <translation>Registro de status 0</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="424"/>
        <source>SPR0</source>
        <translation>SPR0</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="449"/>
        <source>BP4</source>
        <translation>BP4</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="474"/>
        <source>BP3</source>
        <translation>BP3</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="499"/>
        <source>BP2</source>
        <translation>BP2</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="524"/>
        <source>BP1</source>
        <translation>BP1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="549"/>
        <source>BP0</source>
        <translation>BP0</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="574"/>
        <source>WEL</source>
        <translation>WEL</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="599"/>
        <source>WIP</source>
        <translation>WIP</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="830"/>
        <source>SUS1</source>
        <translation>SUS1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="855"/>
        <source>CMP</source>
        <translation>CMP</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="880"/>
        <source>LB3</source>
        <translation>LB3</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="905"/>
        <source>LB2</source>
        <translation>LB2</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="930"/>
        <source>LB1</source>
        <translation>LB1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="955"/>
        <source>SUS2</source>
        <translation>SUS2</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="980"/>
        <source>QE</source>
        <translation>QE</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1005"/>
        <source>SPR1</source>
        <translation>SPR1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="611"/>
        <source>Status Register 1</source>
        <translation>Registro de status 1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1017"/>
        <source>Status register 2</source>
        <translation>Registro de status 2</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1195"/>
        <source>JEDEC info:</source>
        <translation>Informações JEDEC:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1301"/>
        <source>Man. ID</source>
        <translation>ID Fabr.</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1323"/>
        <source>Man. type</source>
        <translation>Tipo Fabr.</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1345"/>
        <source>Capacity</source>
        <translation>Capacidade</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1357"/>
        <source>Unique ID:</source>
        <translation>ID único:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1398"/>
        <source>Read</source>
        <translation>Ler</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1426"/>
        <source>Write registers</source>
        <translation>Gravar registros</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1453"/>
        <location filename="../dialogsfdp.ui" line="1519"/>
        <location filename="../dialogsfdp.ui" line="1541"/>
        <source>(R)</source>
        <translation>(R)</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1475"/>
        <source>DRV1</source>
        <translation>DRV1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1497"/>
        <source>DRV0</source>
        <translation>DRV0</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1563"/>
        <source>WPS</source>
        <translation>WPS</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1585"/>
        <source>ADP</source>
        <translation>ADP</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1607"/>
        <source>ADS</source>
        <translation>ADS</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1693"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p/&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p/&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1731"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Legend:&lt;/p&gt;&lt;p&gt;** - Basic area&lt;br&gt;** - Extended area&lt;br&gt;** - Manufacture area &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;body&gt;&lt;p&gt;Legenda:&lt;/p&gt;&lt;p&gt;** - Zona básica&lt;br&gt;** - Zona ampliada&lt;br&gt;** - Zona de fabricação&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1776"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="84"/>
        <location filename="../dialogsfdp.cpp" line="104"/>
        <location filename="../dialogsfdp.cpp" line="213"/>
        <location filename="../dialogsfdp.cpp" line="226"/>
        <location filename="../dialogsfdp.cpp" line="245"/>
        <location filename="../dialogsfdp.cpp" line="267"/>
        <location filename="../dialogsfdp.cpp" line="282"/>
        <location filename="../dialogsfdp.cpp" line="435"/>
        <location filename="../dialogsfdp.cpp" line="439"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="104"/>
        <location filename="../dialogsfdp.cpp" line="213"/>
        <location filename="../dialogsfdp.cpp" line="226"/>
        <location filename="../dialogsfdp.cpp" line="245"/>
        <source>Error reading register!</source>
        <translation>Erro ao ler o registro!</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="176"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt; Hex SFDP register data:
</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt; Dados de registro hexadecimal SFDP:
</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="177"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Addr:&lt;br&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Addr:&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="282"/>
        <location filename="../dialogsfdp.cpp" line="435"/>
        <source>Programmer </source>
        <translation>Programador </translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="282"/>
        <location filename="../dialogsfdp.cpp" line="435"/>
        <source> is not connected!</source>
        <translation> não está conectado!</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="439"/>
        <source>Before writing the registers, please press the `Read` button!</source>
        <translation>Antes de escrever os registros, favor pressionar o botão `Ler`!</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="84"/>
        <source>Error reading JEDEC ID!</source>
        <translation>Erro ao ler o ID JEDEC!</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="44"/>
        <source>Legend:</source>
        <translation>Legenda:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="45"/>
        <source> - Basic area</source>
        <translation> - Zona básica</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="46"/>
        <source> - Extended area</source>
        <translation> - Zona ampliada</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="47"/>
        <source> - Manufacture area</source>
        <translation> - Zona de fabricação</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="267"/>
        <source>Error reading unique ID!</source>
        <translation>Erro ao ler o ID único!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">O programador CH341a não está conectado!</translation>
    </message>
</context>
<context>
    <name>DialogSP</name>
    <message>
        <location filename="../dialogsp.ui" line="14"/>
        <source>Save part of image</source>
        <translation>Salvar parte da imagem</translation>
    </message>
    <message>
        <location filename="../dialogsp.ui" line="27"/>
        <source>All values in HEX format!</source>
        <translation>Todos os valores em formato HEX!</translation>
    </message>
    <message>
        <location filename="../dialogsp.ui" line="42"/>
        <source>Start address:</source>
        <translation>Endereço de início:</translation>
    </message>
    <message>
        <location filename="../dialogsp.ui" line="120"/>
        <source>Save</source>
        <translation>Salvar</translation>
    </message>
    <message>
        <location filename="../dialogsp.cpp" line="28"/>
        <source>End address</source>
        <translation>Endereço final</translation>
    </message>
    <message>
        <location filename="../dialogsp.cpp" line="29"/>
        <source>Length</source>
        <translation>Comprimento</translation>
    </message>
</context>
<context>
    <name>DialogSR</name>
    <message>
        <location filename="../dialogsr.ui" line="14"/>
        <source>Status register</source>
        <translation>Registro de status</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="296"/>
        <source>WPEN</source>
        <translation>WPEN</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="327"/>
        <location filename="../dialogsr.ui" line="358"/>
        <location filename="../dialogsr.ui" line="389"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="420"/>
        <source>BP1</source>
        <translation>BP1</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="451"/>
        <source>BP0</source>
        <translation>BP0</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="482"/>
        <source>WEN</source>
        <translation>WEN</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="513"/>
        <source>/RDY</source>
        <translation>/RDY</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="545"/>
        <source>Read</source>
        <translation>Ler</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="571"/>
        <source>Write</source>
        <translation>Programar</translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="57"/>
        <location filename="../dialogsr.cpp" line="71"/>
        <location filename="../dialogsr.cpp" line="110"/>
        <location filename="../dialogsr.cpp" line="113"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="57"/>
        <source>Error reading register!</source>
        <translation>Erro ao ler o registro!</translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="71"/>
        <location filename="../dialogsr.cpp" line="113"/>
        <source>Programmer </source>
        <translation>Programador </translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="71"/>
        <location filename="../dialogsr.cpp" line="113"/>
        <source> is not connected!</source>
        <translation> não está conectado!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">O programador CH341a não está conectado!</translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="110"/>
        <source>Before writing the register, please press the `Read` button!</source>
        <translation>Antes de escrever os registro, favor pressionar o botão `Ler`!</translation>
    </message>
</context>
<context>
    <name>DialogSecurity</name>
    <message>
        <location filename="../dialogsecurity.ui" line="14"/>
        <source>Security registers</source>
        <translation>Registros de segurança</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="24"/>
        <source>Hex Editor</source>
        <translation>Editor hexadecimal</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="64"/>
        <source>Operations:</source>
        <translation>Operações</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="93"/>
        <source>Reading security register data from the chip</source>
        <translation>Lendo dados do registro de segurança do chip</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="96"/>
        <location filename="../dialogsecurity.ui" line="128"/>
        <location filename="../dialogsecurity.ui" line="160"/>
        <location filename="../dialogsecurity.ui" line="199"/>
        <location filename="../dialogsecurity.ui" line="231"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="125"/>
        <source>Erasing security register data</source>
        <translation>Apagando dados de registros de segurança</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="157"/>
        <source>Writing data to the security register</source>
        <translation>Gravando dados no registro de segurança</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="196"/>
        <source>Open a binary file from a computer</source>
        <translation>Abra um arquivo binário do computador</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="228"/>
        <source>Save the binary file on the computer</source>
        <translation>Salvar arquivo binário no computador</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="257"/>
        <source>Security register number:</source>
        <translation>Número do registro de segurança:</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="173"/>
        <location filename="../dialogsecurity.cpp" line="183"/>
        <location filename="../dialogsecurity.cpp" line="257"/>
        <location filename="../dialogsecurity.cpp" line="294"/>
        <location filename="../dialogsecurity.cpp" line="365"/>
        <location filename="../dialogsecurity.cpp" line="390"/>
        <location filename="../dialogsecurity.cpp" line="423"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="173"/>
        <source>Error reading register!</source>
        <translation>Erro ao ler o registro!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">O programador CH341a não está conectado!</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="183"/>
        <location filename="../dialogsecurity.cpp" line="294"/>
        <location filename="../dialogsecurity.cpp" line="365"/>
        <source>Programmer </source>
        <translation>Programador </translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="183"/>
        <location filename="../dialogsecurity.cpp" line="294"/>
        <location filename="../dialogsecurity.cpp" line="365"/>
        <source> is not connected!</source>
        <translation> não está conectado!</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="257"/>
        <source>Error writing register!</source>
        <translation>Erro escrevendo o registro!</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="381"/>
        <source>Open file</source>
        <translation>Abrir arquivo</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="390"/>
        <source>The file size exceeds the security register size.</source>
        <translation>O tamanho do arquivo excede o tamanho do registro de segurança.</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="412"/>
        <source>Save file</source>
        <translation>Salvar arquivo</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="423"/>
        <source>Error saving file!</source>
        <translation>Erro salvando arquivo!</translation>
    </message>
</context>
<context>
    <name>DialogSetAddr</name>
    <message>
        <location filename="../dialogsetaddr.ui" line="14"/>
        <source>Goto address</source>
        <translation>Ir para o endereço</translation>
    </message>
    <message>
        <location filename="../dialogsetaddr.ui" line="24"/>
        <source>All values in HEX format!</source>
        <translation>Todos os valores em formato HEX!</translation>
    </message>
    <message>
        <location filename="../dialogsetaddr.ui" line="39"/>
        <source>Address:</source>
        <translation>Endereço:</translation>
    </message>
    <message>
        <location filename="../dialogsetaddr.ui" line="90"/>
        <source>Go to</source>
        <translation>Ir para</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="1042"/>
        <source>File</source>
        <translation>Arquivo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1155"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1158"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1179"/>
        <source>Exit</source>
        <translation>Sair</translation>
    </message>
    <message>
        <source>Ctrl+X</source>
        <translation type="vanished">Ctrl+X</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1167"/>
        <source>Save</source>
        <translation>Salvar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="29"/>
        <source>IMSProg - I2C/MicroWire/SPI CH341a Programmer</source>
        <translation>IMSProg - Programador I2C/MicroWire/SPI CH341a</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="77"/>
        <location filename="../mainwindow.ui" line="1060"/>
        <source>Chip</source>
        <translation>Chip</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="171"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="247"/>
        <source>Page size</source>
        <translation>Tamanho de página</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="285"/>
        <source>Block size</source>
        <translation>Tamanho do bloco</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="323"/>
        <source>VCC, Volt</source>
        <translation>VCC, Volts</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="423"/>
        <source>4byte Addr.</source>
        <translation>Endereço 4bytes.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="572"/>
        <location filename="../mainwindow.ui" line="1191"/>
        <source>Detect</source>
        <translation>Detectar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="609"/>
        <location filename="../mainwindow.ui" line="1203"/>
        <source>Read</source>
        <translation>Ler</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="411"/>
        <source>i</source>
        <translation>i</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="461"/>
        <source>I2C bus speed</source>
        <translation>Velocidade do I2C</translation>
    </message>
    <message>
        <source>Erase size</source>
        <translation type="vanished">Apagar tamanho</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="496"/>
        <source>ECC size</source>
        <translation>Tamanho ECC</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="682"/>
        <source>Auto Options</source>
        <translation>Opções automáticas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="699"/>
        <location filename="../mainwindow.ui" line="1215"/>
        <source>Erase</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="719"/>
        <source>Program</source>
        <translation>Programar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="729"/>
        <location filename="../mainwindow.ui" line="1239"/>
        <source>Verify</source>
        <translation>Verificar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="784"/>
        <source>Go!</source>
        <translation>Ir!</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="823"/>
        <location filename="../mainwindow.ui" line="1075"/>
        <source>Hex Editor</source>
        <translation>Editor hexadecimal</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="891"/>
        <source>  JEDEC ID:</source>
        <translation>JEDEC ID</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="907"/>
        <source>CH341a:</source>
        <translation>CH341a:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="938"/>
        <source>border: 2px solid gray;border-radius: 5px;font-weight:600;border-style:inset;</source>
        <translation>border: 2px solid gray;border-radius: 5px;font-weight:600;border-style:inset;</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="951"/>
        <source>CRC32:</source>
        <translation>CRC32:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1010"/>
        <source>Message</source>
        <translation>Mensagem</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1097"/>
        <source>Programmer</source>
        <translation>Programador</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1091"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="618"/>
        <source>Operations</source>
        <translation>Operações</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="709"/>
        <location filename="../mainwindow.ui" line="1495"/>
        <source>Check erase</source>
        <translation>Verificar apagamento</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1170"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1194"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1206"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1218"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1227"/>
        <source>Write</source>
        <translation>Programar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1230"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1242"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1251"/>
        <source>Undo</source>
        <translation>Desfazer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1254"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1263"/>
        <source>Redo</source>
        <translation>Refazer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1266"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1337"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1376"/>
        <source>Import from Intel HEX</source>
        <translation>Importar de Intel HEX</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1385"/>
        <source>Export to Intel HEX</source>
        <translation>Exportar para Intel HEX</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1394"/>
        <source>Extract from ASUS CAP</source>
        <translation>Extrair do CAP da ASUS</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1403"/>
        <source>Goto address</source>
        <translation>Ir para o endereço</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1406"/>
        <source>Move the cursor to the entered address</source>
        <translation>Mova o cursor para o endereço inserido</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1409"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1418"/>
        <source>Security registers</source>
        <translation>Registros de segurança</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1421"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1430"/>
        <source>Fill test image</source>
        <translation>Preencher imagem de teste</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1433"/>
        <source>Filling the hex editor with a test array</source>
        <translation>Preenchimento do editor hexadecimal com uma matriz de teste</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1436"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1445"/>
        <source>Compare files</source>
        <translation>Comparar arquivos</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1448"/>
        <source>Compares the results of the last and penultimate chip read or file open operation</source>
        <translation>Compara os resultados da última e penúltima operação de leitura de chip ou de abertura de arquivo.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1451"/>
        <source>Ctrl+M</source>
        <translation>Ctrl+M</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1460"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1469"/>
        <source>Paste</source>
        <translation>Colar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1478"/>
        <source>Bad block management</source>
        <translation>Gerenciamento de blocos defeituosos</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1481"/>
        <source>Ctrl+B</source>
        <translation>Ctrl+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1486"/>
        <source>Show programmer version</source>
        <translation>Mostrar versão do programador</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1498"/>
        <source>Check erase chip</source>
        <translation>Verificar se o chip foi apagado</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1501"/>
        <source>Ctrl+J</source>
        <translation>Ctrl+J</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1510"/>
        <source>Filling with code</source>
        <translation>Preenchimento com código</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1513"/>
        <source>Ctrl+K</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1525"/>
        <source>CH341A/B v1.2</source>
        <translation>CH341A/B v1.2</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1533"/>
        <source>CH341A v1.7</source>
        <translation>CH341A v1.7</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1541"/>
        <source>CH347T v1.0</source>
        <translation>CH347T v1.0</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1549"/>
        <source>CH347T v1.1</source>
        <translation>CH347T v1.1</translation>
    </message>
    <message>
        <source>CH347T</source>
        <translation type="vanished">CH347T</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1275"/>
        <source>Save Part</source>
        <translation>Salvar Parte</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1287"/>
        <source>Load Part</source>
        <translation>Carregar parte</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1299"/>
        <source>Find / Replace</source>
        <translation>Localizar / Substituir</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1302"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1307"/>
        <source>About</source>
        <translation>Sobre</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1310"/>
        <source>About IMSProgrammer</source>
        <translation>Sobre IMSProgrammer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1313"/>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1322"/>
        <source>Checksum calculate</source>
        <translation>Cálculo de Checksum</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1325"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1334"/>
        <source>Edit chips Database</source>
        <translation>Editar banco de dados de chips</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1182"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1346"/>
        <location filename="../mainwindow.cpp" line="1997"/>
        <source>Stop</source>
        <translation>Parar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1349"/>
        <source>Forced stop of read, write, erase and verification operations</source>
        <translation>Parada forçada de operações de leitura, gravação, apagamento e verificação</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1352"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1361"/>
        <source>Chip info</source>
        <translation>Informações do chip</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1364"/>
        <source>Information about SFDP and status registers</source>
        <translation>Informações sobre SFDP e registros de status</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1367"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="937"/>
        <location filename="../mainwindow.cpp" line="980"/>
        <location filename="../mainwindow.cpp" line="1541"/>
        <location filename="../mainwindow.cpp" line="2296"/>
        <location filename="../mainwindow.cpp" line="2372"/>
        <source>Current file: </source>
        <translation>Arquivo atual: </translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="83"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="127"/>
        <source>Manufacture</source>
        <translation>Fabricação</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="209"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2066"/>
        <source>Opening DAT file</source>
        <translation>Abrindo um arquivo DAT</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <location filename="../mainwindow.cpp" line="312"/>
        <location filename="../mainwindow.cpp" line="320"/>
        <location filename="../mainwindow.cpp" line="326"/>
        <location filename="../mainwindow.cpp" line="358"/>
        <location filename="../mainwindow.cpp" line="359"/>
        <location filename="../mainwindow.cpp" line="372"/>
        <location filename="../mainwindow.cpp" line="389"/>
        <location filename="../mainwindow.cpp" line="410"/>
        <location filename="../mainwindow.cpp" line="682"/>
        <location filename="../mainwindow.cpp" line="699"/>
        <location filename="../mainwindow.cpp" line="719"/>
        <location filename="../mainwindow.cpp" line="764"/>
        <location filename="../mainwindow.cpp" line="815"/>
        <location filename="../mainwindow.cpp" line="862"/>
        <location filename="../mainwindow.cpp" line="930"/>
        <location filename="../mainwindow.cpp" line="970"/>
        <location filename="../mainwindow.cpp" line="1051"/>
        <location filename="../mainwindow.cpp" line="1115"/>
        <location filename="../mainwindow.cpp" line="1124"/>
        <location filename="../mainwindow.cpp" line="1131"/>
        <location filename="../mainwindow.cpp" line="1157"/>
        <location filename="../mainwindow.cpp" line="1167"/>
        <location filename="../mainwindow.cpp" line="1338"/>
        <location filename="../mainwindow.cpp" line="1392"/>
        <location filename="../mainwindow.cpp" line="1401"/>
        <location filename="../mainwindow.cpp" line="1407"/>
        <location filename="../mainwindow.cpp" line="1418"/>
        <location filename="../mainwindow.cpp" line="1447"/>
        <location filename="../mainwindow.cpp" line="1448"/>
        <location filename="../mainwindow.cpp" line="1462"/>
        <location filename="../mainwindow.cpp" line="1492"/>
        <location filename="../mainwindow.cpp" line="1497"/>
        <location filename="../mainwindow.cpp" line="1521"/>
        <location filename="../mainwindow.cpp" line="1555"/>
        <location filename="../mainwindow.cpp" line="1866"/>
        <location filename="../mainwindow.cpp" line="2074"/>
        <location filename="../mainwindow.cpp" line="2086"/>
        <location filename="../mainwindow.cpp" line="2246"/>
        <location filename="../mainwindow.cpp" line="2262"/>
        <location filename="../mainwindow.cpp" line="2386"/>
        <location filename="../mainwindow.cpp" line="2418"/>
        <location filename="../mainwindow.cpp" line="2436"/>
        <location filename="../mainwindow.cpp" line="2456"/>
        <location filename="../mainwindow.cpp" line="2588"/>
        <location filename="../mainwindow.cpp" line="2702"/>
        <location filename="../mainwindow.cpp" line="2748"/>
        <location filename="../mainwindow.cpp" line="2800"/>
        <location filename="../mainwindow.cpp" line="2809"/>
        <location filename="../mainwindow.cpp" line="2815"/>
        <location filename="../mainwindow.cpp" line="2826"/>
        <location filename="../mainwindow.cpp" line="2855"/>
        <location filename="../mainwindow.cpp" line="2856"/>
        <location filename="../mainwindow.cpp" line="2869"/>
        <location filename="../mainwindow.cpp" line="2895"/>
        <location filename="../mainwindow.cpp" line="2900"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1492"/>
        <location filename="../mainwindow.cpp" line="2895"/>
        <source>The end address must be greater than the starting address.</source>
        <translation>O endereço final deve ser maior que o endereço inicial.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1866"/>
        <source>File &apos;IMSProg_editor&apos; not found!</source>
        <translation>Arquivo não encontrado `IMSProg_editor`!</translation>
    </message>
    <message>
        <source>Error loading chip database file!</source>
        <translation type="vanished">Erro ao carregar o arquivo de banco de dados do chip!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2092"/>
        <source>Parsing DAT file</source>
        <translation>Analisando arquivo DAT</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="277"/>
        <source>Reading data from </source>
        <translation>Lendo dados de </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <location filename="../mainwindow.cpp" line="312"/>
        <location filename="../mainwindow.cpp" line="1051"/>
        <location filename="../mainwindow.cpp" line="1115"/>
        <location filename="../mainwindow.cpp" line="1338"/>
        <location filename="../mainwindow.cpp" line="1392"/>
        <location filename="../mainwindow.cpp" line="2748"/>
        <location filename="../mainwindow.cpp" line="2800"/>
        <source>Unsupported chip type!</source>
        <translation>Chip não suportado!</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">O programador CH341a não está conectado!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="326"/>
        <location filename="../mainwindow.cpp" line="1407"/>
        <location filename="../mainwindow.cpp" line="2815"/>
        <source>Error reading block </source>
        <translation>Erro ao ler o bloco </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="358"/>
        <location filename="../mainwindow.cpp" line="1157"/>
        <location filename="../mainwindow.cpp" line="1447"/>
        <location filename="../mainwindow.cpp" line="2855"/>
        <source>Before reading from chip please press &apos;Detect&apos; button.</source>
        <translation>Antes de ler o chip, clique no botão &apos;Detectar&apos;.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="359"/>
        <source>Please select the chip parameters - manufacture and chip name</source>
        <translation>Selecione os parâmetros do chip - Fabricante e nome do chip</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="410"/>
        <source>The chip is not connect or missing!</source>
        <translation>Chip não conectado ou ausente!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="669"/>
        <location filename="../mainwindow.cpp" line="2287"/>
        <source>Saving file</source>
        <translation>Salvando arquivo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="671"/>
        <location filename="../mainwindow.cpp" line="2289"/>
        <source>Save file</source>
        <translation>Salvar arquivo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="673"/>
        <location filename="../mainwindow.cpp" line="911"/>
        <source>Data Images</source>
        <translation>Arquivos de dados</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="673"/>
        <location filename="../mainwindow.cpp" line="911"/>
        <location filename="../mainwindow.cpp" line="2291"/>
        <location filename="../mainwindow.cpp" line="2364"/>
        <source>All files</source>
        <translation>Todos os arquivos</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="682"/>
        <location filename="../mainwindow.cpp" line="1521"/>
        <source>Error saving file!</source>
        <translation>Erro salvando arquivo!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="702"/>
        <source>Erasing the </source>
        <translation>Apagando o </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="719"/>
        <location filename="../mainwindow.cpp" line="764"/>
        <location filename="../mainwindow.cpp" line="815"/>
        <location filename="../mainwindow.cpp" line="862"/>
        <source>Error erasing sector </source>
        <translation>Erro apagando setor </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="903"/>
        <location filename="../mainwindow.cpp" line="958"/>
        <location filename="../mainwindow.cpp" line="2358"/>
        <source>Opening file</source>
        <translation>Abrindo arquivo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="909"/>
        <location filename="../mainwindow.cpp" line="962"/>
        <location filename="../mainwindow.cpp" line="2362"/>
        <source>Open file</source>
        <translation>Abrir arquivo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="930"/>
        <location filename="../mainwindow.cpp" line="970"/>
        <source>The file size exceeds the chip size. Please select another chip or file or use `Save part` to split the file.</source>
        <translation>O tamanho do arquivo excede o tamanho do chip. Selecione outro chip ou arquivo ou use `Salvar Parte` para dividir o arquivo.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1497"/>
        <location filename="../mainwindow.cpp" line="2900"/>
        <source>The ending address must not exceed the buffer size.</source>
        <translation>O endereço final não deve exceder o tamanho do buffer.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2073"/>
        <source>Cannot find a chip database file.
You may want to run IMSProg_database_update</source>
        <translation>Não foi possível localizar um arquivo de banco de dados de chips.
Recomenda-se executar o IMSProg_database_update</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2246"/>
        <source>Before working with the security registers, click the &apos;Detect&apos; button</source>
        <translation>Antes de trabalhar com os registros de segurança, clique no botão &apos;Detectar&apos;</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2262"/>
        <source>There are no security registers in this chip or the current version of IMSProg does not support this algorithm.</source>
        <translation>Não há registros de segurança neste chip ou a versão atual do IMSProg não suporta este algoritmo.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2291"/>
        <location filename="../mainwindow.cpp" line="2364"/>
        <source>Intel HEX Images</source>
        <translation>Arquivos Intel HEX</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2386"/>
        <source>Not valid HEX format!</source>
        <translation>O formato HEX não é válido!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2418"/>
        <source>The address is larger than the size of the chip!</source>
        <translation>O endereço é maior do que o tamanho do chip!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2436"/>
        <location filename="../mainwindow.cpp" line="2456"/>
        <source>Checksum error!</source>
        <translation>Erro de checksum!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1061"/>
        <source>Writing data to </source>
        <translation>Escrevendo dados em </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="320"/>
        <location filename="../mainwindow.cpp" line="372"/>
        <location filename="../mainwindow.cpp" line="389"/>
        <location filename="../mainwindow.cpp" line="699"/>
        <location filename="../mainwindow.cpp" line="1124"/>
        <location filename="../mainwindow.cpp" line="1167"/>
        <location filename="../mainwindow.cpp" line="1401"/>
        <location filename="../mainwindow.cpp" line="1462"/>
        <location filename="../mainwindow.cpp" line="2702"/>
        <location filename="../mainwindow.cpp" line="2809"/>
        <location filename="../mainwindow.cpp" line="2869"/>
        <source>Programmer </source>
        <translation>Programador </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="320"/>
        <location filename="../mainwindow.cpp" line="372"/>
        <location filename="../mainwindow.cpp" line="389"/>
        <location filename="../mainwindow.cpp" line="699"/>
        <location filename="../mainwindow.cpp" line="1124"/>
        <location filename="../mainwindow.cpp" line="1167"/>
        <location filename="../mainwindow.cpp" line="1401"/>
        <location filename="../mainwindow.cpp" line="1462"/>
        <location filename="../mainwindow.cpp" line="2702"/>
        <location filename="../mainwindow.cpp" line="2809"/>
        <location filename="../mainwindow.cpp" line="2869"/>
        <source> is not connected!</source>
        <translation> não está conectado!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1131"/>
        <source>Error writing sector </source>
        <translation>Erro ao escrever o setor </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1356"/>
        <source>Veryfing data from </source>
        <translation>Verificando dados de </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1418"/>
        <source>Error comparing data!
Address:   </source>
        <translation>Erro ao comparar dados!
Endereço:   </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1418"/>
        <source>
Buffer: </source>
        <translation>
Buffer: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1418"/>
        <location filename="../mainwindow.cpp" line="2826"/>
        <source>    Chip: </source>
        <translation>    Chip: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1448"/>
        <location filename="../mainwindow.cpp" line="2588"/>
        <location filename="../mainwindow.cpp" line="2856"/>
        <source>Please select the chip parameters - manufacture and chip name.</source>
        <translation>Selecione os parâmetros do chip - Fabricante e nome do chip.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1457"/>
        <source>Ok!</source>
        <translation>Ok!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1457"/>
        <source>The operation was successful!</source>
        <translation>Operação concluida com êxito!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1509"/>
        <source>Saving block</source>
        <translation>Salvando bloco</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1511"/>
        <source>Save block</source>
        <translation>Salvar bloco</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1536"/>
        <source>Opening block</source>
        <translation>Abrindo bloco</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1538"/>
        <source>Open block</source>
        <translation>Bloco aberto</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1555"/>
        <source>The end address out of image size!</source>
        <translation>Endereço final fora do tamanho da imagem!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1593"/>
        <source>Connected</source>
        <translation>Conectado</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1598"/>
        <source>Not connected</source>
        <translation>Desconectado</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1997"/>
        <source>Operation aborted!</source>
        <translation>Operação abortada!</translation>
    </message>
    <message>
        <source>The chip database file was not found!</source>
        <translation type="vanished">O arquivo do banco de dados de chips não foi encontrado!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2082"/>
        <source>Error loading chip database file!
File: %1
Error Code: %2
Reason: %3</source>
        <translation>Erro ao carregar o arquivo do banco de dados de chips!
Arquivo: %1
Código de erro: %2
Motivo: %3</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2700"/>
        <source>Info:</source>
        <translation>Informações:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2700"/>
        <source>Device revision: </source>
        <translation>Revisão do dispositivo: </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2765"/>
        <source>Erase checking in </source>
        <translation>Verificando apagamento em </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2826"/>
        <source>Error erasing chip!
Address:   </source>
        <translation>Erro ao apagar o chip!
Endereço:   </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2826"/>
        <source>
Need: FF</source>
        <translation>
Necessário: FF</translation>
    </message>
</context>
<context>
    <name>SearchDialog</name>
    <message>
        <location filename="../searchdialog.ui" line="14"/>
        <source>QHexEdit - Find/Replace</source>
        <translation>QHexEdit - Buscar/Substituir</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="26"/>
        <source>Find</source>
        <translation>Encontrar</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="33"/>
        <location filename="../searchdialog.ui" line="78"/>
        <source>Hex</source>
        <translation>Hex</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="38"/>
        <location filename="../searchdialog.ui" line="83"/>
        <source>UTF-8</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="71"/>
        <source>Replace</source>
        <translation>Substituir</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="116"/>
        <source>Options</source>
        <translation>Opções</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="122"/>
        <source>&amp;Backwards</source>
        <translation>Voltar ao início</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="129"/>
        <source>&amp;Prompt on replace</source>
        <translation>Perguntar ao substituir</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="150"/>
        <source>Standard headers:</source>
        <translation>Cabeçalhos padrão:</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="191"/>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="213"/>
        <source>PNG</source>
        <translation>PNG</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="235"/>
        <source>JPG</source>
        <translation>JPG</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="257"/>
        <source>GIF</source>
        <translation>GIF</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="286"/>
        <source>TAR</source>
        <translation>TAR</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="308"/>
        <source>UEFI</source>
        <translation>UEFI</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="330"/>
        <source>BIOS</source>
        <translation>BIOS</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="352"/>
        <source>GPT</source>
        <translation>GPT</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="385"/>
        <source>&amp;Find</source>
        <translation>Encontrar</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="388"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="413"/>
        <source>&amp;Replace</source>
        <translation>Substituir</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="435"/>
        <source>Replace &amp;All</source>
        <translation>Substituir tudo</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="457"/>
        <source>&amp;Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../searchdialog.cpp" line="91"/>
        <location filename="../searchdialog.cpp" line="117"/>
        <source>QHexEdit</source>
        <translation>QHexEdit</translation>
    </message>
    <message>
        <location filename="../searchdialog.cpp" line="91"/>
        <source>%1 occurrences replaced.</source>
        <translation>%1 ocorrências substituídas.</translation>
    </message>
    <message>
        <location filename="../searchdialog.cpp" line="118"/>
        <source>Replace occurrence?</source>
        <translation>Substituir ocorrência?</translation>
    </message>
</context>
<context>
    <name>UndoStack</name>
    <message>
        <location filename="../commands.cpp" line="133"/>
        <source>Inserting %1 bytes</source>
        <translation>Inserir %1 bytes</translation>
    </message>
    <message>
        <location filename="../commands.cpp" line="155"/>
        <source>Delete %1 chars</source>
        <translation>Deletar %1 caracteres</translation>
    </message>
    <message>
        <location filename="../commands.cpp" line="180"/>
        <source>Overwrite %1 chars</source>
        <translation>Substituir %1 caracteres</translation>
    </message>
</context>
</TS>
