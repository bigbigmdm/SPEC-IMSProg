<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN" sourcelanguage="en">
<context>
    <name>DialogAbout</name>
    <message>
        <location filename="../dialogabout.ui" line="14"/>
        <source>About IMSProg</source>
        <translation>关于 IMSProg</translation>
    </message>
    <message>
        <source>IMSProg - free software I2C, SPI and MicroWire EEPROM/Flash chip programmer for CH341a devices. IMSProg supports 24Cxx, 25xx, 93Cxx, and M95xx series chips.</source>
        <translation type="vanished">IMSProg - I2C、SPI、MicroWire EEPROM/Flash 芯片 CH341A 编程器免费软件。IMSProg 支持 24Cxx、25xx、93Cxx 和 M95xx 系列芯片。</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="26"/>
        <source>IMSProg - free software I2C, SPI and MicroWire EEPROM/Flash chip programmer for CH341A and CH347T devices. IMSProg supports 24Cxx, 25xx, 93Cxx, AT45DBxx and M95xx series chips.</source>
        <translation>IMSProg - I2C、SPI、MicroWire EEPROM/Flash 芯片 CH341A和CH347T 编程器免费软件。IMSProg 支持 24Cxx、25xx、93Cxx, AT45DBxx 和 M95xx 系列芯片。</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="90"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;In this program &lt;a href=&quot;https://github.com/Simsys/qhexedit2/&quot;&gt;QhexEditor2&lt;/a&gt; widget and modified programmer &lt;a href=&quot;https://github.com/McMCCRU/SNANDer&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;SNANDer&lt;/span&gt;&lt;/a&gt; were used.&lt;/p&gt;&lt;p&gt;The page on GitHub is &lt;a href=&quot;https://github.com/bigbigmdm/IMSProg&quot;&gt;here&lt;/a&gt;, the support page is &lt;a href=&quot;https://antenna-dvb-t2.ru/IMSProg.php&quot;&gt;here&lt;/a&gt;. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;该程序使用 &lt;a href=&quot;https://github.com/Simsys/qhexedit2/&quot;&gt;QhexEditor2&lt;/a&gt; widget 和经过修改的编程器 &lt;a href=&quot;https://github.com/McMCCRU/SNANDer&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;SNANDer&lt;/span&gt;&lt;/a&gt; .&lt;/p&gt;&lt;p&gt;GitHub 页面在 &lt;a href=&quot;https://github.com/bigbigmdm/IMSProg&quot;&gt;这里&lt;/a&gt;, 支持页面在 &lt;a href=&quot;https://antenna-dvb-t2.ru/IMSProg.php&quot;&gt;这里&lt;/a&gt;. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="119"/>
        <source>Written by 2023 - 2026 Mikhail Medvedev</source>
        <translation>作者：2023 - 2026 米哈伊尔-梅德韦杰夫</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="140"/>
        <source>Version: </source>
        <translation>版本： </translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="150"/>
        <source>1.1.4</source>
        <translation>1.1.4</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="48"/>
        <location filename="../dialogabout.ui" line="68"/>
        <source>OR</source>
        <translation>或</translation>
    </message>
    <message>
        <source>IMSProg - free software I2C, SPI and MicroWire EEPROM/Flash chip programmer for CH341a devices. IMSProg supports 24Cxx, 25xx, 93Cxx, AT45DBxx and M95xx series chips.</source>
        <translation type="vanished">IMSProg - I2C、SPI、MicroWire EEPROM/Flash 芯片 CH341A 编程器免费软件。IMSProg 支持 24Cxx、25xx、93Cxx, AT45DBxx 和 M95xx 系列芯片。</translation>
    </message>
    <message>
        <source>Written by 2023 Mikhail Medvedev</source>
        <translation type="vanished">作者：2023 米哈伊尔-梅德韦杰夫</translation>
    </message>
    <message>
        <location filename="../dialogabout.ui" line="189"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
</context>
<context>
    <name>DialogBBM</name>
    <message>
        <location filename="../dialogbbm.ui" line="20"/>
        <source>Bad block management</source>
        <translation>坏块管理</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="34"/>
        <source>Chip scan</source>
        <translation>芯片扫描</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="69"/>
        <location filename="../dialogbbm.ui" line="285"/>
        <source>No</source>
        <translation>数字</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="77"/>
        <source>Block</source>
        <translation>区块编号</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="85"/>
        <source>Start address</source>
        <translation>起始地址</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="93"/>
        <source>End address</source>
        <translation>结束地址</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="137"/>
        <source>Check</source>
        <translation>检查</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="147"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="167"/>
        <source>Erasing</source>
        <translation>擦除</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="173"/>
        <source>Skip bad blocks during erase procedure  (recommended)</source>
        <translation>擦除过程中跳过坏块（推荐）</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="180"/>
        <source>Don&apos;t skip bad blocks</source>
        <translation>不要跳过坏扇区</translation>
    </message>
    <message>
        <source>Don&apos;t skip bad sectors</source>
        <translation type="vanished">不要跳过坏扇区</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="190"/>
        <source>Writing</source>
        <translation>写入中</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="196"/>
        <source>Write all blocks one to one (ignore bad blocks)</source>
        <translation>分别写入每个扇区（忽略坏扇区）</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="203"/>
        <source>Skip bad blocks during writing procedure</source>
        <translation>在写入过程中跳过坏扇区</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="256"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="268"/>
        <source>BBM table (Winbond)</source>
        <translation>坏块管理表（Winbond）</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="274"/>
        <source>This operation is used only in some Winbond chips.</source>
        <translation>此操作仅适用于某些 Winbond 芯片。</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="290"/>
        <source>Bad block</source>
        <translation>坏块编号</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="295"/>
        <source>Changed block</source>
        <translation>变更块编号</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="300"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="../dialogbbm.ui" line="348"/>
        <source>Read</source>
        <translation>读取</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="81"/>
        <location filename="../dialogbbm.cpp" line="93"/>
        <location filename="../dialogbbm.cpp" line="164"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="81"/>
        <source>Error reading chip!</source>
        <translation>读取芯片错误！</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="85"/>
        <source>Corrupted blocks found:</source>
        <translation>发现损坏的区块：</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="86"/>
        <source>All blocks in the chip are good!</source>
        <translation>芯片中的所有模块都运行正常！</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="93"/>
        <location filename="../dialogbbm.cpp" line="164"/>
        <source>Programmer </source>
        <translation> </translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="93"/>
        <location filename="../dialogbbm.cpp" line="164"/>
        <source> is not connected!</source>
        <translation> 编程器未连接！</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">CH341A 编程器未连接！</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="154"/>
        <source>Not used</source>
        <translation>未使用</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="155"/>
        <source>Active, valid</source>
        <translation>有效，有效</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="156"/>
        <source>Active, not valid</source>
        <translation>有效，但未激活</translation>
    </message>
    <message>
        <location filename="../dialogbbm.cpp" line="161"/>
        <source>BBM table is not used in this chip.</source>
        <translation>该芯片未使用坏块管理表。</translation>
    </message>
</context>
<context>
    <name>DialogCompare</name>
    <message>
        <location filename="../dialogcompare.ui" line="14"/>
        <source>Comparing files:</source>
        <translation>比较文件：</translation>
    </message>
    <message>
        <location filename="../dialogcompare.ui" line="68"/>
        <source>CRC32: </source>
        <translation>CRC32: </translation>
    </message>
    <message>
        <location filename="../dialogcompare.ui" line="100"/>
        <location filename="../dialogcompare.ui" line="187"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="../dialogcompare.ui" line="155"/>
        <source>CRC32:</source>
        <translation>CRC32:</translation>
    </message>
    <message>
        <location filename="../dialogcompare.ui" line="201"/>
        <source>Visible ASCII areas</source>
        <translation>显示 ASCII 区域</translation>
    </message>
    <message>
        <location filename="../dialogcompare.cpp" line="110"/>
        <location filename="../dialogcompare.cpp" line="111"/>
        <source>Name: </source>
        <translation>名称：</translation>
    </message>
</context>
<context>
    <name>DialogFill</name>
    <message>
        <location filename="../dialogfill.ui" line="14"/>
        <source>Fill the buffer with code</source>
        <translation>用代码填充缓冲区</translation>
    </message>
    <message>
        <location filename="../dialogfill.ui" line="27"/>
        <source>All values in HEX format!</source>
        <translation>所有数值均为 HEX 格式！</translation>
    </message>
    <message>
        <location filename="../dialogfill.ui" line="42"/>
        <source>Start address:</source>
        <translation>起始地址:</translation>
    </message>
    <message>
        <location filename="../dialogfill.ui" line="91"/>
        <source>Filling code:</source>
        <translation>正在填充代码：</translation>
    </message>
    <message>
        <location filename="../dialogfill.ui" line="130"/>
        <source>Fill</source>
        <translation>填充</translation>
    </message>
    <message>
        <location filename="../dialogfill.cpp" line="36"/>
        <source>End address</source>
        <translation>结束地址</translation>
    </message>
    <message>
        <location filename="../dialogfill.cpp" line="37"/>
        <source>Length</source>
        <translation>长度</translation>
    </message>
</context>
<context>
    <name>DialogInfo</name>
    <message>
        <location filename="../dialoginfo.ui" line="14"/>
        <source>Connection info:</source>
        <translation>连接信息：</translation>
    </message>
    <message>
        <location filename="../dialoginfo.ui" line="36"/>
        <source>Slot:</source>
        <translation>插槽：</translation>
    </message>
    <message>
        <location filename="../dialoginfo.ui" line="43"/>
        <location filename="../dialoginfo.ui" line="61"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../dialoginfo.ui" line="54"/>
        <source>Adapter:</source>
        <translation>适配器：</translation>
    </message>
    <message>
        <location filename="../dialoginfo.ui" line="106"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
</context>
<context>
    <name>DialogNANDSr</name>
    <message>
        <location filename="../dialognandsr.ui" line="20"/>
        <source>Status registers</source>
        <translation>缓冲区：</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="37"/>
        <source>Status register 1</source>
        <translation>状态寄存器 1</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="318"/>
        <source>SRP0</source>
        <translation>SRP0</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="349"/>
        <source>BP3</source>
        <translation>BP3</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="380"/>
        <source>BP2</source>
        <translation>BP2</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="411"/>
        <source>BP1</source>
        <translation>BP1</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="442"/>
        <source>BP0</source>
        <translation>BP0</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="473"/>
        <source>TB</source>
        <translation>TB</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="504"/>
        <source>WP-E</source>
        <translation>WP-E</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="535"/>
        <source>SRP1</source>
        <translation>SRP1</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="552"/>
        <source>Status register 2</source>
        <translation>状态寄存器 2</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="824"/>
        <source>OTP-L</source>
        <translation>OTP-L</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="852"/>
        <source>OTP-E</source>
        <translation>OTP-E</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="880"/>
        <source>SR1-L</source>
        <translation>SR1-L</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="908"/>
        <source>ECC-E</source>
        <translation>ECC-E</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="936"/>
        <source>BUF</source>
        <translation>BUF</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="964"/>
        <location filename="../dialognandsr.ui" line="992"/>
        <location filename="../dialognandsr.ui" line="1020"/>
        <location filename="../dialognandsr.ui" line="1309"/>
        <source>(R)</source>
        <translation>(R)</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1040"/>
        <source>Status register 3</source>
        <translation>状态寄存器 3</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1337"/>
        <source>LUT-F</source>
        <translation>LUT-F</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1365"/>
        <source>ECC-1</source>
        <translation>ECC-1</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1393"/>
        <source>ECC-0</source>
        <translation>ECC-0</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1421"/>
        <source>P-FAIL</source>
        <translation>P-FAIL</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1449"/>
        <source>WELL</source>
        <translation>WELL</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1477"/>
        <source>BUSY</source>
        <translation>BUSY</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1505"/>
        <source>E_FAIL</source>
        <translation>E_FAIL</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1522"/>
        <source>Status register 4</source>
        <translation>状态寄存器 4</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1785"/>
        <location filename="../dialognandsr.ui" line="1813"/>
        <location filename="../dialognandsr.ui" line="1841"/>
        <location filename="../dialognandsr.ui" line="1869"/>
        <location filename="../dialognandsr.ui" line="1897"/>
        <location filename="../dialognandsr.ui" line="1925"/>
        <location filename="../dialognandsr.ui" line="1953"/>
        <location filename="../dialognandsr.ui" line="1981"/>
        <location filename="../dialognandsr.ui" line="2261"/>
        <location filename="../dialognandsr.ui" line="2289"/>
        <location filename="../dialognandsr.ui" line="2317"/>
        <location filename="../dialognandsr.ui" line="2345"/>
        <location filename="../dialognandsr.ui" line="2373"/>
        <location filename="../dialognandsr.ui" line="2401"/>
        <location filename="../dialognandsr.ui" line="2429"/>
        <location filename="../dialognandsr.ui" line="2457"/>
        <source>---</source>
        <translation>---</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="1998"/>
        <source>Status register 5</source>
        <translation>状态寄存器 5</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2482"/>
        <source>Unique ID:</source>
        <translation>唯一 ID：</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2538"/>
        <source>Read</source>
        <translation>读取</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2564"/>
        <source>Write</source>
        <translation>写入</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2580"/>
        <source>Parameter page:</source>
        <translation>参数页面：</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2608"/>
        <source>Manufacturer:</source>
        <translation>制造商:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2618"/>
        <source>Model:</source>
        <translation>型号：</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2628"/>
        <source>Page size:</source>
        <translation>页面大小:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2635"/>
        <source>ECC size:</source>
        <translation>ECC 尺寸:</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2648"/>
        <source>Pages per block:</source>
        <translation>每块页面数：</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2655"/>
        <source>Block per unit:</source>
        <translation>每单位块数：</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2662"/>
        <source>Block size:</source>
        <translation>块大小：</translation>
    </message>
    <message>
        <location filename="../dialognandsr.ui" line="2678"/>
        <source>Chip size:</source>
        <translation>芯片大小：</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="102"/>
        <location filename="../dialognandsr.cpp" line="166"/>
        <location filename="../dialognandsr.cpp" line="266"/>
        <location filename="../dialognandsr.cpp" line="309"/>
        <location filename="../dialognandsr.cpp" line="365"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="102"/>
        <source>Error reading register!</source>
        <translation>错误读取寄存器！</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="166"/>
        <source>Error reading Parameter Page!</source>
        <translation>读取参数页面时发生错误！</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="248"/>
        <source>The Parameter Page is not supported.</source>
        <translation>参数页面不支持。</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="266"/>
        <source>Error reading ID!</source>
        <translation>读取ID时发生错误！</translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="309"/>
        <location filename="../dialognandsr.cpp" line="365"/>
        <source>Programmer </source>
        <translation> </translation>
    </message>
    <message>
        <location filename="../dialognandsr.cpp" line="309"/>
        <location filename="../dialognandsr.cpp" line="365"/>
        <source> is not connected!</source>
        <translation> 编程器未连接！</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">CH341A 编程器未连接！</translation>
    </message>
</context>
<context>
    <name>DialogNandSecurity</name>
    <message>
        <location filename="../dialognandsecurity.ui" line="14"/>
        <source>Security registers</source>
        <translation>安全登记册</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="24"/>
        <source>Hex Editor</source>
        <translation>十六进制编辑器</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="64"/>
        <source>Operations:</source>
        <translation>操作：</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="93"/>
        <source>Reading security register data from the chip</source>
        <translation>从芯片读取安全寄存器数据</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="96"/>
        <location filename="../dialognandsecurity.ui" line="128"/>
        <location filename="../dialognandsecurity.ui" line="167"/>
        <location filename="../dialognandsecurity.ui" line="199"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="125"/>
        <source>Writing data to the security register</source>
        <translation>向安全寄存器写入数据</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="164"/>
        <source>Open a binary file from a computer</source>
        <translation>从计算机打开二进制文件</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="196"/>
        <source>Save the binary file on the computer</source>
        <translation>在电脑上保存二进制文件</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.ui" line="225"/>
        <source>Security register number:</source>
        <translation>安全登记编号：</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="79"/>
        <location filename="../dialognandsecurity.cpp" line="119"/>
        <location filename="../dialognandsecurity.cpp" line="214"/>
        <location filename="../dialognandsecurity.cpp" line="232"/>
        <location filename="../dialognandsecurity.cpp" line="265"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="79"/>
        <source>Error reading Parameter Page!</source>
        <translation>读取参数页面时发生错误！</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">CH341A 编程器未连接！</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="119"/>
        <location filename="../dialognandsecurity.cpp" line="214"/>
        <source>Programmer </source>
        <translation> </translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="119"/>
        <location filename="../dialognandsecurity.cpp" line="214"/>
        <source> is not connected!</source>
        <translation> 编程器未连接！</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="223"/>
        <source>Open file</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="232"/>
        <source>The file size exceeds the security register size.</source>
        <translation>文件大小超过安全寄存器大小。</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="254"/>
        <source>Save file</source>
        <translation>保存文件</translation>
    </message>
    <message>
        <location filename="../dialognandsecurity.cpp" line="265"/>
        <source>Error saving file!</source>
        <translation>保存文件出错！</translation>
    </message>
</context>
<context>
    <name>DialogRP</name>
    <message>
        <location filename="../dialogrp.ui" line="20"/>
        <source>Load block from file</source>
        <translation>从文件中加载数据块</translation>
    </message>
    <message>
        <location filename="../dialogrp.ui" line="33"/>
        <source>All values in HEX format!</source>
        <translation>所有数值均为 HEX 格式！</translation>
    </message>
    <message>
        <location filename="../dialogrp.ui" line="48"/>
        <source>Start address:</source>
        <translation>起始地址:</translation>
    </message>
    <message>
        <location filename="../dialogrp.ui" line="112"/>
        <source>Load</source>
        <translation>装载量</translation>
    </message>
</context>
<context>
    <name>DialogSFDP</name>
    <message>
        <location filename="../dialogsfdp.ui" line="14"/>
        <source>Information about SFDP and status registers</source>
        <translation>有关 SFDP 和状态寄存器的信息</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="47"/>
        <source>SFDP support:</source>
        <translation>SFDP 支持：</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="67"/>
        <source>Minimum VCC:</source>
        <translation>最低 VCC：</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="87"/>
        <source>Maximum VCC:</source>
        <translation>最大 VCC：</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="107"/>
        <source>Chip size:</source>
        <translation>芯片大小：</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="127"/>
        <source>Block size:</source>
        <translation>块大小：</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="150"/>
        <source>Speeds:</source>
        <translation>速度：</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="170"/>
        <source>OTP support:</source>
        <translation>支持 OTP：</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="196"/>
        <source>Status Register 0</source>
        <translation>状态寄存器 0</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="424"/>
        <source>SPR0</source>
        <translation>SPR0</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="449"/>
        <source>BP4</source>
        <translation>BP4</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="474"/>
        <source>BP3</source>
        <translation>BP3</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="499"/>
        <source>BP2</source>
        <translation>BP2</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="524"/>
        <source>BP1</source>
        <translation>BP1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="549"/>
        <source>BP0</source>
        <translation>BP0</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="574"/>
        <source>WEL</source>
        <translation>WEL</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="599"/>
        <source>WIP</source>
        <translation>WIP</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="830"/>
        <source>SUS1</source>
        <translation>SUS1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="855"/>
        <source>CMP</source>
        <translation>CMP</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="880"/>
        <source>LB3</source>
        <translation>LB3</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="905"/>
        <source>LB2</source>
        <translation>LB2</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="930"/>
        <source>LB1</source>
        <translation>LB1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="955"/>
        <source>SUS2</source>
        <translation>SUS2</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="980"/>
        <source>QE</source>
        <translation>QE</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1005"/>
        <source>SPR1</source>
        <translation>SPR1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="611"/>
        <source>Status Register 1</source>
        <translation>状态寄存器 1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1017"/>
        <source>Status register 2</source>
        <translation>状态寄存器 2</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1195"/>
        <source>JEDEC info:</source>
        <translation>JEDEC 信息：</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1301"/>
        <source>Man. ID</source>
        <translation>制造商标识：</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1323"/>
        <source>Man. type</source>
        <translation>制造类型：</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1345"/>
        <source>Capacity</source>
        <translation>容量：</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1357"/>
        <source>Unique ID:</source>
        <translation>唯一 ID：</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1398"/>
        <source>Read</source>
        <translation>读取</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1426"/>
        <source>Write registers</source>
        <translation>写寄存器</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1453"/>
        <location filename="../dialogsfdp.ui" line="1519"/>
        <location filename="../dialogsfdp.ui" line="1541"/>
        <source>(R)</source>
        <translation>(R)</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1475"/>
        <source>DRV1</source>
        <translation>DRV1</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1497"/>
        <source>DRV0</source>
        <translation>DRV0</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1563"/>
        <source>WPS</source>
        <translation>WPS</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1585"/>
        <source>ADP</source>
        <translation>ADP</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1607"/>
        <source>ADS</source>
        <translation>ADS</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1693"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p/&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p/&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1731"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Legend:&lt;/p&gt;&lt;p&gt;** - Basic area&lt;br&gt;** - Extended area&lt;br&gt;** - Manufacture area &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;图例:&lt;/p&gt;&lt;p&gt;** - 基本区域&lt;br&gt;** - 扩展区&lt;br&gt;** - 制造商区&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.ui" line="1776"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="84"/>
        <location filename="../dialogsfdp.cpp" line="104"/>
        <location filename="../dialogsfdp.cpp" line="213"/>
        <location filename="../dialogsfdp.cpp" line="226"/>
        <location filename="../dialogsfdp.cpp" line="245"/>
        <location filename="../dialogsfdp.cpp" line="267"/>
        <location filename="../dialogsfdp.cpp" line="282"/>
        <location filename="../dialogsfdp.cpp" line="435"/>
        <location filename="../dialogsfdp.cpp" line="439"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="104"/>
        <location filename="../dialogsfdp.cpp" line="213"/>
        <location filename="../dialogsfdp.cpp" line="226"/>
        <location filename="../dialogsfdp.cpp" line="245"/>
        <source>Error reading register!</source>
        <translation>错误读取寄存器！</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="176"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt; Hex SFDP register data:
</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt; 十六进制 SFDP 寄存器数据:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="177"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Addr:&lt;br&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;地址：&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="282"/>
        <location filename="../dialogsfdp.cpp" line="435"/>
        <source>Programmer </source>
        <translation> </translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="282"/>
        <location filename="../dialogsfdp.cpp" line="435"/>
        <source> is not connected!</source>
        <translation> 编程器未连接！</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="439"/>
        <source>Before writing the registers, please press the `Read` button!</source>
        <translation>在写入寄存器之前，请按`读取`按钮！</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="84"/>
        <source>Error reading JEDEC ID!</source>
        <translation>读取 JEDEC ID 时出错！</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="44"/>
        <source>Legend:</source>
        <translation>图例:</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="45"/>
        <source> - Basic area</source>
        <translation> - 基本区域</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="46"/>
        <source> - Extended area</source>
        <translation> - 扩展区</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="47"/>
        <source> - Manufacture area</source>
        <translation> - 制造商区</translation>
    </message>
    <message>
        <location filename="../dialogsfdp.cpp" line="267"/>
        <source>Error reading unique ID!</source>
        <translation>读取唯一 ID 时出错！</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">CH341A 编程器未连接！</translation>
    </message>
</context>
<context>
    <name>DialogSP</name>
    <message>
        <location filename="../dialogsp.ui" line="14"/>
        <source>Save part of image</source>
        <translation>保存部分映像</translation>
    </message>
    <message>
        <location filename="../dialogsp.ui" line="27"/>
        <source>All values in HEX format!</source>
        <translation>所有数值均为 HEX 格式！</translation>
    </message>
    <message>
        <location filename="../dialogsp.ui" line="42"/>
        <source>Start address:</source>
        <translation>起始地址:</translation>
    </message>
    <message>
        <location filename="../dialogsp.ui" line="120"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../dialogsp.cpp" line="28"/>
        <source>End address</source>
        <translation>结束地址</translation>
    </message>
    <message>
        <location filename="../dialogsp.cpp" line="29"/>
        <source>Length</source>
        <translation>长度</translation>
    </message>
</context>
<context>
    <name>DialogSR</name>
    <message>
        <location filename="../dialogsr.ui" line="14"/>
        <source>Status register</source>
        <translation>状态寄存器</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="296"/>
        <source>WPEN</source>
        <translation>WPEN</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="327"/>
        <location filename="../dialogsr.ui" line="358"/>
        <location filename="../dialogsr.ui" line="389"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="420"/>
        <source>BP1</source>
        <translation>BP1</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="451"/>
        <source>BP0</source>
        <translation>BP0</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="482"/>
        <source>WEN</source>
        <translation>WEN</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="513"/>
        <source>/RDY</source>
        <translation>/RDY</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="545"/>
        <source>Read</source>
        <translation>读取</translation>
    </message>
    <message>
        <location filename="../dialogsr.ui" line="571"/>
        <source>Write</source>
        <translation>写入</translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="57"/>
        <location filename="../dialogsr.cpp" line="71"/>
        <location filename="../dialogsr.cpp" line="110"/>
        <location filename="../dialogsr.cpp" line="113"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="57"/>
        <source>Error reading register!</source>
        <translation>错误读取寄存器！</translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="71"/>
        <location filename="../dialogsr.cpp" line="113"/>
        <source>Programmer </source>
        <translation> </translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="71"/>
        <location filename="../dialogsr.cpp" line="113"/>
        <source> is not connected!</source>
        <translation> 编程器未连接！</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">CH341A 编程器未连接！</translation>
    </message>
    <message>
        <location filename="../dialogsr.cpp" line="110"/>
        <source>Before writing the register, please press the `Read` button!</source>
        <translation>在写入寄存器之前，请按`读取`按钮！</translation>
    </message>
</context>
<context>
    <name>DialogSecurity</name>
    <message>
        <location filename="../dialogsecurity.ui" line="14"/>
        <source>Security registers</source>
        <translation>安全登记册</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="24"/>
        <source>Hex Editor</source>
        <translation>十六进制编辑器</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="64"/>
        <source>Operations:</source>
        <translation>业务：</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="93"/>
        <source>Reading security register data from the chip</source>
        <translation>从芯片读取安全寄存器数据</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="96"/>
        <location filename="../dialogsecurity.ui" line="128"/>
        <location filename="../dialogsecurity.ui" line="160"/>
        <location filename="../dialogsecurity.ui" line="199"/>
        <location filename="../dialogsecurity.ui" line="231"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="125"/>
        <source>Erasing security register data</source>
        <translation>清除安全寄存器数据</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="157"/>
        <source>Writing data to the security register</source>
        <translation>向安全寄存器写入数据</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="196"/>
        <source>Open a binary file from a computer</source>
        <translation>从计算机打开二进制文件</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="228"/>
        <source>Save the binary file on the computer</source>
        <translation>在电脑上保存二进制文件</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.ui" line="257"/>
        <source>Security register number:</source>
        <translation>安全登记编号：</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="173"/>
        <location filename="../dialogsecurity.cpp" line="183"/>
        <location filename="../dialogsecurity.cpp" line="257"/>
        <location filename="../dialogsecurity.cpp" line="294"/>
        <location filename="../dialogsecurity.cpp" line="365"/>
        <location filename="../dialogsecurity.cpp" line="390"/>
        <location filename="../dialogsecurity.cpp" line="423"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="173"/>
        <source>Error reading register!</source>
        <translation>错误读取寄存器！</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">CH341A 编程器未连接！</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="183"/>
        <location filename="../dialogsecurity.cpp" line="294"/>
        <location filename="../dialogsecurity.cpp" line="365"/>
        <source>Programmer </source>
        <translation> </translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="183"/>
        <location filename="../dialogsecurity.cpp" line="294"/>
        <location filename="../dialogsecurity.cpp" line="365"/>
        <source> is not connected!</source>
        <translation> 编程器未连接！</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="257"/>
        <source>Error writing register!</source>
        <translation>错误写入寄存器！</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="381"/>
        <source>Open file</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="390"/>
        <source>The file size exceeds the security register size.</source>
        <translation>文件大小超过安全寄存器大小。</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="412"/>
        <source>Save file</source>
        <translation>保存文件</translation>
    </message>
    <message>
        <location filename="../dialogsecurity.cpp" line="423"/>
        <source>Error saving file!</source>
        <translation>保存文件出错！</translation>
    </message>
</context>
<context>
    <name>DialogSetAddr</name>
    <message>
        <location filename="../dialogsetaddr.ui" line="14"/>
        <source>Goto address</source>
        <translation>转到地址</translation>
    </message>
    <message>
        <location filename="../dialogsetaddr.ui" line="24"/>
        <source>All values in HEX format!</source>
        <translation>所有数值均为 HEX 格式！</translation>
    </message>
    <message>
        <location filename="../dialogsetaddr.ui" line="39"/>
        <source>Address:</source>
        <translation>地址:</translation>
    </message>
    <message>
        <location filename="../dialogsetaddr.ui" line="90"/>
        <source>Go to</source>
        <translation>转到</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="1042"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1155"/>
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1158"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1179"/>
        <source>Exit</source>
        <translation>退出</translation>
    </message>
    <message>
        <source>Ctrl+X</source>
        <translation type="vanished">Ctrl+X</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1167"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="29"/>
        <source>IMSProg - I2C/MicroWire/SPI CH341a Programmer</source>
        <translation>IMSProg - I2C、SPI、MicroWire EEPROM/Flash 芯片 CH341A 编程器</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="77"/>
        <location filename="../mainwindow.ui" line="1060"/>
        <source>Chip</source>
        <translation>芯片</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="171"/>
        <source>Name</source>
        <translation>名称</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="247"/>
        <source>Page size</source>
        <translation>页面大小</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="285"/>
        <source>Block size</source>
        <translation>块大小</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="323"/>
        <source>VCC, Volt</source>
        <translation>VCC(伏)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="423"/>
        <source>4byte Addr.</source>
        <translation>4 字节地址</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="572"/>
        <location filename="../mainwindow.ui" line="1191"/>
        <source>Detect</source>
        <translation>检测</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="609"/>
        <location filename="../mainwindow.ui" line="1203"/>
        <source>Read</source>
        <translation>读取</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="411"/>
        <source>i</source>
        <translation>i</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="461"/>
        <source>I2C bus speed</source>
        <translation>I2C 总线速度</translation>
    </message>
    <message>
        <source>Erase size</source>
        <translation type="vanished">擦除大小</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="496"/>
        <source>ECC size</source>
        <translation>ECC 尺寸</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="682"/>
        <source>Auto Options</source>
        <translation>自动选项</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="699"/>
        <location filename="../mainwindow.ui" line="1215"/>
        <source>Erase</source>
        <translation>擦除</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="719"/>
        <source>Program</source>
        <translation>编程</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="729"/>
        <location filename="../mainwindow.ui" line="1239"/>
        <source>Verify</source>
        <translation>校验</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="784"/>
        <source>Go!</source>
        <translation>开始吧！</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="823"/>
        <location filename="../mainwindow.ui" line="1075"/>
        <source>Hex Editor</source>
        <translation>十六进制编辑器</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="891"/>
        <source>  JEDEC ID:</source>
        <translation>JEDEC ID:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="907"/>
        <source>CH341a:</source>
        <translation>CH341A:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="938"/>
        <source>border: 2px solid gray;border-radius: 5px;font-weight:600;border-style:inset;</source>
        <translation>border: 2px solid gray;border-radius: 5px;font-weight:600;border-style:inset;</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="951"/>
        <source>CRC32:</source>
        <translation>CRC32:</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1010"/>
        <source>Message</source>
        <translation>留言</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1097"/>
        <source>Programmer</source>
        <translation>编程器</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1091"/>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="618"/>
        <source>Operations</source>
        <translation>操作</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="709"/>
        <location filename="../mainwindow.ui" line="1495"/>
        <source>Check erase</source>
        <translation>检查擦除</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1170"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1194"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1206"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1218"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1227"/>
        <source>Write</source>
        <translation>写入</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1230"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1242"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1251"/>
        <source>Undo</source>
        <translation>撤消</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1254"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1263"/>
        <source>Redo</source>
        <translation>重做</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1266"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1337"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1376"/>
        <source>Import from Intel HEX</source>
        <translation>从英特尔 HEX 导入</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1385"/>
        <source>Export to Intel HEX</source>
        <translation>导出为英特尔 HEX</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1394"/>
        <source>Extract from ASUS CAP</source>
        <translation>从ASUS CAP移除</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1403"/>
        <source>Goto address</source>
        <translation>转到地址</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1406"/>
        <source>Move the cursor to the entered address</source>
        <translation>将光标移至输入的地址</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1409"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1418"/>
        <source>Security registers</source>
        <translation>安全登记册</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1421"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1430"/>
        <source>Fill test image</source>
        <translation>填充测试图像</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1433"/>
        <source>Filling the hex editor with a test array</source>
        <translation>用测试数组填充十六进制编辑器</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1436"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1445"/>
        <source>Compare files</source>
        <translation>比较文件</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1448"/>
        <source>Compares the results of the last and penultimate chip read or file open operation</source>
        <translation>比较最后一次和倒数第二次芯片读取或文件打开操作的结果。</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1451"/>
        <source>Ctrl+M</source>
        <translation>Ctrl+M</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1460"/>
        <source>Copy</source>
        <translation>复制</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1469"/>
        <source>Paste</source>
        <translation>粘贴</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1478"/>
        <source>Bad block management</source>
        <translation>坏块管理</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1481"/>
        <source>Ctrl+B</source>
        <translation>Ctrl+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1486"/>
        <source>Show programmer version</source>
        <translation>显示编程器版本</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1498"/>
        <source>Check erase chip</source>
        <translation>检查芯片是否已擦除</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1501"/>
        <source>Ctrl+J</source>
        <translation>Ctrl+J</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1510"/>
        <source>Filling with code</source>
        <translation>正在用代码填充</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1513"/>
        <source>Ctrl+K</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1525"/>
        <source>CH341A/B v1.2</source>
        <translation>CH341A/B v1.2</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1533"/>
        <source>CH341A v1.7</source>
        <translation>CH341A v1.7</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1541"/>
        <source>CH347T v1.0</source>
        <translation>CH347T v1.0</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1549"/>
        <source>CH347T v1.1</source>
        <translation>CH347T v1.1</translation>
    </message>
    <message>
        <source>CH347T</source>
        <translation type="vanished">CH347T</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1275"/>
        <source>Save Part</source>
        <translation>部分保存</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1287"/>
        <source>Load Part</source>
        <translation>部分加载</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1299"/>
        <source>Find / Replace</source>
        <translation>查找/替换</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1302"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1307"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1310"/>
        <source>About IMSProgrammer</source>
        <translation>关于 IMSProg</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1313"/>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1322"/>
        <source>Checksum calculate</source>
        <translation>计算校验和</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1325"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1334"/>
        <source>Edit chips Database</source>
        <translation>编辑芯片数据库</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1182"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1346"/>
        <location filename="../mainwindow.cpp" line="1997"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1349"/>
        <source>Forced stop of read, write, erase and verification operations</source>
        <translation>强制停止读、写、擦除和校验操作</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1352"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1361"/>
        <source>Chip info</source>
        <translation>芯片信息</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1364"/>
        <source>Information about SFDP and status registers</source>
        <translation>有关 SFDP 和状态寄存器的信息</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1367"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="937"/>
        <location filename="../mainwindow.cpp" line="980"/>
        <location filename="../mainwindow.cpp" line="1541"/>
        <location filename="../mainwindow.cpp" line="2296"/>
        <location filename="../mainwindow.cpp" line="2372"/>
        <source>Current file: </source>
        <translation>当前文件： </translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="83"/>
        <source>Type</source>
        <translation>类型</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="127"/>
        <source>Manufacture</source>
        <translation>制造商</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="209"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2066"/>
        <source>Opening DAT file</source>
        <translation>打开 DAT 文件</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <location filename="../mainwindow.cpp" line="312"/>
        <location filename="../mainwindow.cpp" line="320"/>
        <location filename="../mainwindow.cpp" line="326"/>
        <location filename="../mainwindow.cpp" line="358"/>
        <location filename="../mainwindow.cpp" line="359"/>
        <location filename="../mainwindow.cpp" line="372"/>
        <location filename="../mainwindow.cpp" line="389"/>
        <location filename="../mainwindow.cpp" line="410"/>
        <location filename="../mainwindow.cpp" line="682"/>
        <location filename="../mainwindow.cpp" line="699"/>
        <location filename="../mainwindow.cpp" line="719"/>
        <location filename="../mainwindow.cpp" line="764"/>
        <location filename="../mainwindow.cpp" line="815"/>
        <location filename="../mainwindow.cpp" line="862"/>
        <location filename="../mainwindow.cpp" line="930"/>
        <location filename="../mainwindow.cpp" line="970"/>
        <location filename="../mainwindow.cpp" line="1051"/>
        <location filename="../mainwindow.cpp" line="1115"/>
        <location filename="../mainwindow.cpp" line="1124"/>
        <location filename="../mainwindow.cpp" line="1131"/>
        <location filename="../mainwindow.cpp" line="1157"/>
        <location filename="../mainwindow.cpp" line="1167"/>
        <location filename="../mainwindow.cpp" line="1338"/>
        <location filename="../mainwindow.cpp" line="1392"/>
        <location filename="../mainwindow.cpp" line="1401"/>
        <location filename="../mainwindow.cpp" line="1407"/>
        <location filename="../mainwindow.cpp" line="1418"/>
        <location filename="../mainwindow.cpp" line="1447"/>
        <location filename="../mainwindow.cpp" line="1448"/>
        <location filename="../mainwindow.cpp" line="1462"/>
        <location filename="../mainwindow.cpp" line="1492"/>
        <location filename="../mainwindow.cpp" line="1497"/>
        <location filename="../mainwindow.cpp" line="1521"/>
        <location filename="../mainwindow.cpp" line="1555"/>
        <location filename="../mainwindow.cpp" line="1866"/>
        <location filename="../mainwindow.cpp" line="2074"/>
        <location filename="../mainwindow.cpp" line="2086"/>
        <location filename="../mainwindow.cpp" line="2246"/>
        <location filename="../mainwindow.cpp" line="2262"/>
        <location filename="../mainwindow.cpp" line="2386"/>
        <location filename="../mainwindow.cpp" line="2418"/>
        <location filename="../mainwindow.cpp" line="2436"/>
        <location filename="../mainwindow.cpp" line="2456"/>
        <location filename="../mainwindow.cpp" line="2588"/>
        <location filename="../mainwindow.cpp" line="2702"/>
        <location filename="../mainwindow.cpp" line="2748"/>
        <location filename="../mainwindow.cpp" line="2800"/>
        <location filename="../mainwindow.cpp" line="2809"/>
        <location filename="../mainwindow.cpp" line="2815"/>
        <location filename="../mainwindow.cpp" line="2826"/>
        <location filename="../mainwindow.cpp" line="2855"/>
        <location filename="../mainwindow.cpp" line="2856"/>
        <location filename="../mainwindow.cpp" line="2869"/>
        <location filename="../mainwindow.cpp" line="2895"/>
        <location filename="../mainwindow.cpp" line="2900"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="320"/>
        <location filename="../mainwindow.cpp" line="372"/>
        <location filename="../mainwindow.cpp" line="389"/>
        <location filename="../mainwindow.cpp" line="699"/>
        <location filename="../mainwindow.cpp" line="1124"/>
        <location filename="../mainwindow.cpp" line="1167"/>
        <location filename="../mainwindow.cpp" line="1401"/>
        <location filename="../mainwindow.cpp" line="1462"/>
        <location filename="../mainwindow.cpp" line="2702"/>
        <location filename="../mainwindow.cpp" line="2809"/>
        <location filename="../mainwindow.cpp" line="2869"/>
        <source>Programmer </source>
        <translation> </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="320"/>
        <location filename="../mainwindow.cpp" line="372"/>
        <location filename="../mainwindow.cpp" line="389"/>
        <location filename="../mainwindow.cpp" line="699"/>
        <location filename="../mainwindow.cpp" line="1124"/>
        <location filename="../mainwindow.cpp" line="1167"/>
        <location filename="../mainwindow.cpp" line="1401"/>
        <location filename="../mainwindow.cpp" line="1462"/>
        <location filename="../mainwindow.cpp" line="2702"/>
        <location filename="../mainwindow.cpp" line="2809"/>
        <location filename="../mainwindow.cpp" line="2869"/>
        <source> is not connected!</source>
        <translation> 编程器未连接！</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1497"/>
        <location filename="../mainwindow.cpp" line="2900"/>
        <source>The ending address must not exceed the buffer size.</source>
        <translation>结束地址不得超过缓冲区大小。</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1866"/>
        <source>File &apos;IMSProg_editor&apos; not found!</source>
        <translation>¡未找到文件 `IMSProg_editor`！</translation>
    </message>
    <message>
        <source>Error loading chip database file!</source>
        <translation type="vanished">加载芯片数据库文件时出错！</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2092"/>
        <source>Parsing DAT file</source>
        <translation>解析 DAT 文件</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="277"/>
        <source>Reading data from </source>
        <translation>读取的数据来自</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <location filename="../mainwindow.cpp" line="312"/>
        <location filename="../mainwindow.cpp" line="1051"/>
        <location filename="../mainwindow.cpp" line="1115"/>
        <location filename="../mainwindow.cpp" line="1338"/>
        <location filename="../mainwindow.cpp" line="1392"/>
        <location filename="../mainwindow.cpp" line="2748"/>
        <location filename="../mainwindow.cpp" line="2800"/>
        <source>Unsupported chip type!</source>
        <translation>不支持的芯片类型！</translation>
    </message>
    <message>
        <source>Programmer CH341a is not connected!</source>
        <translation type="vanished">CH341A 编程器未连接！</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="326"/>
        <location filename="../mainwindow.cpp" line="1407"/>
        <location filename="../mainwindow.cpp" line="2815"/>
        <source>Error reading block </source>
        <translation>读取程序块编号出错 </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="358"/>
        <location filename="../mainwindow.cpp" line="1157"/>
        <location filename="../mainwindow.cpp" line="1447"/>
        <location filename="../mainwindow.cpp" line="2855"/>
        <source>Before reading from chip please press &apos;Detect&apos; button.</source>
        <translation>读取芯片数据前，请按下 &apos;检测&apos; 按钮。</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="359"/>
        <source>Please select the chip parameters - manufacture and chip name</source>
        <translation>请选择芯片参数 - &apos;制造商&apos; 和芯片 &apos;名称&apos;。</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="410"/>
        <source>The chip is not connect or missing!</source>
        <translation>芯片没有连接或丢失！</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="669"/>
        <location filename="../mainwindow.cpp" line="2287"/>
        <source>Saving file</source>
        <translation>保存文件</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="671"/>
        <location filename="../mainwindow.cpp" line="2289"/>
        <source>Save file</source>
        <translation>保存文件</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="673"/>
        <location filename="../mainwindow.cpp" line="911"/>
        <source>Data Images</source>
        <translation>数据文件</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="673"/>
        <location filename="../mainwindow.cpp" line="911"/>
        <location filename="../mainwindow.cpp" line="2291"/>
        <location filename="../mainwindow.cpp" line="2364"/>
        <source>All files</source>
        <translation>所有文件</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="682"/>
        <location filename="../mainwindow.cpp" line="1521"/>
        <source>Error saving file!</source>
        <translation>保存文件出错！</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="702"/>
        <source>Erasing the </source>
        <translation>擦除芯片 </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="719"/>
        <location filename="../mainwindow.cpp" line="764"/>
        <location filename="../mainwindow.cpp" line="815"/>
        <location filename="../mainwindow.cpp" line="862"/>
        <source>Error erasing sector </source>
        <translation>擦除扇区号出错 </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="903"/>
        <location filename="../mainwindow.cpp" line="958"/>
        <location filename="../mainwindow.cpp" line="2358"/>
        <source>Opening file</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="909"/>
        <location filename="../mainwindow.cpp" line="962"/>
        <location filename="../mainwindow.cpp" line="2362"/>
        <source>Open file</source>
        <translation>打开文件</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="930"/>
        <location filename="../mainwindow.cpp" line="970"/>
        <source>The file size exceeds the chip size. Please select another chip or file or use `Save part` to split the file.</source>
        <translation>文件大小超出芯片大小。请选择其他芯片或文件，或使用 &quot;部分保存&quot; 分割文件。</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1061"/>
        <source>Writing data to </source>
        <translation>将数据写入 </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1131"/>
        <source>Error writing sector </source>
        <translation>写入扇区号出错 </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1356"/>
        <source>Veryfing data from </source>
        <translation>从芯片中提取数据 </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1418"/>
        <source>Error comparing data!
Address:   </source>
        <translation>数据比较错误！
地址：   </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1418"/>
        <source>
Buffer: </source>
        <translation>
缓冲区：  </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1418"/>
        <location filename="../mainwindow.cpp" line="2826"/>
        <source>    Chip: </source>
        <translation>    芯片： </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1448"/>
        <location filename="../mainwindow.cpp" line="2588"/>
        <location filename="../mainwindow.cpp" line="2856"/>
        <source>Please select the chip parameters - manufacture and chip name.</source>
        <translation>请选择芯片参数 - &apos;制造商&apos; 和芯片 &apos;名称&apos;。</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1457"/>
        <source>Ok!</source>
        <translation>Ok!</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1457"/>
        <source>The operation was successful!</source>
        <translation>操作成功！</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1492"/>
        <location filename="../mainwindow.cpp" line="2895"/>
        <source>The end address must be greater than the starting address.</source>
        <translation>结束地址必须大于起始地址。</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1509"/>
        <source>Saving block</source>
        <translation>保存块</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1511"/>
        <source>Save block</source>
        <translation>保存块</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1536"/>
        <source>Opening block</source>
        <translation>打开块</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1538"/>
        <source>Open block</source>
        <translation>打开块</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1555"/>
        <source>The end address out of image size!</source>
        <translation>末端地址超出映像大小范围！</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1593"/>
        <source>Connected</source>
        <translation>已连接</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1598"/>
        <source>Not connected</source>
        <translation>未连接</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2073"/>
        <source>Cannot find a chip database file.
You may want to run IMSProg_database_update</source>
        <translation>找不到芯片数据库文件。
您可能需要运行 IMSProg_database_update</translation>
    </message>
    <message>
        <source>The chip database file was not found!</source>
        <translation type="vanished">未找到芯片数据库文件！</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2082"/>
        <source>Error loading chip database file!
File: %1
Error Code: %2
Reason: %3</source>
        <translation>加载芯片数据库文件时发生错误！
文件：%1
错误代码：%2
原因：%3</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2246"/>
        <source>Before working with the security registers, click the &apos;Detect&apos; button</source>
        <translation>在使用安全注册表之前，请点击 &apos;检测&apos;按钮</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2262"/>
        <source>There are no security registers in this chip or the current version of IMSProg does not support this algorithm.</source>
        <translation>该芯片中没有安全寄存器，或者当前版本的 IMSProg 不支持这种算法。</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2291"/>
        <location filename="../mainwindow.cpp" line="2364"/>
        <source>Intel HEX Images</source>
        <translation>Intel HEX 文件</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2386"/>
        <source>Not valid HEX format!</source>
        <translation>不是有效的 HEX 格式！</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2418"/>
        <source>The address is larger than the size of the chip!</source>
        <translation>地址大于芯片大小！</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2436"/>
        <location filename="../mainwindow.cpp" line="2456"/>
        <source>Checksum error!</source>
        <translation>校验和错误！</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2700"/>
        <source>Info:</source>
        <translation>信息：</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2700"/>
        <source>Device revision: </source>
        <translation>设备版本号： </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2765"/>
        <source>Erase checking in </source>
        <translation>正在检查 </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2826"/>
        <source>Error erasing chip!
Address:   </source>
        <translation>擦除芯片时出错！
地址：   </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2826"/>
        <source>
Need: FF</source>
        <translation>
需要：FF</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1997"/>
        <source>Operation aborted!</source>
        <translation>操作中止！</translation>
    </message>
</context>
<context>
    <name>SearchDialog</name>
    <message>
        <location filename="../searchdialog.ui" line="14"/>
        <source>QHexEdit - Find/Replace</source>
        <translation>QHexEdit - 查找/替换</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="26"/>
        <source>Find</source>
        <translation>查找</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="33"/>
        <location filename="../searchdialog.ui" line="78"/>
        <source>Hex</source>
        <translation>Hex</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="38"/>
        <location filename="../searchdialog.ui" line="83"/>
        <source>UTF-8</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="71"/>
        <source>Replace</source>
        <translation>更换</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="116"/>
        <source>Options</source>
        <translation>选项:</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="122"/>
        <source>&amp;Backwards</source>
        <translation>向后</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="129"/>
        <source>&amp;Prompt on replace</source>
        <translation>更换时提示</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="150"/>
        <source>Standard headers:</source>
        <translation>标准标头：</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="191"/>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="213"/>
        <source>PNG</source>
        <translation>PNG</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="235"/>
        <source>JPG</source>
        <translation>JPG</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="257"/>
        <source>GIF</source>
        <translation>GIF</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="286"/>
        <source>TAR</source>
        <translation>TAR</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="308"/>
        <source>UEFI</source>
        <translation>UEFI</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="330"/>
        <source>BIOS</source>
        <translation>BIOS</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="352"/>
        <source>GPT</source>
        <translation>GPT</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="385"/>
        <source>&amp;Find</source>
        <translation>查找</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="388"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="413"/>
        <source>&amp;Replace</source>
        <translation>替换</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="435"/>
        <source>Replace &amp;All</source>
        <translation>全部更换</translation>
    </message>
    <message>
        <location filename="../searchdialog.ui" line="457"/>
        <source>&amp;Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="../searchdialog.cpp" line="91"/>
        <location filename="../searchdialog.cpp" line="117"/>
        <source>QHexEdit</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../searchdialog.cpp" line="91"/>
        <source>%1 occurrences replaced.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../searchdialog.cpp" line="118"/>
        <source>Replace occurrence?</source>
        <translation>替换发生？</translation>
    </message>
</context>
<context>
    <name>UndoStack</name>
    <message>
        <location filename="../commands.cpp" line="133"/>
        <source>Inserting %1 bytes</source>
        <translation>插入 %1 字节</translation>
    </message>
    <message>
        <location filename="../commands.cpp" line="155"/>
        <source>Delete %1 chars</source>
        <translation>删除 %1 字符</translation>
    </message>
    <message>
        <location filename="../commands.cpp" line="180"/>
        <source>Overwrite %1 chars</source>
        <translation>覆盖 %1 字符</translation>
    </message>
</context>
</TS>
