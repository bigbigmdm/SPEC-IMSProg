#define snander		128
